import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      light: '#757ce8',
      main: '#416788', 
      dark: '#3E4093',
      contrastText: '#416788',
    },
    secondary: {
      light: '#cbd8f1',
      main: '#cbd8f1',
      dark: '#8283B4',
      contrastText: '#000',
    },
  },
});

export default theme;
