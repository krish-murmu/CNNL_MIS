import { create } from "zustand";
import { persist } from "zustand/middleware";
import { LoginResponse } from "../types";
type LoginRes = Omit<LoginResponse, "accessToken,refreshToken">;

type TokenStore = {
  accessToken: string;
  refreshToken: string;
  AuthData: LoginRes;
  setToken: (accessToken: string, refreshToken: string) => void;
  clearToken: () => void;
  clearAuthData: () => void;
};

export const useTokenStore = create(
  persist<TokenStore>(
    (set) => ({
      AuthData: {} as LoginResponse,
      accessToken: "",
      refreshToken: "",
      setToken: (accessToken, refreshToken) =>
        set({ accessToken, refreshToken }),
      clearToken: () => set({ accessToken: "", refreshToken: "" }),
      setAuthData: (AuthData: LoginResponse) => set({ AuthData }),
      clearAuthData: () =>
        set({
          AuthData: {} as LoginResponse,
          accessToken: "",
          refreshToken: "",
        }),
    }),
    {
      name: "token-storage", // unique name of the storage
      getStorage: () => localStorage, // specify the storage to use (here it's localStorage)
    }
  )
);
