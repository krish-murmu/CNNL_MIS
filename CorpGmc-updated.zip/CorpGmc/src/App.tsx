// App.tsx
import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import Login from "./Auth/Login";
import Home from "./Home";
import PolicyDetailsForm from "./Pages/PolicyDetails/PolicyDetailsForm";
import AddressForm from "./Pages/PolicyDetails/Address/AddressForm";
import { ThemeProvider, createTheme } from "@mui/material";
import theme from "./theme";
import UnifiedFormComponent from "./Pages/AddressMaster/UnifiedFormComponent";
import TestPage from "Pages/TestPage";
import RolesManage from "Pages/RolesManage/RolesManage";
import RoleAdd from "Pages/RolesManage/RoleAdd";
import { Toaster } from "react-hot-toast";
import RoleEdit from "Pages/RolesManage/RoleEdit";
import RoleView from "Pages/RolesManage/RoleView";
import CustomerMaster from "Pages/CustomerMaster/CustomerMaster";
import UnifiedForm from "Pages/CustomerMaster/UnifiedForm";
import CityMaster from "Pages/City/CityMaster";
import CityUnifiedForm from "Pages/City/CityUnifiedForm";
import { useAuthStore } from "./Zustand/AuthStore";
import ContactPerson from "Pages/ContactPerson/ContactPerson";
import ContactPersonMaster from "Pages/ContactPerson/ContactPerson";
import CPUnifiedForm from "Pages/ContactPerson/CPUnifiedForm";
import Users from "Pages/Users/Users";
import UserUnifiedForm from "Pages/Users/UserUnifiedForm";
import Create_Quote from "Pages/Quotes/Create_Quote";
import QuoteMaster from "Pages/Quotes/QuoteMaster";
import Quote_View from "Pages/Quotes/Quote_View";
import AddressMaster from "Pages/AddressMaster/AddressMaster";
import PageMaster from "Pages/PageMaster/PageMaster";
import PageUnifiedForm from "Pages/PageMaster/PageUnifiedForm";
import Renewal_Quote from "Pages/Quotes/Renewal_Quote";
import ModuleMaster from "Pages/ModuleMaster/ModuleMaster";
import NotFound from "Pages/NotFound";
import ModuleUnifiedForm from "Pages/ModuleMaster/ModuleUnifiedForm";
import CoverageMaster from "Pages/CoverageMaster/CoverageMaster";
import NewCoverages from "Pages/CoverageMaster/NewCoverages";
import InsuranceCompany from "Pages/InsuranceCompanies/InsuranceCompany";
import InsuranceUnifiedForm from "Pages/InsuranceCompanies/InsuranceUnifiedForm";
import CoverageEdit from "Pages/CoverageMaster/CoverageEdit";
import CoverageView from "Pages/CoverageMaster/CoverageView";

const App: React.FC = () => {
  /*const isAuthenticated = true; useAuthStore((state) => state.isAuthenticated);*/
  return (
    <ThemeProvider theme={theme}>
      <Toaster />
      <Routes>
        {/* <Route path="/" element={<Login />} /> */}
        
        <Route
          path="/"
          element={<Navigate to="/home" />}
        />

        {/* isAuthenticated && */(
          <>
            <Route path="/home" element={<Home />} />

            <>
              <Route path="/pages/manage" element={<PageMaster />} />
              <Route
                path="/pages/manage/form/:mode/:id?"
                element={<PageUnifiedForm />}
              />
            </>
            <>
              <Route path="/modules/manage" element={<ModuleMaster />} />
              <Route
                path="/modules/manage/form/:mode/:id?"
                element={<ModuleUnifiedForm />}
              />
            </>
            <>
              <Route
                path="/insurance-companies/manage"
                element={<InsuranceCompany />}
              />
              <Route
                path="/insurance-companies/manage/form/:mode/:id?"
                element={<InsuranceUnifiedForm />}
              />
            </>
            <>
              <Route path="/user/manage" element={<Users />} />
              <Route
                path="/user/manage/form/:mode/:id?"
                element={<UserUnifiedForm />}
              />
            </>
            <>
              <Route path="/address-master" element={<AddressMaster />} />
              <Route
                path="/address-master/form/:mode/:id?"
                element={<UnifiedFormComponent />}
              />
              <Route path="/address-details" element={<AddressForm />} />
            </>
            <>
              <Route path="/city" element={<CityMaster />} />
              <Route
                path="/city/form/:mode/:id?"
                element={<CityUnifiedForm />}
              />
            </>
            <>
              <Route path="/customer-master" element={<CustomerMaster />} />
              <Route
                path="/customer-master/form/:mode/:id?"
                element={<UnifiedForm />}
              />
            </>
            <>
              <Route path="/contact-person" element={<ContactPersonMaster />} />
              <Route
                path="/contact-person/form/:mode/:id?"
                element={<CPUnifiedForm />}
              />
            </>
            <>
              <Route path="/roles/manage" element={<RolesManage />} />
              <Route path="/roles/add" element={<RoleAdd />} />
              <Route path="/roles/edit/:id" element={<RoleEdit />} />
              <Route path="/roles/view/:id" element={<RoleView />} />
            </>
            <>
              <Route path="/quote/manage" element={<QuoteMaster />} />
              <Route path="/quote/new-gmc-quote" element={<Create_Quote />} />
              <Route path="/quote/renewal" element={<Renewal_Quote />} />
              <Route path="/quote/view/:id" element={<Quote_View />} />
            </>
            <>
              <Route path="/coverages/manage" element={<CoverageMaster />} />
              <Route path="/coverages/add" element={<NewCoverages />} />
              <Route path="/coverages/edit/:id" element={<CoverageEdit />} />
              <Route path="/coverages/view/:id" element={<CoverageView />} />
            </>
            <Route path="/test" element={<TestPage />} />
            {/* <Route path="/404" element={<NotFound />} />
            <Route path="*" element={<Navigate to="/404" />} /> */}
          </>
        )}
      </Routes>
    </ThemeProvider>
  );
};

const moduleData = [
  {
    Modules:[
      {
        "Module_Id": 1,
        "Module_Name": "Masters",
        "Module_Icon": "M",
        "Module_Order": 1,
        "Module_Status": 1,
        "Pages": [],
      },
      {
        "Module_Id": 2,
        "Module_Name": "Quote",
        "Module_Icon": "M",
        "Module_Order": 2,
        "Module_Status": 1,
        "Pages": [],
      }

    ]
  }
];

export default App;
