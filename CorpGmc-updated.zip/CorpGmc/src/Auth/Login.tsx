import React, { useState } from "react";
import axios from "axios";
import { useForm, SubmitHandler, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import toast, { Toaster } from "react-hot-toast";
import { useAuthStore } from "../Zustand/AuthStore";
import { useNavigate } from "react-router";
import { useTokenStore } from "../Zustand/TokenStore";
import { BASE_API_URL } from "../API/Base";
import login from "../assets/login.svg";
import { LoginResponse } from "../types";
import { setAuthToken } from "API/axios";
import { Update_Login_Logs } from "API/Utils";
import logo_bg from "../assets/login_bg.png";
import img from "../assets/bg-logo.png";
interface LoginFormValues {
  username: string;
  password: string;
}

const schema = yup.object().shape({
  username: yup.string().required(),
  password: yup.string().min(8).max(32).required(),
});

const Login: React.FC = () => {
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: yupResolver(schema),
  });
  const [isUsernameFocused, setIsUsernameFocused] = useState<boolean>(false);
  const [isPasswordFocused, setIsPasswordFocused] = useState<boolean>(false);

  const { authenticate } = useAuthStore();

  const navigate = useNavigate();

  const onSubmit: SubmitHandler<LoginFormValues> = async (data) => {
    try {
      const response = await axios.post(
        `${BASE_API_URL}/admin/auth/v3/login`,
        data
      );

      if (response.status === 200) {
        const data: LoginResponse = response.data;
        const access = data.access_token;
        const refresh = data.refresh_token;
        useTokenStore.setState({
          accessToken: access,
          refreshToken: refresh,
          AuthData: data,
        });
        setAuthToken(useTokenStore.getState().accessToken);
        console.log(useTokenStore.getState().AuthData);
        authenticate();
        // Update_Login_Logs();
      }
      toast.success("Login successful");
      // navigate("/city");
    } catch (error) {
      toast.error("Login failed");
      console.error("Login failed:");
    }
  };

  return (
    <div
      className="flex h-screen bg-center bg-no-repeat bg-cover"
      style={{ backgroundImage: `url('${logo_bg}')` }}
    >
      <div className="flex items-center justify-center flex-1 overflow-hidden">
        <div
          className="w-full max-w-md p-20 mt-8 ml-auto mr-40 bg-transparent bg-center bg-no-repeat bg-cover"
          style={{ backgroundImage: `url('${img}')` }}
        >
          <h1 className="mb-4 text-5xl font-normal text-center text-white">
            Welcome!
          </h1>
          <div>
            <form
              onSubmit={handleSubmit(onSubmit)}
              className="flex flex-col items-center justify-center gap-y-2"
            >
              <Controller
                name="username"
                control={control}
                render={({ field }) => (
                  <div className="relative w-full mb-4">
                    <input
                      {...field}
                      type="text"
                      value={field.value || ""}
                      placeholder="USERNAME"
                      className="w-full p-2 text-white placeholder-white bg-transparent border-none rounded-none placeholder:capitalize focus:outline-none focus:ring-0"
                    />
                    <div className="absolute inset-x-0 bottom-0 h-0.5 bg-white"></div>
                  </div>
                )}
              />

              <p className="text-red-500">{errors.username?.message}</p>
              <Controller
                name="password"
                control={control}
                render={({ field }) => (
                  <div className="relative w-full mb-4">
                    <input
                      {...field}
                      type="password"
                      value={field.value || ""}
                      className="w-full p-2 text-white placeholder-white bg-transparent border-none rounded-none placeholder:capitalize focus:outline-none focus:ring-0"
                      placeholder="PASSWORD"
                    />
                    <div className="absolute inset-x-0 bottom-0 h-0.5 bg-white"></div>
                  </div>
                )}
              />
              <p className="text-red-500">{errors.password?.message}</p>
              <button
                type="submit"
                className="flex flex-row items-center justify-center w-full p-2 mt-6 transition-all duration-200 ease-in-out bg-white border rounded-md text-primary hover:bg-blue hover:text-white hover:border-transparent"
              >
                LOGIN
              </button>
            </form>
          </div>
        </div>
      </div>

      <Toaster />
    </div>
  );
};

export default Login;
