export type LoginResponse = {
  Status: string;
  Name: string;
  Email: string;
  User_Id: number;
  Business_Id: number;
  access_token: string;
  refresh_token: string;
  RolesList: Role[];
  Modules: Module[];
};

export type Role = {
  Role_Id: number;
  Role_Name: string;
};

export type Module = {
  Module_Id: number;
  Module_Name: string;
  Module_Icon: string;
  Module_Order: number;
  Module_Status: number;
  Module_Parent_Id: number;
  Pages: Page[];
};

export type Page = {
  Page_Id: number;
  Page_Name: string;
  Page_Url: string;
  Page_Icon: string;
  Permissions: Permission;
};

export type Users = {
  Id: number;
  User_Name: string;
  Email_Id: string;
  Mobile_No: string;
  Business_Id: number;
  IsStatus: boolean;
  User_Type: number;
  Role_Id: number;
  Customer_Id: number;
  Roles: Role[];
};

export type Permission = {
  Actions: Action[];
};

export type Action = {
  ActionsId: number;
  ActionName: string;
  Status: boolean;
};

export interface AddressOption {
  Id: number;
  Address_1: string;
  City_Id: number;
}

export interface CityOption {
  Id: number;
  Name: string;
  State_Id: number;
  State_Name: string;
  Pin_Code: number;
}

export interface AddAddressModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddressAdded: (newAddress: AddressOption) => void;
  data: AddressOption[];
  cities: CityOption[];
}

export interface NewAddressModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (newItem: any) => void; // Update type accordingly
  title: string;
  label: string;
  options: any[];
}

export interface ModalState {
  newInput: string;
  selectedOption: string;
}

export interface Field {
  label: string;
  value: string | number;
  name?: string; // Optional property
  type?: string; // Optional property
  placeholder?: string; // Optional property
}

// props expected by the DynamicReadModal component
export interface DynamicReadModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  fields: Field[];
}

// props expected by the DynamicEditModal component
export interface DynamicEditModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  fields: Field[];
  onSubmit: (editedFields: Record<string, string | number>) => void;
}

// props expected by the AddressForm component
export interface AddressFormProps {
  title: string;
  fields: Field[];
  onSubmit: (data: Record<string, string | number>) => void;
}

export interface Address {
  Id: number;
  Address_1: string;
  City_Id: number;
  City_Name: string;
  State_Name: string;
  Created_By: number;
  Created_On: string;
  Modify_By: number;
  Modify_On: string;
}

export interface DynamicViewFormProps {
  fields: Field[];
}

export type CustomerDetails = {
  Id: number;
  Customer_Name: string;
  Address_1: string;
  CP_Id: string;
  Product_Id: string;
  CD_Id: string;
  IsStatus: boolean;
  Created_By: number;
  Created_On: string;
  Modify_By: number;
  Modify_On: string;
};

export interface UnifiedFormParams {
  mode: "create" | "edit" | "view";
  id?: string;
  [key: string]: string | undefined;
}

export interface FormField {
  label: string;
  key: string;
  type?: string;
}

export interface CRUDFormPageProps {
  mode: "create" | "edit" | "view";
  fields: FormField[];
  data: any;
}

export interface ProductDetails {
  Id: number;
  Product_Name: string;
  Created_By: number;
  Created_On: string;
  Modify_By: number;
  Modify_On: string;
}

export interface WrapTextCellProps {
  value: string; // Assuming Address_1 is of type string
}

export interface ContactPerson {
  Id: number;
  CP_Name: string;
  CP_Designation: string;
  CP_Mobile_1: string;
  CP_Mobile_2: string;
  CP_Phone_1: string;
  CP_Extn_No: string;
  CP_Email_Id: string;
  Created_By: number;
  Created_On: string;
  Modify_By: number;
  Modify_On: string;
}

export interface CDAccDetails {
  Id: number;
  CD_Account: string;
  Customer_Id: number;
  CD_Amount: number;
  CD_Received: string;
  CD_Consume: string;
  Created_By: number;
  Created_On: string;
  Modify_By: number;
  Modify_On: string;
}

// AgeGroupModel.ts
interface AgeGroupModel {
  AgeGroup: string;
  AgeGroupCount: number;
}

// QuoteDataModel.ts
export interface QuoteDataModel {
  Id: number;
  QuoteNumber: number;
  EmployeeNumber: string;
  EmployeeName: string;
  EmployeeGender: string;
  EmployeeDOB: string;
  EmployeeRelation: string;
  EmployeeSum: number;
  EmployeeAge: number;
}

export type GMCQuoteOutputModel = {
  AgeGroups: AgeGroupModel[];
  QuoteData: QuoteDataModel[];
};



