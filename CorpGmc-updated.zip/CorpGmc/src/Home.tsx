import React from "react";
import AxiosInstance from "./API/axios";
import { Button } from "@mui/material";
import { useTokenStore } from "./Zustand/TokenStore";
import Layout from "Components/Layout";
import Header from "Components/Header";
import bg from "./assets/30.1.png";

const Home = () => {
  return (
    <Layout>
      <div
        className="flex justify-center items-center h-screen bg-cover bg-center"
        style={{
          backgroundImage: `url(${bg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="text-center">
          <h1 className="text-2xl text-primary font-bold mb-4">
            Welcome to Environmental and Social Management Activities under Chennai City Partnership (CCP)
          </h1>
          
        </div>
      </div>
    </Layout>
  );
};

export default Home;
