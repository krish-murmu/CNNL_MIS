import { useEffect, useState } from "react";
import { useTokenStore } from "../Zustand/TokenStore";

type ActionName =
  | "List"
  | "Add"
  | "Update"
  | "Delete"
  | "View"
  | "Print"
  | "Export"
  | "Approval"
  | "Transfer";

type Permissions = {
  [key in ActionName]: boolean;
};

export const usePagePermissions = (pageName: string): Permissions => {
  const [permissions, setPermissions] = useState<Permissions>({
    List: false,
    Add: false,
    Update: false,
    Delete: false,
    View: false,
    Print: false,
    Export: false,
    Approval: false,
    Transfer: false,
  });
  const authData = useTokenStore.getState().AuthData;

  useEffect(() => {
    // Find the page across all modules
    let foundPage = null;
    for (const module of authData?.Modules || []) {
      foundPage = module.Pages.find((page) => page.Page_Name === pageName);
      if (foundPage) break;
    }

    // If the page is found, update permissions
    if (foundPage) {
      const updatedPermissions = { ...permissions };
      foundPage.Permissions.Actions.forEach((action) => {
        if (action.ActionName in updatedPermissions) {
          updatedPermissions[action.ActionName as ActionName] = action.Status;
        }
      });
      setPermissions(updatedPermissions);
    }
  }, [authData, pageName]);

  return permissions;
};
