import React, { useEffect, useState } from "react";
import { useTokenStore } from "../Zustand/TokenStore";
import avatar from "../assets/undraw_male_avatar_g98d.svg";
import { LoginResponse, Module } from "../types";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router";
import { useAuthStore } from "../Zustand/AuthStore";
import { update_logout_logs } from "API/Utils";
import { LogOut, ChevronDown, ChevronRight } from "react-feather"; // Import icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { saveAs } from "file-saver";
//import entitlementmatrix from "../assets/undraw_male_avatar_g98d.svg";
import {
  faUser,
  faFile,
  faPeopleArrows,
  faGears,
  faHeart,
  faChartBar,
  faCalendar,
  faShoppingCart,
  faCog,
  faEnvelope,
  faChevronDown,
  faChevronRight,
} from "@fortawesome/free-solid-svg-icons";

type Props = {};

function Sidebar({}: Props) {
  const navigate = useNavigate();
  const authdata: LoginResponse = useTokenStore((state) => state.AuthData);
  //const modules: Module[] = authdata.Modules;
  /*const onDownload1 = () => {
    saveAs(entitlementmatrix, "testFile.docx");
  };*/
  const moduleData = 
  
    {
      Module:
      [
        {
          "Module_Id": 1,
          "Module_Name": "Entitlement Matrix",
          "Module_Icon": "M",
          "Module_Order": 1,
          "Module_Status": 1,
          "Pages": 
          [],
        },
        {
          "Module_Id": 2,
          "Module_Name": "List of Sub-Projects",
          "Module_Icon": "M",
          "Module_Order": 2,
          "Module_Status": 1,
          "Pages": []
        },
        {
          "Module_Id": 3,
          "Module_Name": "Socio Economic Survey Questionnaire",
          "Module_Icon": "M",
          "Module_Order": 3,
          "Module_Status": 1,
          "Pages": []
        },
        {
          "Module_Id": 4,
          "Module_Name": "R&R Implementation",
          "Module_Icon": "M",
          "Module_Order": 4,
          "Module_Status": 1,
          "Pages": []
        },
        {
          "Module_Id": 5,
          "Module_Name": "Reports Download",
          "Module_Icon": "M",
          "Module_Order": 5,
          "Module_Status": 1,
          "Pages": [
            {
              "Page_Id": 6,
              "Page_Name": "EIA & SIA and EMP&SMP",
              "Page_Url": "",
              "Permissions": 
              {
                "Actions": []
                  }
            },
            {
              "Page_Id": 7,
              "Page_Name": "R&R Plan",
              "Page_Url": "",
              "Permissions": 
              {
                "Actions": []
                  }
            },
          ]
        },
      ]
    };
  
  const [modules, setModules] = useState(moduleData);
  //const modules: Module[] = moduleData;
  const [expandedModules, setExpandedModules] = useState<Set<number>>(
    new Set()
  );
  const { signout } = useAuthStore();
  const { clearAuthData, clearToken } = useTokenStore();

  const handleLogout = async () => {
    try {
      // update_logout_logs();
      clearAuthData();
      clearToken();
      signout();
      navigate("/");
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const handleModuleClick = (moduleId: number) => {
    setExpandedModules((prev) => {
      
      const newExpandedModules = new Set(prev);
      console.log(newExpandedModules);
      if(moduleId==1){
        console.log('Inside module 1');
        <a
        href={require('../assets/data/ReportsDownload/R&R Plan/KNK Road/R&R Plan_KNK_SUSP.pdf')}
        download="Example-PDF-document"
        target="_blank"
        rel="noreferrer"></a>
      }
      if (newExpandedModules.has(moduleId)) {
        newExpandedModules.delete(moduleId);
      } else {
        newExpandedModules.add(moduleId);
      }
      return newExpandedModules;
    });
  };

  const variants = {
    open: {
      opacity: 1,
      height: "auto",
      transition: { duration: 0.3, ease: "easeInOut" },
    },
    collapsed: {
      opacity: 0,
      height: 0,
      transition: { duration: 0.3, ease: "easeInOut" },
    },
  };


  return (
    <div className="flex flex-col h-full overflow-y-auto bg-primary text-secondary hover:scrollbar-thin hover:scrollbar-thumb-blue-500 ">
      <div className="flex items-center justify-center mt-8">
        <img
          src={avatar}
          alt=""
          className="object-cover w-16 h-16 border-2 border-white rounded-full"
        />
        <h1 className="ml-4 text-lg font-semibold capitalize">
          {authdata?.Name}
        </h1>
      </div>

      <div className="flex flex-col gap-2 px-4 mt-8">
        {modules.Module.map((module) => (
          <div key={module.Module_Id} className="w-full">
            <button
              onClick={() => handleModuleClick(module.Module_Id)}
              className="flex items-left w-full py-2 pl-4 pr-2 font-medium transition duration-300 bg-transparent border-none rounded text-secondary focus:outline-none hover:bg-blue hover:text-white"
            >
              <FontAwesomeIcon
                icon={getModuleIcon(module.Module_Icon)}
                className="mr-4 text-blue-300"
              />
              {module.Module_Name}

              {module.Pages.length > 0 && (
                <FontAwesomeIcon
                  icon={
                    expandedModules.has(module.Module_Id)
                      ? faChevronDown
                      : faChevronRight
                  }
                  className="absolute text-blue-300 right-4 size-3"
                />
              )}
            </button>
            <AnimatePresence>
              {expandedModules.has(module.Module_Id) && (
                <motion.div
                  initial="collapsed"
                  animate="open"
                  exit="collapsed"
                  variants={variants}
                >
                  <ul>
                    {module.Pages.map((page) => (
                      <li
                        key={page.Page_Id}
                        onClick={() => navigate(page.Page_Url)}
                        className="p-2 ml-10 text-base font-normal transition duration-300 cursor-pointer hover:text-white"
                      >
                        {page.Page_Name}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
                    ))}
        
      </div>
    </div>
  );
}

// Function to map module icon name to Font Awesome icon
const getModuleIcon = (iconName: string) => {
  switch (iconName) {
    case "User":
      return faUser;
    case "Document":
      return faFile;
    case "People":
      return faPeopleArrows;
    case "gears":
      return faCog;
    case "Heart":
      return faHeart;
    case "Chart":
      return faChartBar;
    case "Calendar":
      return faCalendar;
    case "ShoppingCart":
      return faShoppingCart;
    case "Cog":
      return faCog;
    case "Envelope":
      return faEnvelope;
    default:
      return faUser; // You can return a default icon if the module icon name doesn't match any of the cases
  }
};

export default Sidebar;
