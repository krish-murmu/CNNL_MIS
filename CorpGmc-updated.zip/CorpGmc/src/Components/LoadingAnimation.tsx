import React from "react";
import { motion } from "framer-motion";
type Props = {};

function LoadingAnimation({}: Props) {
  const spinnerStyle = {
    width: "50px",
    height: "50px",
    border: "5px solid #3E4093",
    borderTop: "5px solid transparent",
    borderRadius: "50%",
    animation: "spin 5s linear infinite",
  };

  const containerStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
  };

  return (
    <div style={containerStyle}>
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-t-4 border-solid rounded-full border-primary animate-spin"></div>
      </div>
    </div>
  );
}

export default LoadingAnimation;
