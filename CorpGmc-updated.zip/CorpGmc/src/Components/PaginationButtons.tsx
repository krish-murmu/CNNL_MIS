import React from "react";
import { Pagination } from "@mui/material";
import theme from "theme";

interface PaginationButtonsProps {
  currentPage: number;
  totalPages: number;
  handlePageChange: (page: number) => void;
}

const PaginationButtons: React.FC<PaginationButtonsProps> = ({
  currentPage,
  totalPages,
  handlePageChange,
}) => {
  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    handlePageChange(value);
  };

  return (
    <Pagination
      count={totalPages}
      page={currentPage}
      color="secondary"
      onChange={handleChange}
      size="large"
      sx={{
        margin: "20px auto",
        display: "flex",
        justifyContent: "center",
        color: "#fff",
      }}
    />
  );
};

export default PaginationButtons;
