// SearchInput.tsx
import React from "react";
import TextField from "@mui/material/TextField";

interface SearchInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string; // Add placeholder prop
}

const SearchInput: React.FC<SearchInputProps> = ({
  value,
  onChange,
  placeholder,
}) => {
  return (
    <TextField
      label={placeholder}
      variant="outlined"
      margin="normal"
      value={value}
      size="small"
      sx={{ marginBottom: "16px" }}
      onChange={(e) => onChange(e.target.value)}
      fullWidth
    />
  );
};

export default SearchInput;
