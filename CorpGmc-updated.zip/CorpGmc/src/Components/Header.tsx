import { Typography, Box, useTheme, ThemeProvider } from "@mui/material";
import theme from "../theme";

// Define a type for the props
interface HeaderProps {
  title: string;
  subtitle: string;
}

const Header: React.FC<HeaderProps> = ({ title, subtitle }) => {
  return (
    <ThemeProvider theme={theme}>
      <Box mb="20px">
        <Typography
          variant="h4"
          color={theme.palette.primary.contrastText}
          fontWeight="bold"
        >
          {title}
        </Typography>
        <Typography variant="h5" color={theme.palette.secondary.main}>
          {subtitle}
        </Typography>
      </Box>
    </ThemeProvider>
  );
};

export default Header;
