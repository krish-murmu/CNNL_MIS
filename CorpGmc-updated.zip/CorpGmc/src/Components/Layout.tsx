import React, { ReactNode } from "react";
import Sidebar from "./Sidebar";

type Props = {
  children: ReactNode;
};

export default function Layout({ children }: Props) {
  return (
    <div className="flex flex-col w-full min-h-screen max-h-max">
      <div className="flex">
        <div className="w-1/6 min-w-[16%] bg-green">
          <div className="sticky top-0 h-screen">
            <Sidebar />
          </div>
        </div>
        <div className="flex-1 bg-white max-h-fit">{children}</div>
      </div>
    </div>
  );
}
