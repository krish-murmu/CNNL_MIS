import React from "react";

type Props = {};

function Loading({}: Props) {
  return <div>Loading</div>;
}

export default Loading;
