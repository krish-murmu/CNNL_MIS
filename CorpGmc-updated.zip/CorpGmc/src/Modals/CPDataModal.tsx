import React, { useEffect, useState } from "react";
import { Box, Button, Modal, ThemeProvider, Typography } from "@mui/material";
import { DataGrid, GridColDef, GridRowId } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import { format, parseISO } from "date-fns";
import { ContactPerson, WrapTextCellProps } from "types";
import axios from "axios";
import theme from "theme";
import SearchInput from "Components/SearchInput";
import AxiosInstance from "API/axios";
import PaginationButtons from "Components/PaginationButtons";

interface CPDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectedCP: (selectedCP: any) => void;
}

export const formatDate = (dateString: string | null) => {
  if (!dateString) {
    return "N/A"; // or some default value
  }

  const date = parseISO(dateString);
  return format(date, "M/dd/yyyy h:mm:ss a");
};

const CPDataModal: React.FC<CPDataModalProps> = ({
  isOpen,
  onClose,
  onSelectedCP,
}) => {
  const [contactPersonData, setContactPersonData] = useState<any>([]);
  const [searchValue, setSearchValue] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [rowCount, setRowCount] = useState<number>(0);

  const fetchPageData = async (page: number, pageSize: number) => {
    try {
      setLoading(true);

      console.log("Fetching data for page:", page, "pageSize:", pageSize);

      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/contact-person`,
        {
          params: {
            page,
            per_page: pageSize,
          },
        }
      );

      console.log("Response:", response);
      if (
        !response.data ||
        !response.data.contact_person_data ||
        response.data.total_count == null
      ) {
        console.error("Invalid response format:", response.data);
        setLoading(false);
        return;
      }

      const formattedData = response.data.contact_person_data.map(
        (row: ContactPerson, index: number) => ({
          ...row,
          actionsID: startIndex + index + 1,
          Id: row.Id,
        })
      );

      setContactPersonData(formattedData);
      setRowCount(response.data.total_count);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching city data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchPageData(currentPage, pageSize);
    }
  }, [isOpen, currentPage, pageSize]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  const columns: GridColDef[] = [
    { field: "actionsID", headerName: "ID", width: 50 },
    {
      field: "CP_Name",
      headerName: "Contact Person",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "CP_Designation",
      headerName: "Designation",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "CP_Mobile_1",
      headerName: "Mobile 1",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "CP_Mobile_2",
      headerName: "Mobile 2",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "CP_Phone_1",
      headerName: "Phone 1",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "CP_Extn_No",
      headerName: "Extn No",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "CP_Email_Id",
      headerName: "Email Id",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
  ];

  const filteredCPData = contactPersonData.filter((row: any) =>
    row.CP_Name.toLowerCase().includes(searchValue.toLowerCase())
  );

  const handleRowSelection = (rowSelectionModel: GridRowId[]) => {
    const selectedRowId =
      rowSelectionModel.length > 0 ? rowSelectionModel[0].toString() : null;

    const selectedData = selectedRowId
      ? contactPersonData.find(
          (row: any) => row.Id === parseInt(selectedRowId, 10)
        )
      : null;

    // Ensure selectedData is not null before logging the whole row data
    if (selectedData !== null && selectedData !== undefined) {
      // Pass both selectedCity and selectedData to onSelectCity
      onSelectedCP(selectedData); // Change this line
    }
    onClose();
  };

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  return (
    <ThemeProvider theme={theme}>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "30%",
            left: "50%",
            transform: "translate(-50%, -30%)",
            width: "60%",
            maxWidth: "800px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,
            height: "95vh",
            maxHeight: "900px",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              backgroundColor: "#f0f0f0",
              padding: "14px",
              color: `${theme.palette.primary.main}`,
              fontWeight: "bold",
            }}
          >
            Contact Person Selection
          </Typography>

          <SearchInput
            value={searchValue}
            onChange={setSearchValue}
            placeholder="Search by contact person name"
          />
          <Box
            sx={{
              "& .MuiDataGrid-root": {
                border: "none",
                borderBottom: `2px solid ${theme.palette.secondary.light}`,
              },

              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: theme.palette.primary.main,
                borderBottom: "none",
                fontWeight: "bold",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                color: "#fff !important",
              },

              "& .MuiDataGrid-colCell": {
                color: `#fff !important`,
              },

              "& .MuiDataGrid-footerContainer": {
                display: "none",
              },
            }}
          >
            <DataGrid
              columns={columns}
              rows={filteredCPData}
              getRowId={(row) => row.Id}
              autoHeight
              loading={loading}
              onRowSelectionModelChange={handleRowSelection}
            />

            <PaginationButtons
              currentPage={currentPage}
              totalPages={totalPages}
              handlePageChange={handlePageChange}
            />
          </Box>
          <Button onClick={onClose} sx={{ marginTop: 2 }}>
            Close
          </Button>
        </Box>
      </Modal>
    </ThemeProvider>
  );
};

export default CPDataModal;
