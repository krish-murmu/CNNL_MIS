import React, { useEffect, useState } from "react";
import { Box, Button, Modal, ThemeProvider, Typography } from "@mui/material";
import { DataGrid, GridColDef, GridRowId } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import { format, parseISO } from "date-fns";
import { ContactPerson, CustomerDetails, WrapTextCellProps } from "types";
import axios from "axios";
import theme from "theme";
import SearchInput from "Components/SearchInput";
import AxiosInstance from "API/axios";

interface CustomerDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectedCustomer: (selectedCP: any) => void;
}

export const formatDate = (dateString: string | null) => {
  if (!dateString) {
    return "N/A"; // or some default value
  }

  const date = parseISO(dateString);
  return format(date, "M/dd/yyyy h:mm:ss a");
};

const CustomerDataModal: React.FC<CustomerDataModalProps> = ({
  isOpen,
  onClose,
  onSelectedCustomer,
}) => {
  const [CustomerDetailsData, setCustomerDetailsData] = useState<any>([]);
  const [searchValue, setSearchValue] = useState<string>("");

  const fetchPageData = async () => {
    try {
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/customer-details`
      );
      const data: CustomerDetails[] = response.data;
      setCustomerDetailsData(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchPageData();
    }
  }, [isOpen]);

  const columns: GridColDef[] = [
    { field: "Id", headerName: "ID", width: 50 },
    {
      field: "Customer_Name",
      headerName: "Customer Name",
      width: 150,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "Address_1",
      headerName: "Address",
      width: 250,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "City_Name",
      headerName: "City",
      width: 150,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "State_Name",
      headerName: "State",
      width: 150,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "Product_Name",
      headerName: "Product Name",
      width: 150,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
  ];

  const filteredCPData = CustomerDetailsData.filter((row: any) =>
    row.CP_Name.toLowerCase().includes(searchValue.toLowerCase())
  );

  const handleRowSelection = (rowSelectionModel: GridRowId[]) => {
    const selectedRowId =
      rowSelectionModel.length > 0 ? rowSelectionModel[0].toString() : null;

    const selectedData = selectedRowId
      ? CustomerDetailsData.find(
          (row: any) => row.Id === parseInt(selectedRowId, 10)
        )
      : null;

    // Ensure selectedData is not null before logging the whole row data
    if (selectedData !== null && selectedData !== undefined) {
      // Pass both selectedCity and selectedData to onSelectCity
      onSelectedCustomer(selectedData); // Change this line
    }
    onClose();
  };

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  return (
    <ThemeProvider theme={theme}>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "60%",
            maxWidth: "800px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,
            height: "90vh",
            maxHeight: "900px",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              backgroundColor: "#f0f0f0",
              padding: "16px",
              color: `${theme.palette.primary.main}`,
              fontWeight: "bold",
              marginBottom: "16px",
            }}
          >
            Customer Selection
          </Typography>

          <SearchInput
            value={searchValue}
            onChange={setSearchValue}
            placeholder="Search by customer name"
          />

          <Box sx={{ height: "400px" }}>
            <DataGrid
              columns={columns}
              rows={filteredCPData}
              
              getRowId={(row) => row.Id}
              checkboxSelection
              onRowSelectionModelChange={handleRowSelection}
            />
          </Box>
          <Button onClick={onClose} sx={{ marginTop: 2 }}>
            Close
          </Button>
        </Box>
      </Modal>
    </ThemeProvider>
  );
};

export default CustomerDataModal;
