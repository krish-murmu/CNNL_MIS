// CityDataModal.tsx
import React, { useState, useEffect } from "react";
import { Modal, Typography, ThemeProvider, Box, Button } from "@mui/material";
import { DataGrid, GridColDef, GridRowId, GridToolbar } from "@mui/x-data-grid";
import { BASE_API_URL } from "../API/Base";
import theme from "../theme";
import SearchInput from "Components/SearchInput";
import AxiosInstance from "API/axios";
import { CityOption } from "types";
import PaginationButtons from "Components/PaginationButtons";

interface CityDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCity: (selectedCity: any, selectedData: any) => void;
}

const CityDataModal: React.FC<CityDataModalProps> = ({
  isOpen,
  onClose,
  onSelectCity,
}) => {
  const [cityData, setCityData] = useState<any[]>([]);
  const [searchValue, setSearchValue] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [rowCount, setRowCount] = useState<number>(0);

  const columns: GridColDef[] = [
    { field: "Id", headerName: "City ID", flex: 1 },
    { field: "City_Name", headerName: "City", flex: 1 },
    {
      field: "Pin_Code",
      headerName: "Pin Code",
      flex: 1,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    { field: "State_Name", headerName: "State", flex: 1 },
  ];

  const filteredCityData = cityData.filter((city) =>
    city.City_Name.toLowerCase().includes(searchValue.toLowerCase())
  );

  useEffect(() => {
    const fetchCityData = async (page: number, pageSize: number) => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/v1/city`,
          {
            params: {
              page,
              per_page: pageSize,
            },
          }
        );

        if (
          !response.data ||
          !response.data.city_data ||
          response.data.total_count == null
        ) {
          console.error("Invalid response format:", response.data);

          return;
        }

        const formattedData = response.data.city_data.map(
          (row: CityOption, index: number) => ({
            ...row,
            actionsID: startIndex + index + 1,
            Id: row.Id,
          })
        );

        setCityData(formattedData);
        setRowCount(response.data.total_count);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching city data:", error);
        setLoading(false);
      }
    };

    if (isOpen) {
      fetchCityData(currentPage, pageSize);
    }
  }, [isOpen, currentPage, pageSize]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  const handleRowSelection = (rowSelectionModel: GridRowId[]) => {
    const selectedRowId =
      rowSelectionModel.length > 0 ? rowSelectionModel[0].toString() : null;

    const selectedData = selectedRowId
      ? cityData.find((row) => row.Id === parseInt(selectedRowId, 10))
      : null;

    // Ensure selectedData is not null before logging the whole row data
    if (selectedData !== null && selectedData !== undefined) {
      // Pass both selectedCity and selectedData to onSelectCity
      onSelectCity(selectedData, selectedData); // Change this line
    }
    onClose();
  };

  return (
    <ThemeProvider theme={theme}>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "30%",
            left: "50%",
            transform: "translate(-50%, -30%)",
            width: "60%",
            maxWidth: "800px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,

            height: "95vh",
            maxHeight: "900px",
          }}
        >
          <Typography
            variant="h5"
            sx={{
              backgroundColor: "#f0f0f0",
              padding: "14px",
              color: `${theme.palette.primary.main}`,
              fontWeight: "bold",
            }}
          >
            City Selection
          </Typography>

          <SearchInput
            value={searchValue}
            onChange={setSearchValue}
            placeholder="Search City"
          />

          <Box
          
            sx={{
              "& .MuiDataGrid-root": {
                border: "none",
                borderBottom: `2px solid ${theme.palette.secondary.light}`,
              },

              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: theme.palette.primary.main,
                borderBottom: "none",
                fontWeight: "bold",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                color: "#fff !important",
              },

              "& .MuiDataGrid-colCell": {
                color: `#fff !important`,
              },

              "& .MuiDataGrid-footerContainer": {
                display: "none",
              },
            }}
          >
            <DataGrid
              columns={columns}
              rows={filteredCityData}
              getRowId={(row) => row.Id}
              autoHeight
              loading={loading}
              onRowSelectionModelChange={handleRowSelection}
            />

            <PaginationButtons
              currentPage={currentPage}
              totalPages={totalPages}
              handlePageChange={handlePageChange}
            />
          </Box>
          <Button onClick={onClose} sx={{ mt: 4 }}>
            Close
          </Button>
        </Box>
      </Modal>
    </ThemeProvider>
  );
};

export default CityDataModal;
