import React, { useEffect, useState } from "react";
import { Box, Button, Modal, ThemeProvider, Typography } from "@mui/material";
import { DataGrid, GridColDef, GridRowId } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import axios from "axios";
import theme from "theme";
import { Address, WrapTextCellProps } from "types";
import SearchInput from "Components/SearchInput";
import AxiosInstance from "API/axios";

interface StateDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectedState: (selectedState: any) => void;
}

const StateDataModal: React.FC<StateDataModalProps> = ({
  isOpen,
  onClose,
  onSelectedState,
}) => {
  const [stateData, setStateData] = useState<any>([]);
  const [searchValue, setSearchValue] = useState<string>("");

  const fetchPageData = async () => {
    try {
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/state`
      );

      const data: Address[] = response.data;
      setStateData(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchPageData();
    }
  }, [isOpen]);

  const columns: GridColDef[] = [
    { field: "Id", headerName: "ID", flex: 1 },
    {
      field: "State_Name",
      headerName: "State",
      flex: 1,
    },
    { field: "Country_Name", headerName: "Country", flex: 1 },
  ];

  const handleRowSelection = (rowSelectionModel: GridRowId[]) => {
    const selectedRowId =
      rowSelectionModel.length > 0 ? rowSelectionModel[0].toString() : null;

    const selectedData = selectedRowId
      ? stateData.find((row: any) => row.Id === parseInt(selectedRowId, 10))
      : null;

    // Ensure selectedData is not null before logging the whole row data
    if (selectedData !== null && selectedData !== undefined) {
      // Pass both selectedCity and selectedData to onSelectCity
      onSelectedState(selectedData); // Change this line
    }
    onClose();
  };

  const filteredStateData = stateData.filter((state: any) =>
    state.State_Name.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <ThemeProvider theme={theme}>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "50%",
            maxWidth: "800px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 2,
            height: "90vh",
            maxHeight: "800px",
          }}
        >
          <Typography
            variant="h5"
            sx={{
              backgroundColor: "#f0f0f0",
              padding: "16px",
              color: `${theme.palette.primary.main}`,
              fontWeight: "600",
            }}
          >
            State Selection
          </Typography>

          <SearchInput
            value={searchValue}
            onChange={setSearchValue}
            placeholder="Search State"
          />
          <Box sx={{ height: "350px" }}>
            <DataGrid
              columns={columns}
              rows={filteredStateData}
              // autoHeight
              getRowId={(row) => row.Id}
              pagination
              pageSizeOptions={[5, 10, 25, 100]}
              onRowSelectionModelChange={handleRowSelection}
            />
          </Box>
          <Button onClick={onClose} sx={{ mt: 1 }}>
            Close
          </Button>
        </Box>
      </Modal>
    </ThemeProvider>
  );
};

export default StateDataModal;
