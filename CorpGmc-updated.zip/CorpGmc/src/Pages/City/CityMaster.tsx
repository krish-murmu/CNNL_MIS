import { Button } from "@mui/material";
import { Box } from "@mui/system";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import theme from "theme";
import { CityOption } from "types";
import { DataGrid, GridColDef, DataGridProps } from "@mui/x-data-grid";
import { usePermission } from "Components/ActionPermission";
import toast from "react-hot-toast";
import DeleteModal from "Modals/DeleteModal";
import PaginationButtons from "Components/PaginationButtons";
import { usePagePermissions } from "Components/PagePermissions";
import { AddBox, Delete, EditNote, MenuBook } from "@mui/icons-material";

const CityMaster: React.FC = () => {
  const [rows, setRows] = useState<CityOption[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [rowCount, setRowCount] = useState<number>(0);

  const navigate = useNavigate();

  // Fetch permissions for Address module
  const permissions = usePagePermissions("City");

  // Base64 decoding function
  function base64Decode(encodedStr: string) {
    return atob(encodedStr);
  }

  function base64Encode(str: string) {
    return btoa(str);
  }

  const fetchData = async (page: number, pageSize: number) => {
    try {
      setLoading(true);

      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/city`,
        {
          params: {
            page,
            per_page: pageSize,
          },
        }
      );

      if (
        !response.data ||
        !response.data.city_data ||
        response.data.total_count == null
      ) {
        console.error("Invalid response format:", response.data);

        return;
      }

      const formattedData = response.data.city_data.map(
        (row: CityOption, index: number) => ({
          ...row,
          actionsID: startIndex + index + 1,
          Id: row.Id,
        })
      );

      setRows(formattedData);
      setRowCount(response.data.total_count);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (permissions.List) {
      fetchData(currentPage, pageSize);
    }
  }, [currentPage, pageSize, permissions]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(currentPage * pageSize, rowCount);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  // Conditionally define the Action column based on permissions
  const actionColumn =
    permissions?.Update || permissions?.Delete || permissions?.View
      ? {
          field: "action",
          headerName: "Action",
          width: 260,
          renderCell: (params: any) => (
            <div className="cellAction">
              {permissions?.Update && (
                <div
                  className="editButton"
                  onClick={() => handleEdit(params.row)}
                >
                  <EditNote sx={{ fontSize: "20px" }} />
                </div>
              )}
              {permissions?.Delete && (
                <div
                  className="deleteButton"
                  onClick={() => handleDelete(params.row.Id)}
                >
                  <Delete sx={{ fontSize: "20px" }} />
                </div>
              )}
              {permissions?.View && (
                <div
                  className="viewButton"
                  onClick={() => handleView(params.row)}
                >
                  <MenuBook sx={{ fontSize: "20px" }} />
                </div>
              )}
            </div>
          ),
        }
      : undefined;

  const columns: GridColDef[] = [
    {
      field: "actionsID",
      headerName: "ID",
      width: 100,
    },

    ...(actionColumn ? [actionColumn] : []),

    {
      field: "City_Name",
      headerName: "City",
      width: 200,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "Pin_Code",
      headerName: "Pincode",
      width: 200,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },

    {
      field: "State_Name",
      headerName: "State",
      width: 200,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
  ];

  const handleAdd = () => {
    navigate("/city/form/create");
  };

  const handleView = (row: any) => {
    const encodedId = base64Encode(row.Id);

    navigate(`/city/form/view/${encodedId}`);
  };

  const handleEdit = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/city/form/edit/${encodedId}`);
  };

  const handleDelete = (id: string) => {
    const encodedId = base64Encode(id);
    setIsDeleteModalOpen(true);
    setSelectedRowId(encodedId);
  };

  const handleDeleteCancel = () => {
    setIsDeleteModalOpen(false);
  };

  // Function to handle confirming the delete operation
  const handleDeleteConfirm = async () => {
    try {
      const decodedId = selectedRowId ? base64Decode(selectedRowId) : null;

      // Delete the item
      await AxiosInstance.delete(`${BASE_API_URL}/admin/v1/city/${decodedId}`);

      // Update the state by removing the deleted item
      setRows((prevRows) =>
        prevRows.filter((row: any) => row.Id.toString() !== decodedId)
      );

      setIsDeleteModalOpen(false);
      setLoading(false); // Set loading to false

      toast.success("Data deleted successfully!");
    } catch (error) {
      console.error("Error deleting data:", error);
      setIsDeleteModalOpen(false);
      setLoading(false); // Set loading to false
      toast.error("Error deleting data");
    }
  };

  return (
    <Layout>
      <div className="datatable">
        <div className="datatableTitle">
          <Header title="City Master" subtitle="" />
          <div className="flex space-x-2">
            {permissions?.Add && (
              <Button className="link" onClick={handleAdd}>
                <AddBox sx={{ fontSize: "40px" }} />
              </Button>
            )}
          </div>
        </div>

        <Box
          width={"1100px"}
          margin={"auto"}
          sx={{
            "& .MuiDataGrid-root": {
              border: "none",
              borderBottom: `2px solid ${theme.palette.secondary.light}`,
            },

            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: theme.palette.primary.main,
              borderBottom: "none",
              fontWeight: "bold",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              color: "#fff !important",
            },

            "& .MuiDataGrid-colCell": {
              color: `#fff !important`,
            },

            "& .MuiDataGrid-footerContainer": {
              display: "none",
            },
          }}
        >
          <DataGrid
            rows={rows}
            columns={columns}
            getRowId={(row) => row.Id}
            autoHeight
            loading={loading}
          />
        </Box>

        <PaginationButtons
          currentPage={currentPage}
          totalPages={totalPages}
          handlePageChange={handlePageChange}
        />
      </div>
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        title="Confirm Deletion"
        message="Are you sure you want to delete this data?"
      />
    </Layout>
  );
};

export default CityMaster;
