import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import toast from "react-hot-toast";
import { Button, CircularProgress, Grid, TextField } from "@mui/material";
import { Box } from "@mui/system";
import { BASE_API_URL } from "API/Base";
import { CRUDFormPageProps } from "types";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import StateDataModal from "Modals/StateDataModal";
import theme from "theme";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [isAddStateModalOpen, setIsAddStateModalOpen] =
    useState<boolean>(false);
  const [editedValues, setEditedValues] = useState<any>({});
  const [selectedState, setSelectedState] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [formData, setFormData] = useState({
    Id: "",
    City_Name: "",
    Pin_Code: "",
    State_Id: "",
  });
  const [errors, setErrors] = useState({
    City_Name: "",
    Pin_Code: "",
    State_Id: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);

      setFormData({
        Id: data.Id,
        City_Name: data.City_Name,
        Pin_Code: data.Pin_Code,
        State_Id: data.State_Id,
      });

      setSelectedState(data.State_Name);
    }
  }, [mode, data]);

  // Callback function when an address is selected in the modal
  const handleSelectedAddress = (selectedState: any) => {
    setIsAddStateModalOpen(false);
    setSelectedState(selectedState);
    handleInputChange("State_Id", selectedState.Id);
  };

  const handleInputChange = (field: string, value: string | any) => {
    if (typeof value === "object" && value !== null) {
      // Handle the case when a value is selected from the modal
      setFormData((prevData) => ({
        ...prevData,
        [field]: value.Id, // Assuming the selected value has an 'Id' property
      }));

      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [field]: value,
      }));
    } else {
      // Handle the case when the value is directly entered in the input field
      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [field]: value,
      }));
    }
  };

  //   The valid pin code of India must satisfy the following conditions.

  // It can be only six digits.
  // It should not start with zero.
  // First digit of the pin code must be from 1 to 9.
  // Next five digits of the pin code may range from 0 to 9.
  // It should allow only one white space, but after three digits, although this is optional
  const validateForm = () => {
    let isValid = true;
    const newErrors = {
      City_Name: "",
      Pin_Code: "",
      State_Id: "",
    };

    if (!formData.City_Name.trim()) {
      newErrors.City_Name = "City Name is required";
      isValid = false;
    } else if (!/^[A-Za-z\s-]+$/.test(formData.City_Name.trim())) {
      newErrors.City_Name = "Invalid characters in City Name";
      isValid = false;
    }

    if (!formData.Pin_Code.trim()) {
      newErrors.Pin_Code = "Pin Code is required";
      isValid = false;
    } else if (!/^[1-9]\d{2}\s?\d{3}$/.test(formData.Pin_Code.trim())) {
      newErrors.Pin_Code = "Invalid Pin Code";
      isValid = false;
    }

    if (!formData.State_Id) {
      newErrors.State_Id = "State is required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };
  const handleSubmit = async () => {
    try {
      // Reset formErrors before validation
      setErrors({
        City_Name: "",
        Pin_Code: "",
        State_Id: "",
      });

      setLoading(true);
      // Perform form validation
      if (!validateForm()) {
        return;
      }

      if (mode === "create") {
        const data = {
          City_Name: formData.City_Name,
          Pin_Code: formData.Pin_Code,
          State_Id: formData.State_Id,
        };

        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/v1/city`,
          data
        );

        if (response.data) {
          toast.success("City created successfully");
          setFormData({
            Id: "",
            City_Name: "",
            Pin_Code: "",
            State_Id: selectedState?.Id || "",
          });
        }
      } else if (mode === "edit") {
        const data = {
          City_Name: editedValues.City_Name,
          Pin_Code: editedValues.Pin_Code,
          State_Id: editedValues.State_Id,
        };

        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/v1/city/${editedValues.Id}`,
          data
        );

        if (response.data) {
          toast.success("City updated successfully");
        }
      }
    } catch (error: any) {
      if (error.response) {
        toast.error("Error response details", error.response.data);
        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        } else {
          toast.error("Server Error");
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <StateDataModal
        isOpen={isAddStateModalOpen}
        onClose={() => {
          setIsAddStateModalOpen(false);
        }}
        onSelectedState={handleSelectedAddress}
      />
      {loading && (
        <Box
          sx={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <CircularProgress size={50} />
        </Box>
      )}
      <Box sx={{ width: "80%", margin: "50px auto" }}>
        <Header
          title={
            mode === "view"
              ? "View city details"
              : mode === "edit"
              ? "Edit city details"
              : mode === "create"
              ? "Create new city "
              : ""
          }
          subtitle={""}
        />

        <Grid container spacing={2}>
          {mode === "create" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="City Name"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  value={formData.City_Name}
                  onChange={(e) =>
                    handleInputChange("City_Name", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.City_Name}
                  helperText={errors.City_Name}
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Pincode"
                  variant="outlined"
                  fullWidth
                  required
                  value={formData.Pin_Code}
                  onChange={(e) =>
                    handleInputChange("Pin_Code", e.target.value)
                  }
                  margin="normal"
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Pin_Code}
                  helperText={errors.Pin_Code}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="State"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  value={selectedState?.State_Name || ""}
                  onChange={(e) =>
                    handleInputChange("State_Id", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  onClick={() => setIsAddStateModalOpen(true)}
                  error={!!errors.State_Id}
                  helperText={errors.State_Id}
                />
              </Grid>
            </>
          )}
          {mode === "view" && (
            <>
              <Grid container spacing={2}>
                {fields.map(({ label, key, type }) => (
                  <Grid item xs={6} key={key}>
                    <TextField
                      key={key}
                      label={label}
                      variant="outlined"
                      fullWidth
                      margin="normal"
                      value={data[key] || ""}
                      sx={{ marginBottom: "16px" }}
                    />
                  </Grid>
                ))}
              </Grid>
            </>
          )}
          {mode === "edit" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="City Name"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.City_Name || " "}
                  onChange={(e) =>
                    handleInputChange("City_Name", e.target.value)
                  }
                  error={!!errors.City_Name}
                  helperText={errors.City_Name}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Pincode"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Pin_Code || " "}
                  onChange={(e) =>
                    handleInputChange("Pin_Code", e.target.value)
                  }
                  error={!!errors.Pin_Code}
                  helperText={errors.Pin_Code}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="State"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  onClick={() => setIsAddStateModalOpen(true)}
                  value={selectedState?.State_Name || data?.State_Name || ""}
                  onChange={(e) =>
                    handleInputChange("State_Id", e.target.value)
                  }
                  error={!!errors.State_Id}
                  helperText={errors.State_Id}
                />
              </Grid>
            </>
          )}
        </Grid>

        <Box mt={2} display="flex" justifyContent="space-between">
          {mode === "create" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "#fff" }}
            >
              {" "}
              Create{" "}
            </Button>
          )}
          {mode === "edit" && (
            <Button
              variant="contained"
              color="primary"
              sx={{ color: "#fff" }}
              onClick={handleSubmit}
            >
              {" "}
              Save Changes{" "}
            </Button>
          )}
          <Button
            variant="outlined"
            sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            onClick={() => navigate("/city")}
          >
            Back
          </Button>
        </Box>
      </Box>
    </Layout>
  );
};

export default CRUDForm;
