import { Button } from "@mui/material";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Layout from "Components/Layout";
import LoadingAnimation from "Components/LoadingAnimation";
import React, { useEffect, useState } from "react";

type Props = {};

function TestPage({}: Props) {
  const [dataArrived, setDataArrived] = useState<boolean>(false);

  useEffect(() => {
    // Simulate data arrival after a delay
    setTimeout(() => {
      setDataArrived(true);
    }, 1000);
  }, []);

  const handleDownload = () => {
    AxiosInstance({
      url: `${BASE_API_URL}/admin/quotes/gmc-quote/download-excel`,
      method: "GET",
      responseType: "blob",
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "file.xlsx");
        document.body.appendChild(link);
        link.click();

        // Check if parentNode is not null before removing the child
        if (link.parentNode) {
          link.parentNode.removeChild(link);
        }

        window.URL.revokeObjectURL(url);
      })
      .catch((error) => {
        console.error("Error downloading the file", error);
      });
  };
  return (
    <Layout>
      <div className="flex flex-row items-center justify-center w-full h-full">
        {!dataArrived ? ( // Display loading animation if data hasn't arrived
          <LoadingAnimation />
        ) : (
          <div className="flex flex-col items-center justify-center w-full h-full">
            {/* Your content when data has arrived */}
            <h1>Data has arrived!</h1>
            <Button variant="contained" onClick={handleDownload}>
              Download Excel File
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}

export default TestPage;
