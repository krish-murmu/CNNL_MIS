// AddressForm.tsx
import React, { useEffect, useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import {
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import axios from "axios";
import { BASE_API_URL } from "../../../API/Base";
import toast, { Toaster } from "react-hot-toast";
import DataTableModal from "./DataTableModal";
import { SelectChangeEvent } from "@mui/material";

interface FormData {
  Address: string;
  city: string;
}

type CityOption = {
  Id: number;
  State_Id: number;
  Name: string;
};

type AddressOption = {
  Id: number;
  Address_1: string;
  City_Id: number; // Add this property
};

const AddressForm: React.FC = () => {
  const {
    register,
    handleSubmit,
    setValue, // Add this line to get the setValue function
    formState: { errors },
  } = useForm<FormData>();
  const [address, setAddress] = useState<AddressOption[]>([]);
  const [cities, setCities] = useState<CityOption[]>([]);
  const [selectedRow, setSelectedRow] = useState<AddressOption | null>(null);
  const [isAddCityModalOpen, setAddCityModalOpen] = useState(false);
  const [isDataTableModalOpen, setDataTableModalOpen] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<string | null>(null);
  const [selectedCityId, setSelectedCityId] = useState<number | null>(null);
  const [stateIds, setStateIds] = useState<number[]>([]);

  const handleDataTableModalOpen = () => {
    setDataTableModalOpen(true);
  };

  const handleRowSelect = (
    selectedRowId: string | null,
    selectedData: AddressOption | null
  ) => {
    setSelectedRow(selectedData);

    // Set the selected address data to the state
    setSelectedAddress(selectedData?.Address_1 || null);
    console.log("selected row id:", selectedRowId);
    console.log("Selected address:", selectedData?.Address_1);
  };
  const fetchAddressOptions = async () => {
    try {
      const response = await axios(`${BASE_API_URL}/admin/v1/address-details`);

      if (Array.isArray(response.data)) {
        const uniqueAddresses = response.data.map((address: AddressOption) => ({
          Id: address.Id,
          Address_1: address.Address_1,
          City_Id: address.City_Id, // Include the actual City_Id from the API
        }));

        setAddress(uniqueAddresses);
      } else {
        console.error("Invalid data format received from the API");
      }
    } catch (error) {
      console.error("Error fetching addresses:", error);
    }
  };
  useEffect(() => {
    const fetchCityOptions = async () => {
      try {
        const response = await axios(`${BASE_API_URL}/admin/v1/city`);

        if (Array.isArray(response.data)) {
          const uniqueCities = response.data.map((city: CityOption) => ({
            Id: city.Id, // Include the Id property
            State_Id: city.State_Id,
            Name: city.Name,
          }));

          // Extract State_Ids from the response
          const uniqueStateIdsFromResponse = Array.from(
            new Set(response.data.map((city: CityOption) => city.State_Id))
          );

          setCities(uniqueCities);
          setStateIds(uniqueStateIdsFromResponse);
        } else {
          console.error("Invalid data format received from the API");
        }
      } catch (error) {
        console.error("Error fetching cities:", error);
      }
    };

    fetchAddressOptions();
    fetchCityOptions();
  }, []);

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    try {
      const completeData = {
        Address_1: data.Address,
        City_Id: selectedCityId,
        Created_By: 1,
        Created_On: "2024-01-03 07:25:50",
        Modify_By: 1,
        Modify_On: "2024-01-03 07:25:50",
      };

      console.log("Submitted data:", completeData);
      const url = `${BASE_API_URL}/admin/v1/address-details`;
      const response = await axios.post(url, completeData);

      // Check for a successful response (status codes 2xx)
      if (response.status >= 200 && response.status < 300) {
        console.log("Data submitted successfully");
        setTimeout(() => {
          toast.success("Data submitted successfully");
        }, 0);
        // Handle success, e.g., redirect or show a success message
      } else if (response.status === 409) {
        // Check if the status is 409 (Conflict) for duplicacy
        console.log("Error submitting data - Address already exists");
        setTimeout(() => {
          toast.error("Error submitting data - Address already exists");
        }, 0);
        // Handle duplicacy error, e.g., show a specific message to the user
      } else {
        // Handle other errors
        console.log(`Error submitting data - Status: ${response.status}`);
        setTimeout(() => {
          toast.error("Error submitting data - Please try again");
        }, 0);
        // Handle other errors, e.g., show a generic error message to the user
      }
    } catch (error) {
      console.error("Error submitting data:", error);
      setTimeout(() => {
        toast.error("Error submitting data - Please try again");
      }, 0);
      // Handle unexpected error, e.g., show an error message to the user
    }
  };

  const handleAddAddress = (newAddress: AddressOption) => {
    setAddress((prevAddresses) => [...prevAddresses, newAddress]);
  };
  const handleSelectChange = (e: SelectChangeEvent<number>) => {
    const selectedValue = e.target.value;
    // Handle the select change here
    // For example, update some state based on the selected value
    // You might want to add your logic here
  };

  return (
    <div>
      <form
        onSubmit={handleSubmit(onSubmit)}
        style={{
          padding: "20px",
          borderRadius: "8px",
          backgroundColor: "white",
          width: "300px",
          margin: "auto",
          marginTop: "20px",
        }}
      >
        

        <FormControl fullWidth sx={{ mb: 4 }} error={!!errors.city}>
          <TextField
            placeholder="Select your address"
            value={selectedAddress || ""}
            onClick={handleDataTableModalOpen}
            onChange={(e) => setSelectedAddress(e.target.value)}
          />
        </FormControl>

        <Button variant="contained" color="primary" type="submit" fullWidth>
          Submit
        </Button>
      </form>

      <DataTableModal
        isOpen={isDataTableModalOpen}
        onClose={() => setDataTableModalOpen(false)}
        data={address}
        cities={cities}
        fetchAddressOptions={fetchAddressOptions}
        onRowSelect={handleRowSelect}
      />
      <Toaster />
    </div>
  );
};

export default AddressForm;
