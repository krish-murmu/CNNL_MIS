import React, { useState } from "react";
import { Modal, Typography, IconButton, Box, TextField } from "@mui/material";
import { DataGrid, GridRowId, GridToolbar } from "@mui/x-data-grid";
import { AddBox } from "@mui/icons-material";
import AddAddressModal from "./AddAddressModal";

interface DataTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: AddressOption[];
  cities: CityOption[];
  fetchAddressOptions: () => Promise<void>;
  onRowSelect: (
    selectedRowId: string | null,
    selectedData: AddressOption | null
  ) => void;
}

interface AddressOption {
  Id: number;
  Address_1: string;
  City_Id: number;
}

type CityOption = {
  Id: number;
  State_Id: number;
  Name: string;
};

const DataTableModal: React.FC<DataTableModalProps> = ({
  isOpen,
  onClose,
  data,
  cities,
  fetchAddressOptions,
  onRowSelect,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isAddAddressModalOpen, setAddAddressModalOpen] = useState(false);

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value);
  };

  const handleAddressAdded = async () => {
    await fetchAddressOptions();
  };

  const filteredData = data.filter((row) =>
    Object.values(row).some((value) =>
      value.toString().toLowerCase().includes(searchQuery.toLowerCase())
    )
  );
  const handleRowSelection = (rowSelectionModel: GridRowId[]) => {
    const selectedRowId =
      rowSelectionModel.length > 0 ? rowSelectionModel[0].toString() : null;

    console.log(selectedRowId);

    const selectedData = selectedRowId
      ? data.find((row) => row.Id === parseInt(selectedRowId, 10))
      : null;

    // Ensure selectedData is not undefined before calling onRowSelect
    if (selectedData !== undefined) {
      // Pass both the selected row ID and the entire selected row data
      onRowSelect(selectedRowId, selectedData);
    }
    onClose();
  };

  const columns = [
    { field: "Id", headerName: "ID", width: 150 },
    { field: "City_Id", headerName: "City ID", width: 150 },
    { field: "Address_1", headerName: "Address", width: 250 },
  ];

  const getRowId = (row: AddressOption) => row.Id;

  return (
    <div>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "700px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography variant="h6" id="modal-title" sx={{ p: 2 }}>
            Address List
          </Typography>
          <IconButton
            edge="end"
            color="inherit"
            onClick={onClose}
            aria-label="close"
            sx={{ position: "absolute", top: 0, right: 0 }}
          ></IconButton>
          <Box sx={{ display: "flex", justifyContent: "space-between" }}>
            <TextField
              label="Search"
              variant="outlined"
              value={searchQuery}
              size="small"
              onChange={handleSearchChange}
              sx={{ mb: 2 }}
            />

            <AddBox
              fontSize="large"
              onClick={() => setAddAddressModalOpen(true)}
              sx={{ color: "teal", cursor: "pointer" }}
            />
          </Box>
          <div style={{ height: 400, width: "100%" }}>
            <DataGrid
              rows={filteredData}
              columns={columns}
              pagination
              autoHeight
              components={{
                Toolbar: GridToolbar,
              }}
              pageSizeOptions={[10, 25, 50, 100]}
              checkboxSelection
              getRowId={getRowId}
              onRowSelectionModelChange={handleRowSelection}
            />
          </div>
        </Box>
      </Modal>

      <AddAddressModal
        isOpen={isAddAddressModalOpen}
        onClose={() => setAddAddressModalOpen(false)}
        onAddressAdded={handleAddressAdded}
        data={data}
        cities={cities}
      />
    </div>
  );
};

export default DataTableModal;
