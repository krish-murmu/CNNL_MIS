import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { ContactPerson, UnifiedFormParams } from "types";
import { BASE_API_URL } from "API/Base";
import CRUDForm from "./CRUDForm";
import AxiosInstance from "API/axios";

const CPUnifiedForm = () => {
  const { mode, id } = useParams<UnifiedFormParams>();
  const [apiData, setApiData] = useState<any>([]);

  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };

  const decodedId = id ? base64Decode(id) : null;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/v1/contact-person/${decodedId}`
        );
        const data: ContactPerson = response.data;

        setApiData(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (mode !== "create") {
      fetchData();
    }
  }, [mode, id]);

  const createFields =
    mode === "create"
      ? [
          { label: "City", key: "City_Id", type: "modal" },
          { label: "Address", key: "Address_1" },
        ]
      : apiData
      ? Object.keys(apiData)
          .filter(
            (key) =>
              ![
                "Id",
                "Action_Id",
                "Module_Id",
                "IsStatus",
                "Sub_Module_Id",
                "Created_By",
                "Created_On",
                "Modify_By",
                "Modify_On",
                "Created_By_User_NAME",
                "Modify_By_User_NAME",
              ].includes(key)
          )
          .map((key) => ({ label: key, key }))
      : [];

  return (
    <div>
      {mode && (
        <>
          <CRUDForm mode={mode} data={apiData} fields={createFields} />
        </>
      )}
    </div>
  );
};

export default CPUnifiedForm;
