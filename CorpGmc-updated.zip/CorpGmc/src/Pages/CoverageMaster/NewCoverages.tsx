import {
  Button,
  FormControl,
  InputLabel,
  Menu,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { Controller, Form, SubmitHandler, useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";

type Props = {};

interface Coverages {
  Id: number;
  Coverage_Name: string;
  Coverage_Detail: string;
  Coverage_Type: string;
  Parent_Coverage_Id: string;
}

interface CoverageInput {
  Coverage_Name: string;
  Input_Type: string;
  Coverage_Detail: string;
  Parent_Coverage: number;
}

function NewCoverages({}: Props) {
  const navigator = useNavigate();
  const [Loading, setLoading] = useState<boolean>(true);
  const [Coverages, setCoverages] = useState<Coverages[]>([]);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<CoverageInput>();

  const onSubmit: SubmitHandler<CoverageInput> = async (inputs) => {
    try {
      // if (inputs.Parent_Coverage != 0) {
      //   const parentname = Coverages.filter(
      //     (coverage) => coverage.Id == inputs.Parent_Coverage
      //   )[0].Coverage_Name;
      //   inputs.Coverage_Name = `${parentname} - ${inputs.Coverage_Name}`;
      // }
      const data: CoverageInput = {
        Coverage_Name: inputs.Coverage_Name,
        Coverage_Detail: inputs.Coverage_Detail,
        Input_Type: inputs.Input_Type,
        Parent_Coverage: inputs.Parent_Coverage,
      };

      const res = await AxiosInstance.post(
        `${BASE_API_URL}/admin/coverages/v1/add-new/coverage`,
        data
      );
      if (res.status === 200) {
        toast.success("Coverage Added Successfully");
        navigator("/coverages/manage");
      }
    } catch (e) {
      console.log(e);
      toast.error("Something Went Wrong");
    }
  };

  const fetchCoverages = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/coverages/v1/get-coverages`
      );
      const data: Coverages[] = res.data;
      setCoverages(data);
      setLoading(false);
      console.log("coverages", Coverages);
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoverages();
  }, []);

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center p-8">
        <div className="flex flex-row items-center justify-start w-full">
          <Header title="Add New Coverage" subtitle="" />
        </div>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col items-start w-full justify-normal"
        >
          <div className="flex flex-row items-center justify-start w-full mt-8 gap-x-8">
            <div className="flex flex-row items-center w-1/3">
              <Controller
                name="Coverage_Name"
                control={control}
                defaultValue=""
                rules={{ required: true }}
                render={({ field }) => (
                  <TextField
                    type="text"
                    error={Boolean(errors.Coverage_Name)}
                    label="Coverage Name"
                    className="w-full p-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-0"
                    placeholder="Coverage Name"
                    {...field}
                  />
                )}
              />
            </div>
            <div className="flex flex-row items-center w-1/3 mb-2">
              <FormControl fullWidth margin="normal" variant="outlined">
                <InputLabel>Parent Coverage</InputLabel>
                <Controller
                  name="Parent_Coverage"
                  control={control}
                  rules={{ required: true }}
                  defaultValue={0}
                  render={({ field }) => (
                    <Select
                      placeholder="Parent Coverage"
                      error={Boolean(errors.Parent_Coverage)}
                      className="w-full"
                      defaultValue={null}
                      label="Parent Coverage"
                      {...field}
                    >
                      <MenuItem value={0}>No Parent</MenuItem>
                      {Coverages.filter(
                        (coverage) => coverage.Parent_Coverage_Id == "0"
                      ).map((coverage) => (
                        <MenuItem key={coverage.Id} value={coverage.Id}>
                          {coverage.Coverage_Name}
                        </MenuItem>
                      ))}
                    </Select>
                  )}
                />
              </FormControl>
            </div>
            <div className="flex flex-row items-center w-1/3 mb-2">
              <FormControl fullWidth margin="normal" variant="outlined">
                <InputLabel>Input Type</InputLabel>
                <Controller
                  name="Input_Type"
                  control={control}
                  defaultValue=""
                  rules={{ required: true }}
                  render={({ field }) => (
                    <Select
                      placeholder="Input Type"
                      className="w-full"
                      label="Input Type"
                      error={Boolean(errors.Input_Type)}
                      {...field}
                    >
                      <MenuItem value="Boolean">Checbox</MenuItem>
                      <MenuItem value="Input">Input</MenuItem>
                    </Select>
                  )}
                />
              </FormControl>
            </div>
          </div>
          <div className="flex flex-row items-center justify-start w-full mt-8 gap-x-8">
            <div className="flex flex-row items-center w-1/2">
              <Controller
                name="Coverage_Detail"
                control={control}
                defaultValue=""
                rules={{ required: true, maxLength: 80 }}
                render={({ field }) => (
                  <TextField
                    type="text"
                    error={Boolean(errors.Coverage_Detail)}
                    multiline={true}
                    rows={4}
                    label="Coverage Details"
                    className="w-full p-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-0"
                    placeholder="Coverage Details (Max 80 Characters)"
                    {...field}
                  />
                )}
              />
            </div>
          </div>
          <div className="flex flex-row items-center justify-start w-full h-12 mt-8 gap-x-8">
            <Button type="submit" className="w-1/3 h-full" variant="contained">
              <span className="text-white">Submit</span>
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
}

export default NewCoverages;
