import {
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { Controller, Form, SubmitHandler, useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { useNavigate, useParams } from "react-router";

type Props = {};

interface Coverages {
  Id: number;
  Coverage_Name: string;
  Coverage_Detail: string;
  Coverage_Type: string;
  Parent_Coverage_Id: number;
}

function CoverageView({}: Props) {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [Coverage, setCoverage] = useState<Coverages>();
  const [loading, setLoading] = useState<boolean>(true);
  const [AllCoverages, setAllCoverages] = useState<Coverages[]>([]);

  const fetchCoverages = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/coverages/v1/get-coverages`
      );
      const data: Coverages[] = res.data;
      setAllCoverages(data);
      setLoading(false);
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };
  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<Coverages>();

  const fetch_coverage_details = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/coverages/v1/get-coverage/${id}`
      );
      const data: Coverages = res.data;
      setCoverage(data);
      console.log(data);
    } catch (error) {
      toast.error("Error Fetching Data");
      console.log(error);
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      await fetchCoverages();
      await fetch_coverage_details();
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (Coverage) {
      // Populate the form with existing data
      reset({
        Id: Coverage.Id,
        Coverage_Name: Coverage.Coverage_Name,
        Parent_Coverage_Id: Coverage.Parent_Coverage_Id,
        Coverage_Type: Coverage.Coverage_Type,
        Coverage_Detail: Coverage.Coverage_Detail,
      });
    }
  }, [Coverage, reset]);

  return (
    <Layout>
      <div className="flex flex-col w-full h-full px-8 pt-8">
        <div className="flex flex-row items-center justify-start w-full">
          <Header
            title="View Coverage"
            subtitle={Coverage?.Coverage_Name as string}
          />
        </div>
        <form className="flex flex-col items-start w-full justify-normal">
          <div className="flex flex-row items-center justify-start w-full mt-8 gap-x-8">
            <div className="flex flex-row items-center w-1/3">
              <Controller
                name="Id"
                control={control}
                disabled={true}
                rules={{ required: true }}
                render={({ field }) => (
                  <TextField
                    disabled={true}
                    type="number"
                    error={Boolean(errors.Id)}
                    defaultValue={Coverage?.Id}
                    className="w-full p-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-0"
                    {...field}
                  />
                )}
              />
            </div>
            <div className="flex flex-row items-center w-1/3">
              <Controller
                name="Coverage_Name"
                control={control}
                disabled={true}
                defaultValue=""
                rules={{ required: true }}
                render={({ field }) => (
                  <TextField
                    type="text"
                    error={Boolean(errors.Coverage_Name)}
                    label="Coverage Name"
                    className="w-full p-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-0"
                    placeholder="Coverage Name"
                    {...field}
                  />
                )}
              />
            </div>
            <div className="flex flex-row items-center w-1/3 mb-2">
              <FormControl fullWidth margin="normal" variant="outlined">
                <InputLabel>Parent Coverage</InputLabel>
                <Controller
                  name="Parent_Coverage_Id"
                  control={control}
                  disabled={true}
                  rules={{ required: true }}
                  defaultValue={0}
                  render={({ field }) => (
                    <Select
                      placeholder="Parent Coverage"
                      error={Boolean(errors.Parent_Coverage_Id)}
                      className="w-full"
                      defaultValue={null}
                      label="Parent Coverage"
                      {...field}
                    >
                      <MenuItem value={0}>No Parent</MenuItem>
                      {AllCoverages.filter(
                        (coverage) => coverage.Parent_Coverage_Id == 0
                      ).map((coverage) => (
                        <MenuItem key={coverage.Id} value={coverage.Id}>
                          {coverage.Coverage_Name}
                        </MenuItem>
                      ))}
                    </Select>
                  )}
                />
              </FormControl>
            </div>
            <div className="flex flex-row items-center w-1/3 mb-2">
              <FormControl fullWidth margin="normal" variant="outlined">
                <InputLabel>Input Type</InputLabel>
                <Controller
                  name="Coverage_Type"
                  control={control}
                  disabled={true}
                  defaultValue=""
                  rules={{ required: true }}
                  render={({ field }) => (
                    <Select
                      placeholder="Input Type"
                      className="w-full"
                      label="Input Type"
                      error={Boolean(errors.Coverage_Type)}
                      {...field}
                    >
                      <MenuItem value="Boolean">Checbox</MenuItem>
                      <MenuItem value="Input">Input</MenuItem>
                    </Select>
                  )}
                />
              </FormControl>
            </div>
          </div>
          <div className="flex flex-row items-center justify-start w-full mt-8 gap-x-8">
            <div className="flex flex-row items-center w-1/2">
              <Controller
                name="Coverage_Detail"
                control={control}
                disabled={true}
                defaultValue=""
                rules={{ required: true, maxLength: 80 }}
                render={({ field }) => (
                  <TextField
                    type="text"
                    error={Boolean(errors.Coverage_Detail)}
                    multiline={true}
                    rows={4}
                    label="Coverage Details"
                    className="w-full p-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-0"
                    placeholder="Coverage Details (Max 80 Characters)"
                    {...field}
                  />
                )}
              />
            </div>
          </div>
        </form>
      </div>
    </Layout>
  );
}

export default CoverageView;
