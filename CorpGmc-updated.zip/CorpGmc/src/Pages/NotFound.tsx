import Layout from "Components/Layout";
import React from "react";
import notfound from "../assets/undraw_Page_not_found_re_e9o6.png";
type Props = {};

function NotFound({}: Props) {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-start w-full h-full pt-8">
        <div className="flex flex-row justify-center w-2/3 h-1/2">
          <img src={notfound} alt="" />
        </div>
        <div className="flex flex-col items-center justify-center w-1/3">
          <h1 className="text-3xl font-semibold text-primary">
            Page Not Found
          </h1>
          <h3 className="text-2xl font-semibold text-primary">
            The page you are looking for does not exist
          </h3>
        </div>
      </div>
    </Layout>
  );
}

export default NotFound;
