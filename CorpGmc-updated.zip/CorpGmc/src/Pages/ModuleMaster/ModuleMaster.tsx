import { AddBox, Delete, EditNote, MenuBook } from "@mui/icons-material";
import { Box, Button } from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import PaginationButtons from "Components/PaginationButtons";
import DeleteModal from "Modals/DeleteModal";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";
import theme from "theme";
import { Module, WrapTextCellProps } from "types";

const ModuleMaster = () => {
  const [rows, setRows] = useState<Module[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [rowCount, setRowCount] = useState<number>(0);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async (page: number, pageSize: number) => {
      try {
        setLoading(true);
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/modules/v1/modules`,
          {
            params: {
              page,
              per_page: pageSize,
            },
          }
        );

        if (
          !response.data ||
          !response.data.module_data ||
          response.data.total_count == null
        ) {
          console.error("Invalid response format:", response.data);
          setLoading(false);
          return;
        }

        const formattedData = response.data.module_data.map(
          (row: Module, index: number) => ({
            ...row,
            id: row.Module_Id, // Use 'id' as the unique identifier
            actionsID: startIndex + index + 1,
          })
        );
        setRows(formattedData);
        setRowCount(response.data.total_count);
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    };

    fetchData(currentPage, pageSize);
  }, [currentPage, pageSize]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  const base64Encode = (str: string) => {
    return btoa(str);
  };
  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };
  const handleEdit = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/modules/manage/form/edit/${encodedId}`);
  };

  const handleView = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/modules/manage/form/view/${encodedId}`);
  };

  const handleDelete = (id: string) => {
    const encodedId = base64Encode(id);
    setIsDeleteModalOpen(true);
    setSelectedRowId(encodedId);
  };

  const handleDeleteCancel = () => {
    setIsDeleteModalOpen(false);
  };

  const actionColumn = {
    field: "action",
    headerName: "Action",
    width: 180,
    renderCell: (params: any) => (
      <div className="cellAction">
        <div className="editButton" onClick={() => handleEdit(params.row)}>
          <EditNote sx={{ fontSize: "20px" }} />
        </div>

        <div
          className="deleteButton"
          onClick={() => handleDelete(params.row.Id)}
        >
          <Delete sx={{ fontSize: "20px" }} />
        </div>

        <div className="viewButton" onClick={() => handleView(params.row)}>
          <MenuBook sx={{ fontSize: "20px" }} />
        </div>
      </div>
    ),
  };

  const handleDeleteConfirm = async () => {
    try {
      const decodedId = selectedRowId ? base64Decode(selectedRowId) : null;
      const response = await AxiosInstance.delete(
        `${BASE_API_URL}/admin/modules/v1/modules/${decodedId}`
      );

      if (response.data) {
        // Remove the deleted row from the local state
        setIsDeleteModalOpen(false);
        setRows((prevRows) =>
          prevRows.filter((row: any) => row.Id.toString() !== decodedId)
        );
        toast.success("Data deleted successfully");
      } else {
        toast.error("Error deleting data");
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      setIsDeleteModalOpen(false);
    }
  };

  const coloumns: GridColDef[] = [
    {
      field: "actionsID",
      headerName: "ID",

      width: 80,
    },
    ...(actionColumn ? [actionColumn] : []),
    {
      field: "Module_Name",
      headerName: "Module Name",
      width: 180,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },

    {
      field: "Module_Icon",
      headerName: "Module Icon",
      width: 180,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Module_Order",
      headerName: "Module order",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Parent_Module_Id",
      headerName: "Parent ID",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },

    {
      field: "IsStatus",
      headerName: "Status",
      width: 150,
      renderCell: (params) => (
        <div
          className={`cellWithStatus ${params.value ? "active" : "inactive"}`}
        >
          {params.value ? "Active" : "Inactive"}
        </div>
      ),
    },
  ];
  return (
    <Layout>
      <div className="datatable">
        <div className="datatableTitle">
          <Header title="Module master" subtitle="" />
          <div className="flex space-x-2">
            <Button
              className="link"
              onClick={() => navigate("/modules/manage/form/create")}
            >
              <AddBox sx={{ fontSize: "40px" }} />
            </Button>
          </div>
        </div>

        <Box
          width={"1100px"}
          margin={"auto"}
          sx={{
            "& .MuiDataGrid-root": {
              border: "none",
              borderBottom: `2px solid ${theme.palette.secondary.light}`,
            },

            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: theme.palette.primary.main,
              borderBottom: "none",
              fontWeight: "bold",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              color: "#fff !important",
            },

            "& .MuiDataGrid-colCell": {
              color: `#fff !important`,
            },

            "& .MuiDataGrid-footerContainer": {
              display: "none",
            },
          }}
        >
          <DataGrid
            rows={rows}
            columns={coloumns}
            getRowId={(row) => row.Id}
            autoHeight
            loading={loading}
          />
        </Box>

        <PaginationButtons
          currentPage={currentPage}
          totalPages={totalPages}
          handlePageChange={handlePageChange}
        />
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={handleDeleteCancel}
          onConfirm={handleDeleteConfirm}
          title="Confirm Deletion"
          message="Are you sure you want to delete this data?"
        />
      </div>
    </Layout>
  );
};

export default ModuleMaster;
