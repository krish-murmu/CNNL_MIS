import {
  IconDefinition,
  faCoffee,
  faCogs,
  faHome,
  faLocation,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import Header from "Components/Header";
import IconPicker from "Components/IconPicker";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { CRUDFormPageProps, Module } from "types";
import iconData from "../../API/icons.json";
import AxiosInstance from "API/axios";
import { BASE_API_URL } from "API/Base";
import { Navigate, useNavigate } from "react-router";
import theme from "theme";
import toast from "react-hot-toast";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedIcon, setSelectedIcon] = useState<IconDefinition | null>(null);
  const [parentModule, setParentModule] = useState<any>([]);
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [editedValues, setEditedValues] = useState<any>({});

  const [formData, setFormData] = useState({
    Module_Name: "",
    Module_Order: 0,
    Module_Icon: "",
    Module_Parent_Id: 0,
    IsStatus: true,
  });
  const [errors, setErrors] = useState({
    Module_Name: "",
    Module_Order: "",
    Module_Icon: "",
  });

  const navigate = useNavigate();

  useEffect(() => {
    const fetchParentModule = async () => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/modules/v1/parent-modules`
        );
        const data: Module[] = response.data;
        setParentModule(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchParentModule();
  }, [mode]);

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);

      const foundModule = parentModule.find(
        (module: any) => module.Module_Name === formData.Module_Parent_Id
      );

      setFormData({
        Module_Name: data.Module_Name || "",
        Module_Order: data.Module_Order || 0,
        Module_Icon: data.Module_Icon || "",
        Module_Parent_Id: data.Module_Parent_Id || 0,
        IsStatus: data.IsStatus || "",
      });

      setSelectedIcon(data.Module_Icon);
      setSelectedModule(foundModule ? foundModule.Module_Name : "");
    }
  }, [mode, data]);

  const handleIconSelect = (icon: any) => {
    setSelectedIcon(icon);
    handleInputChange("Module_Icon", icon.iconName); // Update the form data with the selected icon name
  };

  const handleInputChange = (key: string, value: any) => {
    setFormData({
      ...formData,
      [key]: value,
    });

    if (key === "Module_Parent_Id") {
      setSelectedModule(value);
    }
  };

  // Map icon names to Font Awesome icons
  const Ficons = iconData.map((iconData) => {
    switch (iconData.icon) {
      case "faCoffee":
        return faCoffee;
      case "faHome":
        return faHome;
      case "faUser":
        return faUser;
      case "faLocationPin":
        return faLocation;
      case "faGear":
        return faCogs; // Assuming "faGear" corresponds to faCogs
      default:
        return null; // Handle other cases or provide a default icon
    }
  });

  const validIcons = Ficons.filter((icon) => icon !== null) as IconDefinition[];

  const validateForm = () => {
    let isValid = true;
    const newErrors = {
      Module_Name: "",
      Module_Order: "",
      Module_Icon: "",
    };

    if (!formData.Module_Name.trim()) {
      newErrors.Module_Name = "Module Name is required";
      isValid = false;
    } else if (formData.Module_Name.length < 3) {
      newErrors.Module_Name = "Module Name must be at least 3 characters long";
      isValid = false;
    }

    if (!formData.Module_Order) {
      newErrors.Module_Order = "Module Order is required";
    } else if (formData.Module_Order < 0) {
      newErrors.Module_Order = "Module Order must be greater than 0";
    }

    if (!formData.Module_Icon.trim()) {
      newErrors.Module_Icon = "Module Icon is required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };
  const handleSubmit = async () => {
    try {
      setErrors({
        Module_Name: "",
        Module_Order: "",
        Module_Icon: "",
      });
      setLoading(true);

      if (!validateForm()) {
        return;
      }
      if (mode === "create") {
        const foundModule = parentModule.find(
          (module: any) => module.Module_Name === formData.Module_Parent_Id
        );
        const newData = {
          Module_Name: formData.Module_Name,
          Module_Icon: formData.Module_Icon,
          Module_Order: formData.Module_Order,
          Parent_Module_Id: foundModule ? foundModule.Id : 0,
          IsStatus: !!formData.IsStatus,
        };

        console.log(newData);
        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/modules/v1/modules`,
          newData
        );

        if (response.data) {
          toast.success("Module created successfully");
          setFormData({
            Module_Name: "",
            Module_Icon: iconData[0].icon,
            Module_Order: 0,
            Module_Parent_Id: parentModule[0]?.Id || 0,
            IsStatus: true,
          });
        }
      } else if (mode === "edit") {
        const foundModule = parentModule.find(
          (module: any) => module.Module_Name === formData.Module_Parent_Id
        );

        const newData = {
          Module_Name: formData.Module_Name,
          Module_Icon: formData.Module_Icon,
          Module_Order: formData.Module_Order,
          Parent_Module_Id: foundModule
            ? foundModule.Id
            : formData.Module_Parent_Id,
          IsStatus: !!formData.IsStatus,
        };
        console.log(newData);
        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/modules/v1/modules/${editedValues.Id}`,
          newData
        );

        if (response.data) {
          toast.success("Module updated successfully");
          setFormData({
            Module_Name: "",
            Module_Icon: iconData[0].icon,
            Module_Order: 0,
            Module_Parent_Id: parentModule[0]?.Id || 0,
            IsStatus: true,
          });
        }
      }
    } catch (error: any) {
      if (error.response) {
        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        } else {
          // Handle other error status codes
          toast.error(`Server Error: ${error.response.status}`);
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };
  return (
    <Layout>
      {loading && (
        <Box
          sx={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",

            zIndex: 1000,
          }}
        >
          <CircularProgress size={50} />
        </Box>
      )}
      <Box sx={{ width: "80%", margin: "50px auto" }}>
        <Header
          title={
            mode === "view"
              ? "View module details"
              : mode === "edit"
              ? "Edit module details"
              : mode === "create"
              ? "Create new module "
              : ""
          }
          subtitle={""}
        />

        <Grid container spacing={2}>
          {mode === "create" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Module Name"
                  fullWidth
                  margin="normal"
                  value={formData?.Module_Name}
                  onChange={(e) =>
                    handleInputChange("Module_Name", e.target.value)
                  }
                  error={!!errors.Module_Name}
                  helperText={errors.Module_Name}
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Module Order"
                  margin="normal"
                  fullWidth
                  value={formData?.Module_Order}
                  onChange={(e) =>
                    handleInputChange("Module_Order", e.target.value)
                  }
                  error={!!errors.Module_Order}
                  helperText={errors.Module_Order}
                />
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Status</InputLabel>
                  <Select
                    value={formData.IsStatus || ""}
                    label="Status"
                    required
                    onChange={(e) =>
                      handleInputChange("IsStatus", e.target.value)
                    }
                  >
                    <MenuItem value={"true"}>Active</MenuItem>
                    <MenuItem value={"false"}>Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <IconPicker
                  icons={[faCoffee, faHome, faUser, faLocation, faCogs]}
                  selectedIcon={selectedIcon}
                  onSelect={handleIconSelect}
                />
                {errors.Module_Icon && (
                  <FormHelperText sx={{ color: "red" }}>
                    {errors.Module_Icon}
                  </FormHelperText>
                )}
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Parent Module</InputLabel>
                  <Select
                    value={formData?.Module_Parent_Id || ""}
                    label="Parent Module"
                    onChange={(e) =>
                      handleInputChange("Module_Parent_Id", e.target.value)
                    }
                  >
                    {parentModule?.map((module: Module) => (
                      <MenuItem
                        key={module.Module_Name} // Use a unique identifier here
                        value={module.Module_Name}
                      >
                        {module.Module_Name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            </>
          )}
          {mode === "edit" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Module Name"
                  fullWidth
                  margin="normal"
                  value={formData.Module_Name || ""}
                  onChange={(e) =>
                    handleInputChange("Module_Name", e.target.value)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Module Order"
                  fullWidth
                  margin="normal"
                  value={formData?.Module_Order || ""}
                  onChange={(e) =>
                    handleInputChange("Module_Order", e.target.value)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Status</InputLabel>
                  <Select
                    value={formData.IsStatus ? "true" : "false"}
                    label="Status"
                    onChange={(e) =>
                      handleInputChange(
                        "IsStatus",
                        e.target.value === "true" ? 1 : 0
                      )
                    }
                  >
                    <MenuItem value={"true"}>Active</MenuItem>
                    <MenuItem value={"false"}>Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Parent module</InputLabel>
                  <Select
                    value={selectedModule || ""}
                    label="Parent Module"
                    onChange={(e) =>
                      handleInputChange("Module_Parent_Id", e.target.value)
                    }
                  >
                    {parentModule?.map((module: Module) => (
                      <MenuItem
                        key={module.Module_Id} // Use a unique identifier here
                        value={module.Module_Name}
                      >
                        {module.Module_Name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <IconPicker
                  icons={validIcons}
                  selectedIcon={selectedIcon}
                  onSelect={handleIconSelect}
                />
              </Grid>
            </>
          )}
          {mode === "view" && (
            <>
              <Grid container spacing={2}>
                {fields.map(({ label, key, type }) => (
                  <Grid item xs={6} key={key}>
                    <TextField
                      key={key}
                      label={label}
                      variant="outlined"
                      fullWidth
                      margin="normal"
                      value={data[key] || ""}
                    />
                  </Grid>
                ))}
              </Grid>
            </>
          )}
        </Grid>

        <Box mt={2} display="flex" justifyContent="space-between">
          {mode === "create" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "#fff" }}
            >
              {" "}
              Create{" "}
            </Button>
          )}
          {mode === "edit" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "#fff" }}
            >
              {" "}
              Save Changes{" "}
            </Button>
          )}
          <Button
            variant="outlined"
            sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            onClick={() => navigate("/modules/manage")}
          >
            Back
          </Button>
        </Box>
      </Box>
    </Layout>
  );
};

export default CRUDForm;
