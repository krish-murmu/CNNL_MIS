import { Button } from "@mui/base";
import {
  AddBox,
  Delete,
  DeleteOutline,
  EditNote,
  MenuBook,
  ViewCozy,
} from "@mui/icons-material";
import { Box, Chip } from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import PaginationButtons from "Components/PaginationButtons";
import DeleteModal from "Modals/DeleteModal";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { BookOpen } from "react-feather";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";
import theme from "theme";
import { Page, WrapTextCellProps } from "types";

const PageMaster: React.FC = () => {
  const [rows, setRows] = useState<Page[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [rowCount, setRowCount] = useState<number>(0);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);

  const navigate = useNavigate();

  const base64Encode = (str: string) => {
    return btoa(str);
  };
  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };

  const fetchData = async (page: number, pageSize: number) => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${BASE_API_URL}/admin/modules/v1/get-all-pages`,
        {
          params: {
            page,
            per_page: pageSize,
          },
        }
      );

      if (
        !response.data ||
        !response.data.pages_data ||
        response.data.total_count == null
      ) {
        console.error("Invalid response format:", response.data);
        setLoading(false);
        return;
      }

      const formattedData = response.data.pages_data.map(
        (row: Page, index: number) => ({
          ...row,
          id: row.Page_Id, // Use 'id' as the unique identifier
          actionsID: startIndex + index + 1,
        })
      );

      setRows(formattedData);
      setRowCount(response.data.total_count);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(currentPage, pageSize);
  }, [currentPage, pageSize]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(currentPage * pageSize, rowCount);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  const handleCreate = () => {
    navigate("/pages/manage/form/create");
  };

  const ActionNamesCell = ({ value }: { value: string[] }) => (
    <div style={{ display: "flex", flexWrap: "wrap" }}>
      {value.map((actionName) => (
        <Chip
          key={actionName}
          label={actionName}
          variant="outlined"
          style={{
            margin: 4,
            whiteSpace: "nowrap",
            color: "darkblue",
            border: "1px solid grey",
            borderRadius: 0,
          }}
          size="small"
        />
      ))}
    </div>
  );
  const handleEdit = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/pages/manage/form/edit/${encodedId}`);
  };

  const handleView = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/pages/manage/form/view/${encodedId}`);
  };

  const handleDelete = (id: string) => {
    const encodedId = base64Encode(id);
    setIsDeleteModalOpen(true);
    setSelectedRowId(encodedId);
  };

  const handleDeleteCancel = () => {
    setIsDeleteModalOpen(false);
  };

  // Conditionally define the Action column based on permissions
  const actionColumn = {
    field: "action",
    headerName: "Action",
    width: 150,
    renderCell: (params: any) => (
      <div className="cellAction">
        <div className="editButton" onClick={() => handleEdit(params.row)}>
          Edit
        </div>

        <div
          className="deleteButton"
          onClick={() => handleDelete(params.row.Id)}
        >
          Delete
        </div>

        <div className="viewButton" onClick={() => handleView(params.row)}>
          View
        </div>
      </div>
    ),
  };

  const coloumns: GridColDef[] = [
    {
      field: "actionsID",
      headerName: "ID",

      width: 50,
    },
    ...(actionColumn ? [actionColumn] : []),
    {
      field: "Page_Name",
      headerName: "Page Name",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },

    {
      field: "Page_Url",
      headerName: "Page Url",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },

    {
      field: "Module_Name",
      headerName: "Module Name",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Page_Icon",
      headerName: "Page Icon",
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Page_Order",
      headerName: "Page order",
      width: 100,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Action_Names",
      headerName: "Permissions",
      width: 360,
      renderCell: (params) => <ActionNamesCell value={params.value} />,
    },

    {
      field: "IsStatus",
      headerName: "Status",
      width: 160,
      renderCell: (params) => (
        <div
          className={`cellWithStatus ${params.value ? "active" : "inactive"}`}
        >
          {params.value ? "Active" : "Inactive"}
        </div>
      ),
    },
  ];

  const handleDeleteConfirm = async () => {
    try {
      const decodedId = selectedRowId ? base64Decode(selectedRowId) : null;
      const response = await AxiosInstance.delete(
        `${BASE_API_URL}/admin/modules/v1/pages/${decodedId}`
      );

      if (response.data) {
        // Remove the deleted row from the local state
        setIsDeleteModalOpen(false);
        setRows((prevRows) =>
          prevRows.filter((row: any) => row.Id.toString() !== decodedId)
        );
        toast.success("Data deleted successfully");
      } else {
        toast.error("Error deleting data");
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      setIsDeleteModalOpen(false);
    }
  };

  return (
    <div>
      <Layout>
        <div className="datatable">
          <div className="datatableTitle">
            <Header title="Page Master" subtitle="" />
            <div className="flex space-x-2">
              <Button className="link" onClick={handleCreate}>
                <AddBox sx={{ fontSize: "40px" }} />
              </Button>
            </div>
          </div>

          <Box
            width={"1100px"}
            margin={"auto"}
            sx={{
              "& .MuiDataGrid-root": {
                border: "none",
                borderBottom: `2px solid ${theme.palette.secondary.light}`,
              },

              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: theme.palette.primary.main,
                borderBottom: "none",
                fontWeight: "bold",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                color: "#fff !important",
              },

              "& .MuiDataGrid-colCell": {
                color: `#fff !important`,
              },

              "& .MuiDataGrid-footerContainer": {
                display: "none",
              },
            }}
          >
            <DataGrid
              rows={rows}
              columns={coloumns}
              getRowId={(row) => row.Id}
              autoHeight
              loading={loading}
              density="comfortable"
            />
          </Box>

          <PaginationButtons
            currentPage={currentPage}
            totalPages={totalPages}
            handlePageChange={handlePageChange}
          />
          <DeleteModal
            isOpen={isDeleteModalOpen}
            onClose={handleDeleteCancel}
            onConfirm={handleDeleteConfirm}
            title="Confirm Deletion"
            message="Are you sure you want to delete this data?"
          />
        </div>
      </Layout>
    </div>
  );
};

export default PageMaster;
