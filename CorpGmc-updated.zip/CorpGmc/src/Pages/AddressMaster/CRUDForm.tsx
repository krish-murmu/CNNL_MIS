// ViewFormPage.tsx
import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  ThemeProvider,
  Grid,
  CircularProgress,
} from "@mui/material";
import theme from "../../theme";
import Header from "../../Components/Header";
import CityDataModal from "../../Modals/CityDataModal";
import { BASE_API_URL } from "../../API/Base";
import { useNavigate } from "react-router";
import { CRUDFormPageProps } from "types";
import Layout from "Components/Layout";
import toast, { Toaster } from "react-hot-toast";
import AxiosInstance from "API/axios";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [isCityModalOpen, setIsCityModalOpen] = useState<boolean>(false);
  const [selectedCity, setSelectedCity] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [editedValues, setEditedValues] = useState<any>({});
  const [formData, setFormData] = useState({
    City_Id: "",
    Address_1: "",
  });
  const [errors, setErrors] = useState({
    City_Id: "",
    Address_1: "",
  });

  const navigate = useNavigate();

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);
      setFormData({
        City_Id: data.City_Id || "",
        Address_1: data.Address_1 || "",
      });
      setSelectedCity(data.City_Name);
    }
  }, [mode, data]);

  const handleCityModalOpen = () => {
    setIsCityModalOpen(true);
  };

  const handleCityModalClose = () => {
    setIsCityModalOpen(false);
  };

  const handleCitySelect = (selectedCity: any) => {
    setIsCityModalOpen(false);
    setSelectedCity(selectedCity);
    handleFieldChange("City_Id", selectedCity);
  };

  const handleFieldChange = (key: string, value: string | any) => {
    if (typeof value === "object" && value !== null) {
      setFormData((prevData: any) => ({
        ...prevData,
        [key]: value.Id,
      }));
      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [key]: value, // Assuming the selected value has the same field name
      }));
    } else {
      setFormData((prevData: any) => ({
        ...prevData,
        [key]: value,
      }));
    }
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = {
      City_Id: "",
      Address_1: "",
    };

    if (!formData.City_Id) {
      newErrors.City_Id = "City is required";
      isValid = false;
    }

    if (!formData.Address_1 || !formData.Address_1.trim()) {
      newErrors.Address_1 = "Address is required";
      isValid = false;
    } else if (formData.Address_1.length < 5) {
      newErrors.Address_1 = "Invalid address";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };
  const handleSubmit = async () => {
    try {
      setLoading(true);
      if (!validateForm()) {
        return;
      }
      if (mode === "create") {
        const completData = {
          City_Id: formData.City_Id,
          Address_1: formData.Address_1,
        };

        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/v1/address-details`,
          completData
        );

        if (response.data) {
          setFormData({
            City_Id: formData.City_Id || "",
            Address_1: "",
          });
          setLoading(false);
          toast.success("Data created successfully");
        }
      } else if (mode === "edit") {
        const complete = {
          City_Id: selectedCity?.Id ?? formData.City_Id,
          Address_1: formData.Address_1,
          Modify_By: 1,
          Modify_On: "2024-01-03 07:25:50",
        };

        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/v1/address-details/${data.Id}`,
          complete
        );

        if (response.data) {
          toast.success("Data updated successfully");
          setLoading(false);
        }
      }
    } catch (error: any) {
      if (error.response) {
        toast.error("Error response details", error.response.data);

        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate("/address-master");
  };

  return (
    <Layout>
      <ThemeProvider theme={theme}>
        <CityDataModal
          isOpen={isCityModalOpen}
          onClose={handleCityModalClose}
          onSelectCity={handleCitySelect}
        />
        {loading && (
          <Box
            sx={{
              position: "fixed",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",

              zIndex: 1000,
            }}
          >
            <CircularProgress size={50} />
          </Box>
        )}
        <Box sx={{ width: "80%", margin: "50px auto" }}>
          <Header
            title={
              mode === "view"
                ? "View address"
                : mode === "edit"
                ? "Edit address"
                : mode === "create"
                ? "Create new address"
                : ""
            }
            subtitle={""}
          />

          <Grid container spacing={2}>
            {mode === "create" && (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="City"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    required
                    sx={{ marginBottom: "16px" }}
                    value={selectedCity?.City_Name || ""}
                    onChange={(e) =>
                      handleFieldChange("City_Id", e.target.value)
                    }
                    onClick={handleCityModalOpen}
                    error={!!errors.City_Id}
                    helperText={errors.City_Id}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Address"
                    variant="outlined"
                    fullWidth
                    required
                    margin="normal"
                    sx={{ marginBottom: "16px" }}
                    value={formData?.Address_1 || ""}
                    onChange={(e) =>
                      handleFieldChange("Address_1", e.target.value)
                    }
                    error={!!errors.Address_1}
                    helperText={errors.Address_1}
                  ></TextField>
                </Grid>
              </>
            )}

            {mode === "edit" && (
              <Grid item xs={16}>
                <TextField
                  label="City"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{ marginBottom: "16px" }}
                  value={selectedCity?.City_Name || data?.City_Name || ""}
                  onChange={(e) => handleFieldChange("City_Id", e.target.value)}
                  onClick={handleCityModalOpen}
                  error={!!errors.City_Id}
                  helperText={errors.City_Id}
                />
                <TextField
                  label="Address"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  sx={{ marginBottom: "16px" }}
                  value={formData?.Address_1 || ""}
                  onChange={(e) =>
                    handleFieldChange("Address_1", e.target.value)
                  }
                  error={!!errors.Address_1}
                  helperText={errors.Address_1}
                />
              </Grid>
            )}
            {mode === "view" && (
              <>
                <Grid container spacing={2}>
                  {fields.map(({ label, key, type }) => (
                    <Grid item xs={6} key={key}>
                      <TextField
                        key={key}
                        label={label}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        sx={{ marginBottom: "16px" }}
                        value={data[key] || ""}
                      />
                    </Grid>
                  ))}
                </Grid>
              </>
            )}
          </Grid>

          <Box mt={2} display="flex" justifyContent="space-between">
            {mode === "edit" && (
              <Button
                variant="contained"
                color="primary"
                sx={{ color: "#fff" }}
                onClick={handleSubmit}
              >
                Save Changes
              </Button>
            )}

            {mode === "create" && (
              <Button
                variant="contained"
                color="primary"
                sx={{ color: "#fff" }}
                onClick={handleSubmit}
              >
                Create
              </Button>
            )}
            <Button
              variant="outlined"
              sx={{ border: `1px solid ${theme.palette.primary.main}` }}
              onClick={handleBack}
            >
              Back
            </Button>
          </Box>
        </Box>
      </ThemeProvider>
      <Toaster />
    </Layout>
  );
};

export default CRUDForm;
