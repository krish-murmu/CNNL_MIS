import { Button, Modal } from "@mui/material";
import { Box } from "@mui/system";
import {
  DataGrid,
  GridAlignment,
  GridColDef,
  GridRenderCellParams,
  GridToolbar,
} from "@mui/x-data-grid";
import AxiosInstance from "API/axios";
import { usePagePermissions } from "Components/PagePermissions";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";

type Props = {};

interface QuoteHistoryModel {
  Id: number;
  QuoteNumber: number;
  ProductId: number;
  ProductName: string;
  CustomerId: number;
  CustomerName: string;
  isRenewal: boolean;
  //   FamilyId: number;
  //   FamilyType: string;
  QuoteDate: Date; // You may need to adjust the Date type to match your needs
}

function QuoteMaster({}: Props) {
  const navigate = useNavigate();
  const permissions = usePagePermissions("Quote History");
  const [QuoteModal, setQuoteModal] = useState<boolean>(false);
  const [Loading, setLoading] = useState<boolean>(false);
  const [rows, setRows] = useState<QuoteHistoryModel[]>([]);

  const openQuoteModal = () => {
    setQuoteModal(true);
  };
  const closeQuoteModal = () => {
    setQuoteModal(false);
  };

  const fetchdata = async () => {
    try {
      const res = await AxiosInstance.get(
        "/admin/quotes/Master/Get-Quotes-History"
      );
      const data: QuoteHistoryModel[] = res.data;
      console.log(data);
      setRows(data);
      setLoading(false);
    } catch (error) {
      console.log(error);
      toast.error("Error in fetching data");
    }
  };

  const handleViewClick = (id: number, isRenewal: boolean) => {
    navigate(`/quote/view/${id}`);
  };

  const columns: GridColDef[] = [
    {
      field: "Sr. No.",
      headerName: "Id",
      width: 70,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        // Find the index of the row in the rows array and add 1
        const rowIndex = rows.findIndex((row) => row.Id === params.row.Id) + 1;
        return <div>{rowIndex}</div>;
      },
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    ...(permissions?.View
      ? [
          {
            field: "Actions",
            headerName: "Actions",
            headerAlign: "center" as GridAlignment, // Corrected type
            align: "center" as GridAlignment, // Corrected type
            headerClassName:
              "bg-primary text-white font-bold flex flex-row items-center",
            width: 100,
            renderCell: (params: GridRenderCellParams) => (
              <div className="cellAction">
                <div
                  className="viewButton"
                  onClick={() => {
                    console.log("Renewal", params.row.isRenewal);
                    handleViewClick(
                      params.row.QuoteNumber as number,
                      params.row.isRenewal as boolean
                    );
                  }}
                >
                  View
                </div>
              </div>
            ),
          },
        ]
      : []),

    {
      field: "QuoteNumber",
      headerName: "Quote Number",
      width: 120,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    {
      field: "ProductName",
      headerName: "Product Name",
      width: 120,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    {
      field: "isRenewal",
      headerName: "Renewal/Fresh",
      width: 150,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
      renderCell: (params) => {
        return <div>{params.row.isRenewal ? "Renewal" : "Fresh"}</div>;
      },
    },
    {
      field: "CustomerName",
      headerName: "Customer",
      width: 150,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    {
      field: "QuoteDate",
      headerName: "Quote Date",
      width: 200,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
  ];

  useEffect(() => {
    if (permissions.List) {
      console.log("Fetching Data");
      setLoading(true);
      fetchdata();
    } else {
      console.log("Cannot Fetch Data");
    }
  }, [permissions]);

  return (
    <Layout>
      <div className="flex flex-col items-center justify-start w-full h-full px-8 mb-16">
        <div className="flex flex-row items-center justify-start w-full">
          <Header title={"Quote History"} subtitle={"View Quote History"} />
        </div>
        <div id="actions" className="flex flex-row items-center w-full h-16 ">
          {permissions.Add ? (
            <Button
              variant="contained"
              onClick={() => {
                openQuoteModal();
              }}
              className="flex flex-row items-center justify-center w-1/6 h-12 rounded-full bg-primary "
            >
              <h3 className="text-white ">Get GMC Quote</h3>
            </Button>
          ) : null}
        </div>
        <div className="flex flex-col items-center justify-start w-full pr-12 mt-4">
          <DataGrid
            rows={rows}
            columns={columns}
            autoHeight
            loading={Loading}
            getRowId={(rows) => rows.Id.toString()}
            disableRowSelectionOnClick={true}
            pagination
            pageSizeOptions={[5, 10, 25, 50]}
            initialState={{
              pagination: { paginationModel: { pageSize: 25 } },
            }}
            onCellClick={(params) => {
              if (params.field === "action" && params.row) {
                console.log("clicked", params.row.Id);
              }
            }}
          />
        </div>
      </div>
      <Modal key="Quote Modal" open={QuoteModal} onClose={closeQuoteModal}>
        <Box className="absolute top-1/2 left-1/2 w-1/6 h-3/4 transform rounded-2xl -translate-x-1/2 -translate-y-1/2 bg-white shadow-md border-none  pb-8 min-w-[400px] flex flex-col items-center justify-center gap-y-4">
          <div className="flex flex-col items-center w-full h-full border-none">
            <div className="flex flex-row items-center justify-center w-full h-1/6 rounded-t-2xl bg-primary">
              <h3 className="text-3xl font-semibold text-white">
                Select Quote Type
              </h3>
            </div>
            <div className="flex flex-col items-center w-full px-8 pt-8 h-5/6 gap-y-8">
              <button
                onClick={() => {
                  navigate("/quote/new-gmc-quote");
                }}
                className="flex flex-row items-center justify-center w-full text-white transition-all duration-200 ease-in-out hover:bg-primary/90 h-1/6 rounded-2xl bg-primary"
              >
                <h3 className="text-xl font-normal">Get GMC Quote (Fresh)</h3>
              </button>
              <button
                onClick={() => {
                  navigate("/quote/renewal");
                }}
                className="flex flex-row items-center justify-center w-full text-white transition-all duration-200 ease-in-out hover:bg-primary/90 h-1/6 rounded-2xl bg-primary"
              >
                <h3 className="text-xl font-normal">Get GMC Quote (Renewal)</h3>
              </button>
              <button className="flex flex-row items-center justify-center w-full text-white transition-all duration-200 ease-in-out hover:bg-primary/90 h-1/6 rounded-2xl bg-primary">
                <h3 className="text-xl font-normal">Get Fire Quote</h3>
              </button>
            </div>
          </div>
        </Box>
      </Modal>
    </Layout>
  );
}

export default QuoteMaster;
