import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  InputAdornment,
  InputLabel,
  List,
  ListItem,
  MenuItem,
  Modal,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { Controller, SubmitHandler, useForm } from "react-hook-form";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { VisuallyHiddenInput } from "@chakra-ui/react";
import {
  DataGrid,
  GridColDef,
  GridToolbar,
  GridToolbarContainer,
  GridToolbarQuickFilter,
} from "@mui/x-data-grid";
import AxiosInstance from "API/axios";
import { BASE_API_URL } from "API/Base";
import toast from "react-hot-toast";
import { useTokenStore } from "../../Zustand/TokenStore";
import { GMCQuoteOutputModel, QuoteDataModel } from "types";
import LoadingAnimation from "Components/LoadingAnimation";
import { motion } from "framer-motion";

export type CustomerModelFields = {
  Id: number;
  Customer_Name: string;
  Address_1: string;
  City_Name: string;
  State_Name: string;
  Pin_Code: number;
};

interface Inputs {
  QuoteNumber: number;
  Customer: string;
  Address: string;
  City: string;
  Postal_Code: number;
  State: string;
  Family: number;
  QuoteDate: Date;
  File: File | null;
}

interface FamilyOptions {
  Id: number;
  Status_Name: string;
  isStatus: boolean;
}

interface Coverages {
  Id: number;
  Coverage_Name: string;
  Coverage_Detail: string;
  Coverage_Type: string;
  Parent_Coverage_Id: number;
  Parent_Coverage_Name: string;
}

type Props = {};

export default function Create_Quote({}: Props) {
  //Form Functioning
  const {
    register,
    handleSubmit,
    watch,
    control,
    setValue,
    formState: { errors },
  } = useForm<Inputs>();
  const [FamilyOptions, SetFamilyOptions] = useState<FamilyOptions[]>([]);
  const [FileSent, setFileSent] = useState<boolean>(false);
  const [DataArrival, setDataArrival] = useState<boolean>(false);
  const [FileName, setFileName] = useState<string>("");

  // const onSubmit: SubmitHandler<Inputs> = async (data: Inputs) => {
  //   console.log(data);

  //   const customer = rows.find((row) => row.Customer_Name === data.Customer);
  //   const inputdata = {
  //     QuoteNumber: data.QuoteNumber,
  //     Customer: customer?.Id.toString(),
  //     Address: data.Address,
  //     City: data.City,
  //     Postal_Code: data.Postal_Code,
  //     State: data.State,
  //     Family: data.Family,
  //     QuoteDate: data.QuoteDate,
  //   };
  //   const res = await AxiosInstance.post(
  //     `${BASE_API_URL}/admin/quotes/gmc-quote/vt/post-quote-data`,
  //     inputdata
  //   );
  //   const File = data.File;
  //   if (res.status === 200) {
  //     toast.success("Uploading File");
  //     coveragesend();
  //     setFileSent(true);
  //     if (File !== null) sendFile(File, data.QuoteNumber);
  //   }
  //   // Proceed with form submission
  // };

  // const sendFile = async (file: File | null, quoteNumber: number) => {
  //   if (!file) {
  //     console.error("No file selected");
  //     // You can display an error message or take appropriate action here
  //     return;
  //   }
  //   console.log(file);
  //   const formData = new FormData();
  //   formData.append("file", file);

  //   const url = `${BASE_API_URL}/admin/quotes/gmc-quote/vt/post-data-file?quotenumber=${quoteNumber}`;

  //   try {
  //     const response = await fetch(url, {
  //       method: "POST",
  //       body: formData,
  //       // If you need to add headers like Authorization, uncomment and modify the following line
  //       headers: {
  //         Authorization: `Bearer ${useTokenStore.getState().accessToken}`,
  //       },
  //     });

  //     if (response.ok) {
  //       const result = await response.json();
  //       console.log(result);
  //       toast.success("File Uploaded Successfully");
  //       toast.success("Fetching Data");
  //       // setFileSent(true);
  //       getOutputData();
  //     } else {
  //       // Handle HTTP errors
  //       console.error("Upload failed:", response.statusText);
  //       toast.error(`Error uploading file: ${response.statusText}`);
  //     }
  //   } catch (error) {
  //     console.error("Error:", error);
  //     toast.error(`Error uploading file: ${error}`);
  //   }
  // };

  // const coveragesend = async () => {
  //   const CoveragesToSend: CoveragesInput[] = [];

  //   for (const [key, value] of Object.entries(inputValues)) {
  //     const coverageId = parseInt(key);
  //     const foundCoverage = Coverages.find((c) => c.Id === coverageId);

  //     if (foundCoverage) {
  //       CoveragesToSend.push({
  //         CoverageId: coverageId,
  //         CoverageName: foundCoverage.Coverage_Name, // Add the name here
  //         Input_Type: typeof value === "boolean" ? "Boolean" : "Input",
  //         Value: value,
  //       });
  //     }
  //   }

  //   const data = {
  //     QuoteNumber: quoteNumber,
  //     Coverages: CoveragesToSend,
  //   };
  //   try {
  //     const res = await AxiosInstance.post(
  //       `${BASE_API_URL}/admin/coverages/vt/quote-coverage-input`,
  //       data
  //     );
  //     if (res.status === 200) {
  //       setCoverageSent(true);
  //     }
  //   } catch (error) {
  //     console.log(error);
  //     toast.error("Something Went Wrong");
  //   }
  //   // Here you can continue with sending data or other logic
  // };

  const prepareCoveragesToSend = () => {
    const coveragesToSend = [];

    for (const [key, value] of Object.entries(inputValues)) {
      const coverageId = parseInt(key);
      const foundCoverage = Coverages.find((c) => c.Id === coverageId);

      if (foundCoverage) {
        coveragesToSend.push({
          CoverageId: coverageId,
          CoverageName: foundCoverage.Coverage_Name, // Add the name here
          Input_Type: typeof value === "boolean" ? "Boolean" : "Input",
          Value: value,
        });
      }
    }

    return coveragesToSend;
  };
  const onSubmit: SubmitHandler<Inputs> = async (data: Inputs) => {
    console.log(data);

    const customer = rows.find((row) => row.Customer_Name === data.Customer);
    const quoteData = {
      QuoteNumber: data.QuoteNumber,
      Customer: customer?.Id.toString(),
      Address: data.Address,
      City: data.City,
      Postal_Code: data.Postal_Code,
      State: data.State,
      Family: data.Family,
      QuoteDate: data.QuoteDate,
    };

    const coveragesToSend =
      prepareCoveragesToSend(); /* logic to prepare your coverages data */

    const formData = new FormData();
    formData.append("quote_data", JSON.stringify(quoteData));
    formData.append("coverages", JSON.stringify(coveragesToSend));

    if (data.File) {
      formData.append("file", data.File);
    }
    for (let [key, value] of formData.entries()) {
      console.log(key, value);
    }
    try {
      const res = await AxiosInstance.post(
        `${BASE_API_URL}/admin/quotes/gmc-quote/v1/quote-data-combined`, // Adjust the URL to your combined endpoint
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data", // This might be optional as Axios sets it automatically for FormData
            Authorization: `Bearer ${useTokenStore.getState().accessToken}`,
          },
        }
      );

      if (res.status === 200) {
        toast.success("Data submitted successfully");
        setCoverageSent(true);
        setFileSent(true);
        getOutputData();
        // handle successful submission
      } else {
        // Handle other HTTP responses
        toast.error(`Error: ${res.statusText}`);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error(`Error submitting data: ${error}`);
    }
    // Continue with the Axios request
  };

  const handleDateChange = (date: Date) => {
    // Assuming "QuoteDate" is the name of your form field
    setValue("QuoteDate", date);
  };

  const generateRandomQuoteNumber = () => {
    const min = 100000;
    const max = 999999;
    const rand: number = Math.floor(min + Math.random() * (max - min + 1));
    setQuoteNumber(rand);
    setValue("QuoteNumber", rand);
  };

  const get_family_options = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/quotes/gmc-quote/v1/get-family-options`
      );
      const data: FamilyOptions[] = res.data;
      if (data) {
        SetFamilyOptions(data);
      } else {
        toast.error("Error fetching data");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Error fetching data");
    }
  };

  //Customer Model functioning
  const [CustomerModel, setCustomerModal] = useState(false);
  const [rows, setRows] = useState<CustomerModelFields[]>([]);
  const [quoteNumber, setQuoteNumber] = useState<number>();
  const [selectedRow, setSelectedRow] = useState<
    CustomerModelFields | undefined
  >();

  const handleRowSelection = (row: CustomerModelFields) => {
    setSelectedRow(row);
  };

  const columns: GridColDef[] = [
    // {
    //   field: "selection",
    //   headerName: "Select",
    //   width: 100,
    //   sortable: false,
    //   headerClassName:
    //     "bg-primary text-white font-bold flex flex-row items-center justify-center",
    //   renderCell: (params) => {
    //     return (
    //       <Checkbox
    //         checked={selectedRow === params.row}
    //         onChange={() =>
    //           handleRowSelection(params.row as CustomerModelFields)
    //         }
    //       />
    //     );
    //   },
    // },
    {
      field: "index",
      headerName: "Index",
      width: 100,
      renderCell: (params) => {
        const index = params.rowNode.id;
        return (
          <div className="flex flex-row items-center justify-center w-full h-full">
            <h3 className="text-black">{params.rowNode.id}</h3>
          </div>
        );
      },
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "Customer_Name",
      headerName: "Customer Name",
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "Address_1",
      headerName: "Address",
      // width: 200,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "City_Name",
      headerName: "City",
      // width: 160,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "State_Name",
      headerName: "State",
      // width: 150,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "Pin_Code",
      headerName: "Postal Code",
      // width: 150,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
  ];

  function CustomToolbar() {
    return (
      <GridToolbarContainer className="p-4 text-black bg-primary/20 placeholder-primary">
        <GridToolbarQuickFilter />
      </GridToolbarContainer>
    );
  }

  const fetchCustomerData = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/quotes/Master/v1/customer-details`
      );
      const data: CustomerModelFields[] = res.data;
      if (data) {
        setRows(data);
      } else {
        toast.error("Error fetching data");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Error fetching data");
    }
  };

  const openCustomerModal = () => {
    setCustomerModal(true);
  };

  const closeCustomerModal = () => {
    setCustomerModal(false);
  };

  const handleConfirmSelection = () => {
    if (selectedRow) {
      setValue("Customer", selectedRow.Customer_Name);
      setValue("Address", selectedRow.Address_1);
      setValue("City", selectedRow.City_Name);
      setValue("Postal_Code", selectedRow.Pin_Code);
      setValue("State", selectedRow.State_Name);
      setValue("QuoteNumber", quoteNumber as number);
      closeCustomerModal();
    }
  };

  //Getting Data after File Upload
  const [RecievedQuoteData, setRecievedQuoteData] =
    useState<GMCQuoteOutputModel>();

  const getOutputData = async () => {
    const toastId = toast.loading("Loading quote data...");
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/quotes/gmc-quote/v1/get-quote-data-by-quote-number?QuoteNumber=${quoteNumber}`
      );
      const data: GMCQuoteOutputModel = res.data;
      setRecievedQuoteData(data);
      setDataArrival(true);
      toast.success("Data loaded successfully!", { id: toastId });
    } catch (error) {
      console.log(error);
      toast.error("Failed to load data", { id: toastId });
    }
  };

  const OutputColumns: GridColDef[] = [
    {
      field: "QuoteNumber",
      headerName: "Quote Number",
      width: 100,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeNumber",
      headerName: "Employee Number",
      width: 200,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeName",
      headerName: "Employee Name",
      width: 300,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeGender",
      headerName: "Gender",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeDOB",
      headerName: "DOB",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeRelation",
      headerName: "Relation",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeSum",
      headerName: "Sum Assured",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeAge",
      headerName: "Age",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
  ];

  const [Coverages, setCoverages] = useState<Coverages[]>([]);
  const fetchCoverages = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/coverages/v1/get-coverages`
      );
      const data: Coverages[] = res.data;
      setCoverages(data);
    } catch (e) {
      console.log(e);
    }
  };
  const [selectedCoverages, setSelectedCoverages] = useState<number[]>([]);
  const [inputValues, setInputValues] = useState<{
    [key: number]: boolean | string;
  }>({});
  const [coverageSent, setCoverageSent] = useState<boolean>(false);

  const handleCheckboxChange = (id: number, isChecked: boolean) => {
    setSelectedCoverages((prev) =>
      isChecked ? [...prev, id] : prev.filter((coverageId) => coverageId !== id)
    );
    handleInputChange(id, isChecked);
  };

  const handleInputChange = (id: number, value: boolean | string) => {
    setInputValues((prev) => ({ ...prev, [id]: value }));
  };

  const renderInput = (coverage: Coverages) => {
    return coverage.Coverage_Type === "Boolean" ? (
      <Checkbox
        disabled={coverageSent}
        checked={!!inputValues[coverage.Id]}
        onChange={(e) => handleCheckboxChange(coverage.Id, e.target.checked)}
      />
    ) : (
      <input
        type="number"
        disabled={coverageSent}
        value={(inputValues[coverage.Id] as string) || ""}
        onChange={(e) => handleInputChange(coverage.Id, e.target.value)}
        className="pl-2 ml-2 transition-all duration-200 ease-in-out border rounded border-slate-700 hover:border-primary active:border-primary"
      />
    );
  };

  const variants = {
    open: { opacity: 1, height: "auto" },
    collapsed: { opacity: 0, height: 0 },
  };

  const renderChildCoverages = (parentId: number) => {
    const isVisible = selectedCoverages.includes(parentId);

    return (
      <motion.ul
        initial="collapsed"
        animate={isVisible ? "open" : "collapsed"}
        variants={variants}
        transition={{ duration: 0.5, ease: "easeInOut" }}
        className="overflow-hidden list-disc"
      >
        {Coverages.filter(
          (coverage) => coverage.Parent_Coverage_Id === parentId
        ).map((childCoverage) => (
          <li
            key={childCoverage.Id}
            className="flex flex-row items-center mb-2 ml-4"
          >
            <span>{childCoverage.Coverage_Name}</span>
            {renderInput(childCoverage)}
          </li>
        ))}
      </motion.ul>
    );
  };

  const renderCoverages = (Coverages: Coverages[]) => {
    return (
      <ul className="list-decimal">
        {Coverages.filter((coverage) => coverage.Parent_Coverage_Id === 0).map(
          (coverage) => (
            <li key={coverage.Id} className="">
              <span>{coverage.Coverage_Name}</span>
              {renderInput(coverage)}
              {selectedCoverages.includes(coverage.Id) && (
                <ul>{renderChildCoverages(coverage.Id)}</ul>
              )}
            </li>
          )
        )}
      </ul>
    );
  };

  useEffect(() => {
    fetchCustomerData();
    generateRandomQuoteNumber();
    get_family_options();
    fetchCoverages();
  }, []);

  return (
    <Layout>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <div
          className={`flex flex-col items-center w-full h-full px-8 pt-2 ${
            FileSent ? "mb-16" : ""
          } gap-y-0`}
        >
          <div className="w-full">
            <Header title={"Get A Quote"} subtitle={"Get GMC Quote"} />
          </div>
          {/* <div className="flex flex-row items-end justify-start w-full h-20">
            <Header title={"Insert Quote Details"} subtitle={""} />
          </div> */}
          <div className="flex flex-col items-center justify-center w-full h-auto">
            <div className="flex flex-row items-center w-full justify-normal text-primary ">
              <h1 className="text-3xl font-semibold">Insert Quote Details</h1>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
              }}
              className="flex flex-col w-full h-full gap-y-2"
            >
              <div className="flex flex-row items-center w-full gap-x-2 justify-normal">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <TextField
                    className="w-full h-full"
                    {...register("QuoteNumber", {
                      required: "This Field Is Required",
                    })}
                    error={Boolean(errors.QuoteNumber)}
                    defaultValue={quoteNumber}
                    disabled={true}
                    onChange={(e) => {
                      setQuoteNumber(parseInt(e.target.value));
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Typography
                            variant="subtitle1"
                            className="text-black"
                          >
                            Quote Number:
                          </Typography>
                        </InputAdornment>
                      ),
                    }}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <DatePicker
                    label="Quote Date"
                    className="w-full h-full"
                    {...register("QuoteDate", {
                      required: "This Field Is Required",
                    })}
                    defaultValue={new Date()}
                    onChange={(date: Date | null) => {
                      if (date) {
                        setValue("QuoteDate", date); // Set the selected date to the form input
                      }
                    }}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 justify-normal">
                  <TextField
                    className="w-full h-full cursor-pointer"
                    value={selectedRow?.Customer_Name}
                    defaultValue={""}
                    error={Boolean(errors.Customer)}
                    onClick={openCustomerModal}
                    {...register("Customer", {
                      required: "This Field Is Required",
                    })}
                    InputLabelProps={{
                      shrink: true, // This ensures the label moves up when input has a value
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Typography
                            variant="subtitle1"
                            className="text-black"
                          >
                            Customer Name:
                          </Typography>
                        </InputAdornment>
                      ),
                    }}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <TextField
                    value={selectedRow?.Address_1}
                    onClick={openCustomerModal}
                    defaultValue={""}
                    className="w-full h-full"
                    InputLabelProps={{
                      shrink: true, // This ensures the label moves up when input has a value
                    }}
                    {...register("Address", {
                      required: "This Field Is Required",
                    })}
                    error={Boolean(errors.Address)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Typography
                            variant="subtitle1"
                            className="text-black"
                          >
                            Address:
                          </Typography>
                        </InputAdornment>
                      ),
                    }}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <TextField
                    value={selectedRow?.City_Name}
                    onClick={openCustomerModal}
                    defaultValue={""}
                    className="w-full h-full "
                    InputLabelProps={{
                      shrink: true, // This ensures the label moves up when input has a value
                    }}
                    {...register("City", {
                      required: "This Field Is Required",
                    })}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Typography
                            variant="subtitle1"
                            className="text-black"
                          >
                            City Name:
                          </Typography>
                        </InputAdornment>
                      ),
                    }}
                    error={Boolean(errors.City)}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <TextField
                    onClick={openCustomerModal}
                    value={selectedRow?.State_Name}
                    defaultValue={""}
                    className="w-full h-full "
                    InputLabelProps={{
                      shrink: true, // This ensures the label moves up when input has a value
                    }}
                    {...register("State", {
                      required: "This Field Is Required",
                    })}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Typography
                            variant="subtitle1"
                            className="text-black"
                          >
                            State:
                          </Typography>
                        </InputAdornment>
                      ),
                    }}
                    error={Boolean(errors.State)}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-row items-center w-2/3 h-full justify-normal gap-x-2">
                  <InputLabel
                    htmlFor="family"
                    className="font-semibold text-black placeholder:text-black"
                  >
                    <span className="text-black">Family Type : </span>
                  </InputLabel>
                  <Select
                    error={Boolean(errors.Family)}
                    className="w-1/2 h-full"
                    label="Family"
                    sx={{ ":placeholder-shown": { color: "red" } }}
                    aria-label="Family"
                    placeholder="Select Family Type"
                    {...register("Family", {
                      required: "This Field Is Required",
                    })}
                  >
                    {FamilyOptions.map((option) => (
                      <MenuItem key={option.Id} value={option.Id}>
                        {option.Status_Name}
                      </MenuItem>
                    ))}
                  </Select>
                </div>
              </div>
              <div className="flex flex-row items-center w-full justify-normal">
                <h3 className="text-3xl font-semibold text-primary ">
                  Select Coverage
                </h3>
              </div>
              <div className="flex flex-col w-full pl-4">
                {renderCoverages(Coverages)}
              </div>

              <div className="flex flex-row items-start w-full h-16 gap-x-2">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <div className="flex flex-col items-center justify-start w-full h-full">
                    <Controller
                      name="File"
                      control={control}
                      rules={{ required: "This Field is Required" }}
                      render={({ field }) => (
                        <Button
                          component="label"
                          variant="contained"
                          disabled={FileSent}
                          color="primary"
                          className="w-full h-12 hover:bg-secondary hover:text-white hover:border-transparent"
                          startIcon={
                            <CloudUploadIcon className="text-white " />
                          }
                        >
                          <span className="text-white">Upload file</span>
                          <VisuallyHiddenInput
                            required={true}
                            disabled={FileSent}
                            type="file"
                            accept=".xlsx, .xls ,.txt ,.csv"
                            onChange={(e) => {
                              const file = e.target?.files?.[0];
                              field.onChange(file);
                              setFileName(file?.name ?? "");
                            }}
                          />
                        </Button>
                      )}
                    />
                    {/* show uploaded file name */}
                  </div>
                  {FileName && (
                    <span className="text-blue">File Name : {FileName}</span>
                  )}
                  {errors.File && (
                    <span className="text-red-500">File is required</span>
                  )}
                </div>
                <div className="flex flex-row items-start w-1/3 h-full">
                  <button
                    disabled={FileSent}
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      handleSubmit(onSubmit)();
                    }}
                    className={`${
                      FileSent ? "hidden" : ""
                    } flex flex-row items-center justify-center w-full h-12 transition-all duration-200 ease-in-out bg-white border rounded-md border-primary text-primary hover:bg-primary hover:text-white hover:border-transparent`}
                  >
                    Submit
                  </button>
                </div>
              </div>
            </form>
          </div>

          {FileSent && !DataArrival ? (
            <LoadingAnimation />
          ) : FileSent && DataArrival ? (
            <>
              <div className="flex flex-col items-center w-full mt-2 gap-y-8">
                {/* Data Grid */}
                <DataGrid
                  className="w-full"
                  rows={RecievedQuoteData?.QuoteData ?? []}
                  columns={OutputColumns}
                  getRowId={(row: QuoteDataModel) => row.Id}
                  autoHeight
                  slots={{
                    toolbar: GridToolbar,
                  }}
                  pagination
                  pageSizeOptions={[5, 10, 25]}
                  initialState={{
                    pagination: { paginationModel: { pageSize: 5 } },
                  }}
                  onCellClick={(params) => {
                    if (params.field === "action" && params.row) {
                      console.log("clicked", params.row.Id);
                    }
                  }}
                />
                <div className="w-full row-span-6">
                  <div className="flex flex-row items-center justify-center w-full h-16 border-b border-white bg-primary">
                    <h3 className="text-2xl text-white">Age Counts</h3>
                  </div>
                  <div className="grid w-full h-12 grid-cols-2">
                    <div className="flex flex-row items-center justify-center w-full text-white border-b bg-primary border-x border-slate-500">
                      <h1 className="">Age Groups</h1>
                    </div>
                    <div className="flex flex-row items-center justify-center w-full text-white border-b bg-primary border-x border-slate-500">
                      <h1 className="">Counts</h1>
                    </div>
                  </div>
                  <div className="grid w-full grid-cols-2">
                    {RecievedQuoteData?.AgeGroups.map((item, index) => {
                      return (
                        <>
                          <div
                            key={index}
                            className="flex flex-row items-center justify-center w-full h-12 text-white border-b bg-primary/10 border-x border-slate-500"
                          >
                            <h1 className="text-black">
                              People Between the Ages : {item.AgeGroup}
                            </h1>
                          </div>
                          <div className="flex flex-row items-center justify-center w-full border-b bg-primary/10 border-x border-slate-500">
                            <h1 className="text-black ">
                              {item.AgeGroupCount}
                            </h1>
                          </div>
                        </>
                      );
                    })}
                  </div>
                </div>
              </div>
            </>
          ) : null}
        </div>
        <Modal
          key={"Customer Modal"}
          open={CustomerModel}
          onClose={closeCustomerModal}
        >
          <Box className="absolute top-1/2 left-1/2 w-11/12 h-[90%] transform -translate-x-1/2 -translate-y-1/2 bg-white shadow-md px-8 pb-8 min-w-[400px] flex flex-col items-center justify-center gap-y-4">
            <h2 className="text-3xl font-semibold text-primary">
              Select Customer
            </h2>
            <div className="w-full h-full">
              <DataGrid
                rows={rows}
                //adjustable column widths

                columns={columns}
                getRowId={(row: CustomerModelFields) => row.Id}
                autoHeight
                slots={{
                  toolbar: CustomToolbar,
                }}
                pagination
                onRowDoubleClick={(params) => {
                  // Handle double-click selection here
                  handleRowSelection(params.row as CustomerModelFields);
                  handleConfirmSelection();
                }}
                initialState={{
                  pagination: { paginationModel: { pageSize: 25 } },
                }}
                onCellClick={(params) => {
                  if (params.field === "action" && params.row) {
                    console.log("clicked", params.row.Id);
                  }
                }}
                className="cursor-pointer"
              />
            </div>
            {/* <Button
              variant="contained"
              color="primary"
              onClick={handleConfirmSelection}
              disabled={!selectedRow}
            >
              Confirm Selection
            </Button> */}
          </Box>
        </Modal>
      </LocalizationProvider>
    </Layout>
  );
}
