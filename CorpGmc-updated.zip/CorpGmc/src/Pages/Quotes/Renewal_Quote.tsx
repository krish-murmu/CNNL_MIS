import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import React, { useEffect, useState } from "react";
import { CustomerModelFields } from "./Create_Quote";
import { BASE_API_URL } from "API/Base";
import toast from "react-hot-toast";
import { Controller, SubmitHandler, useForm } from "react-hook-form";
import {
  DataGrid,
  GridColDef,
  GridToolbar,
  GridToolbarContainer,
  GridToolbarQuickFilter,
} from "@mui/x-data-grid";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import {
  Box,
  Button,
  Checkbox,
  InputAdornment,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { VisuallyHiddenInput } from "@chakra-ui/react";
import { useTokenStore } from "../../Zustand/TokenStore";
import { GMCQuoteOutputModel, QuoteDataModel } from "types";
import LoadingAnimation from "Components/LoadingAnimation";
import { motion } from "framer-motion";

type Props = {};

interface RenewalDetails {
  QuoteNumber: number;
  Customer: string;
  Address: string;
  City: string;
  State: string;
  QuoteDate: Date;
  Previous_Insurer: string;
  Previous_Insurance_Start_Date: Date;
  Previous_Insurance_End_Date: Date;
  Premium_Inception: number;
  Premium_till_date: number;
  Members_Inception_Self: number;
  Members_Inception_Dependents: number;
  Members_Inception_Total: number;
  Members_till_date_Self: number;
  Members_till_date_Dependents: number;
  Members_till_date_Total: number;
  Claims_Quantity: number;
  Family: number;
  Amount: number;
  Outstanding: number;
  LastClaimDate: Date;
  File: File | null;
}

interface RenewalModelFields {
  Quote_No: number;
  Quote_Date: string;
  Product_Id: number;
  Quote_For: number; // CustomerId
  Previous_Insurance_Company: string;
  Previous_Policy_Start: string;
  Previous_Policy_End: string;
  Members_Inception: number;
  Members_Till_Date: number;
  Claims_Quantity: number;
  Last_Claim_Date: string;
  Claim_Amount: number;
  Claim_Outstanding: number;
}

interface Coverages {
  Id: number;
  Coverage_Name: string;
  Coverage_Detail: string;
  Coverage_Type: string;
  Parent_Coverage_Id: number;
  Parent_Coverage_Name: string;
}
interface FamilyOptions {
  Id: number;
  Status_Name: string;
  isStatus: boolean;
}

function Renewal_Quote({}: Props) {
  const [quoteNumber, setQuoteNumber] = useState<number>(0);
  const [FamilyOptions, SetFamilyOptions] = useState<FamilyOptions[]>([]);

  const get_family_options = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/quotes/gmc-quote/v1/get-family-options`
      );
      const data: FamilyOptions[] = res.data;
      if (data) {
        SetFamilyOptions(data);
      } else {
        toast.error("Error fetching data");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Error fetching data");
    }
  };

  const {
    register,
    handleSubmit,
    watch,
    control,
    setValue,
    formState: { errors },
  } = useForm<RenewalDetails>();

  // const onSubmit: SubmitHandler<RenewalDetails> = async (
  //   inputs: RenewalDetails
  // ) => {
  //   console.log(inputs);
  //   try {
  //     const customerid = rows.find(
  //       (row) => row.Customer_Name === inputs.Customer
  //     )?.Id;
  //     if (!customerid) {
  //       toast.error("Invalid Customer");
  //       return;
  //     }

  //     const data: RenewalModelFields = {
  //       Quote_No: inputs.QuoteNumber,
  //       Quote_Date: inputs.QuoteDate.toISOString().split("T")[0],
  //       Product_Id: 1,
  //       Quote_For: customerid,
  //       Previous_Insurance_Company: inputs.Previous_Insurer,
  //       Previous_Policy_Start:
  //         inputs.Previous_Insurance_Start_Date.toISOString().split("T")[0],
  //       Previous_Policy_End:
  //         inputs.Previous_Insurance_End_Date.toISOString().split("T")[0],
  //       Members_Inception: inputs.Members_Inception_Total,
  //       Members_Till_Date: inputs.Members_till_date_Total,
  //       Claims_Quantity: inputs.Claims_Quantity,
  //       Last_Claim_Date: inputs.LastClaimDate.toISOString().split("T")[0],
  //       Claim_Amount: inputs.Amount,
  //       Claim_Outstanding: inputs.Outstanding,
  //     };

  //     const res = await AxiosInstance.post(
  //       `${BASE_API_URL}/admin/quotes/renewal-quotes/v1/renewal-quote-details`,
  //       data
  //     );

  //     if (res.status === 200) {
  //       toast.success("Quote Created Successfully");
  //       const File: File = inputs.File as File;
  //       sendFile(File, quoteNumber);
  //     } else {
  //       toast.error(`Error Creating Quote: ${res.statusText}`);
  //     }
  //   } catch (error) {
  //     console.error(error);
  //     toast.error("Network or server error");
  //   }
  // };

  // const sendFile = async (file: File | null, quoteNumber: number) => {
  //   if (!file) {
  //     console.error("No file selected");
  //     // You can display an error message or take appropriate action here
  //     return;
  //   }
  //   console.log(file);
  //   const formData = new FormData();
  //   formData.append("file", file);

  //   const url = `${BASE_API_URL}/admin/quotes/gmc-quote/v2/post-data-file?quotenumber=${quoteNumber}`;

  //   try {
  //     const response = await fetch(url, {
  //       method: "POST",
  //       body: formData,
  //       // If you need to add headers like Authorization, uncomment and modify the following line
  //       headers: {
  //         Authorization: `Bearer ${useTokenStore.getState().accessToken}`,
  //       },
  //     });

  //     if (response.ok) {
  //       const result = await response.json();
  //       console.log(result);
  //       toast.success("File Uploaded Successfully");
  //       toast.success("Fetching Data");
  //       getOutputTableData();
  //       setFileSent(true);
  //     } else {
  //       // Handle HTTP errors
  //       console.error("Upload failed:", response.statusText);
  //       toast.error(`Error uploading file: ${response.statusText}`);
  //     }
  //   } catch (error) {
  //     console.error("Error:", error);
  //     toast.error(`Error uploading file: ${error}`);
  //   }
  // };

  const prepareCoveragesToSend = () => {
    const coveragesToSend = [];

    for (const [key, value] of Object.entries(inputValues)) {
      const coverageId = parseInt(key);
      const foundCoverage = Coverages.find((c) => c.Id === coverageId);

      if (foundCoverage) {
        coveragesToSend.push({
          CoverageId: coverageId,
          CoverageName: foundCoverage.Coverage_Name, // Add the name here
          Input_Type: typeof value === "boolean" ? "Boolean" : "Input",
          Value: value,
        });
      }
    }

    return coveragesToSend;
  };
  const onSubmit: SubmitHandler<RenewalDetails> = async (
    data: RenewalDetails
  ) => {
    console.log(data);

    const customerid = rows.find(
      (row) => row.Customer_Name === data.Customer
    )?.Id;
    if (!customerid) {
      toast.error("Invalid Customer");
      return;
    }

    const renewal_data = {
      Quote_No: data.QuoteNumber,
      Quote_Date: data.QuoteDate.toISOString().split("T")[0],
      Product_Id: 1,
      Quote_For: customerid,
      Previous_Insurance_Company: data.Previous_Insurer,
      Previous_Policy_Start:
        data.Previous_Insurance_Start_Date.toISOString().split("T")[0],
      Previous_Policy_End:
        data.Previous_Insurance_End_Date.toISOString().split("T")[0],
      Members_Inception: data.Members_Inception_Total,
      Members_Till_Date: data.Members_till_date_Total,
      Claims_Quantity: data.Claims_Quantity,
      Last_Claim_Date: data.LastClaimDate.toISOString().split("T")[0],
      Claim_Amount: data.Amount,
      Claim_Outstanding: data.Outstanding,
      Family: data.Family,
      Premium_Inception: data.Premium_Inception as number,
      Premium_Till_Date: data.Premium_till_date as number,
    };
    console.log(renewal_data);

    const coveragesToSend =
      prepareCoveragesToSend(); /* logic to prepare your coverages data */

    const formData = new FormData();
    formData.append("renewal_data", JSON.stringify(renewal_data));
    formData.append("coverages", JSON.stringify(coveragesToSend));

    if (data.File) {
      formData.append("file", data.File);
    }
    for (let [key, value] of formData.entries()) {
      console.log(key, value);
    }
    try {
      const res = await AxiosInstance.post(
        `${BASE_API_URL}/admin/quotes/renewal-quotes/v2/renewal-quote-details`, // Adjust the URL to your combined endpoint
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data", // This might be optional as Axios sets it automatically for FormData
            Authorization: `Bearer ${useTokenStore.getState().accessToken}`,
          },
        }
      );

      if (res.status === 200) {
        toast.success("Data submitted successfully");
        setCoverageSent(true);
        setFileSent(true);
        getOutputTableData();
        // handle successful submission
      } else {
        // Handle other HTTP responses
        toast.error(`Error: ${res.statusText}`);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error(`Error submitting data: ${error}`);
    }
    // Continue with the Axios request
  };

  const [FileName, setFileName] = useState<string>("");
  const [inceptionSelf, setInceptionSelf] = useState<number>(0);
  const [inceptionDependents, setInceptionDependents] = useState<number>(0);
  const [tillDateSelf, setTillDateSelf] = useState<number>(0);
  const [tillDateDependents, setTillDateDependents] = useState<number>(0);

  const calculateInceptionTotal = (
    self: number | undefined,
    dependents: number | undefined
  ) => {
    const selfValue = self || 0;
    const dependentsValue = dependents || 0;
    return selfValue + dependentsValue;
  };

  const calculateTillDateTotal = (
    self: number | undefined,
    dependents: number | undefined
  ) => {
    const selfValue = self || 0;
    const dependentsValue = dependents || 0;
    return selfValue + dependentsValue;
  };

  useEffect(() => {
    // When inceptionSelf changes, update the form's state
    setValue("Members_Inception_Self", inceptionSelf as number);
    setValue("Members_Inception_Dependents", inceptionDependents as number);
    setValue(
      "Members_Inception_Total",
      calculateInceptionTotal(inceptionSelf, inceptionDependents)
    );
    setValue("Members_till_date_Self", tillDateSelf as number);
    setValue("Members_till_date_Dependents", tillDateDependents as number);
    setValue(
      "Members_till_date_Total",
      calculateTillDateTotal(tillDateSelf, tillDateDependents)
    );
  }, [
    inceptionSelf,
    inceptionDependents,
    tillDateDependents,
    tillDateSelf,
    setValue,
  ]);

  //Customer Modal Functions
  const [rows, setRows] = useState<CustomerModelFields[]>([]);
  const [CustomerModel, setCustomerModal] = useState(false);
  function CustomToolbar() {
    return (
      <GridToolbarContainer className="p-4 text-black bg-primary/20 placeholder-primary">
        <GridToolbarQuickFilter />
      </GridToolbarContainer>
    );
  }
  const [selectedRow, setSelectedRow] = useState<
    CustomerModelFields | undefined
  >();
  const openCustomerModal = () => {
    setCustomerModal(true);
  };

  const closeCustomerModal = () => {
    setCustomerModal(false);
  };

  const handleConfirmSelection = () => {
    if (selectedRow) {
      setValue("Customer", selectedRow.Customer_Name);
      setValue("Address", selectedRow.Address_1);
      setValue("City", selectedRow.City_Name);
      setValue("State", selectedRow.State_Name);
      setValue("QuoteNumber", quoteNumber as number);
      closeCustomerModal();
    }
  };
  const handleRowSelection = (row: CustomerModelFields) => {
    setSelectedRow(row);
  };
  const columns: GridColDef[] = [
    {
      field: "Sr. No.",
      headerName: "Id",
      width: 100,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        // Find the index of the row in the rows array and add 1
        const rowIndex = rows.findIndex((row) => row.Id === params.row.Id) + 1;
        return <div>{rowIndex}</div>;
      },
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "Customer_Name",
      headerName: "Customer Name",
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "Address_1",
      headerName: "Address",
      // width: 200,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "City_Name",
      headerName: "City",
      // width: 160,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "State_Name",
      headerName: "State",
      // width: 150,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "Pin_Code",
      headerName: "Postal Code",
      // width: 150,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
  ];

  const fetchCustomerData = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/quotes/Master/v1/customer-details`
      );
      const data: CustomerModelFields[] = res.data;
      if (data) {
        setRows(data);
      } else {
        toast.error("Error fetching data");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Error fetching data");
    }
  };

  const generateRandomQuoteNumber = () => {
    const min = 100000;
    const max = 999999;
    const rand: number = Math.floor(min + Math.random() * (max - min + 1));
    setQuoteNumber(rand);
    setValue("QuoteNumber", rand);
  };

  //Receiving Data From THE API After file is sent
  const [OutputTable, SetOutputTable] = useState<GMCQuoteOutputModel>();
  const [FileSent, setFileSent] = useState(false);
  const [DataArrival, setDataArrival] = useState(false);

  const getOutputTableData = async () => {
    try {
      const toastId = toast.loading("Loading quote data...");
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/quotes/gmc-quote/v1/get-quote-data-by-quote-number?QuoteNumber=${quoteNumber}`
      );
      const data: GMCQuoteOutputModel = res.data;
      SetOutputTable(data);
      setDataArrival(true);
      toast.success("Data loaded successfully!", { id: toastId });
    } catch (error) {
      console.log(error);
    }
  };

  const OutputColumns: GridColDef[] = [
    {
      field: "Sr. No.",
      headerName: "Id",
      width: 100,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        // Find the index of the row in the rows array and add 1
        const rowIndex = rows.findIndex((row) => row.Id === params.row.Id) + 1;
        return <div>{rowIndex}</div>;
      },
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    // {
    //   field: "QuoteNumber",
    //   headerName: "Quote Number",
    //   width: 100,
    //   flex: 1,
    //   headerClassName:
    //     "bg-primary text-white font-bold flex flex-row items-center justify-center",
    // },
    {
      field: "EmployeeNumber",
      headerName: "Employee Number",
      width: 200,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeName",
      headerName: "Employee Name",
      width: 300,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeGender",
      headerName: "Gender",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeDOB",
      headerName: "DOB",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeRelation",
      headerName: "Relation",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeSum",
      headerName: "Sum Assured",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeAge",
      headerName: "Age",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
  ];

  const [Coverages, setCoverages] = useState<Coverages[]>([]);
  const fetchCoverages = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/coverages/v1/get-coverages`
      );
      const data: Coverages[] = res.data;
      setCoverages(data);
    } catch (e) {
      console.log(e);
    }
  };
  const [selectedCoverages, setSelectedCoverages] = useState<number[]>([]);
  const [inputValues, setInputValues] = useState<{
    [key: number]: boolean | string;
  }>({});
  const [coverageSent, setCoverageSent] = useState<boolean>(false);

  const handleCheckboxChange = (id: number, isChecked: boolean) => {
    setSelectedCoverages((prev) =>
      isChecked ? [...prev, id] : prev.filter((coverageId) => coverageId !== id)
    );
    handleInputChange(id, isChecked);
  };

  const handleInputChange = (id: number, value: boolean | string) => {
    setInputValues((prev) => ({ ...prev, [id]: value }));
  };

  const renderInput = (coverage: Coverages) => {
    return coverage.Coverage_Type === "Boolean" ? (
      <Checkbox
        disabled={coverageSent}
        checked={!!inputValues[coverage.Id]}
        onChange={(e) => handleCheckboxChange(coverage.Id, e.target.checked)}
      />
    ) : (
      <input
        type="number"
        disabled={coverageSent}
        value={(inputValues[coverage.Id] as string) || ""}
        onChange={(e) => handleInputChange(coverage.Id, e.target.value)}
        className="pl-2 ml-2 transition-all duration-200 ease-in-out border rounded border-slate-700 hover:border-primary active:border-primary"
      />
    );
  };

  const variants = {
    open: { opacity: 1, height: "auto" },
    collapsed: { opacity: 0, height: 0 },
  };

  const renderChildCoverages = (parentId: number) => {
    const isVisible = selectedCoverages.includes(parentId);

    return (
      <motion.ul
        initial="collapsed"
        animate={isVisible ? "open" : "collapsed"}
        variants={variants}
        transition={{ duration: 0.5, ease: "easeInOut" }}
        className="overflow-hidden list-disc"
      >
        {Coverages.filter(
          (coverage) => coverage.Parent_Coverage_Id === parentId
        ).map((childCoverage) => (
          <li
            key={childCoverage.Id}
            className="flex flex-row items-center mb-2 ml-4"
          >
            <span>{childCoverage.Coverage_Name}</span>
            {renderInput(childCoverage)}
          </li>
        ))}
      </motion.ul>
    );
  };

  const renderCoverages = (Coverages: Coverages[]) => {
    return (
      <ul className="list-decimal">
        {Coverages.filter((coverage) => coverage.Parent_Coverage_Id === 0).map(
          (coverage) => (
            <li key={coverage.Id} className="">
              <span>{coverage.Coverage_Name}</span>
              {renderInput(coverage)}
              {selectedCoverages.includes(coverage.Id) && (
                <ul>{renderChildCoverages(coverage.Id)}</ul>
              )}
            </li>
          )
        )}
      </ul>
    );
  };

  useEffect(() => {
    fetchCustomerData();
    generateRandomQuoteNumber();
    fetchCoverages();
    get_family_options();
  }, []);

  return (
    <Layout>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <div className="flex flex-col w-full h-full px-8 pt-2 mb-16">
          <div className="flex flex-row w-full ">
            <Header title={"Renewal Quote"} subtitle={""} />
          </div>
          <div className="flex flex-col items-center justify-center w-full h-auto">
            <div className="flex flex-row items-center w-full h-16 mb-2 justify-normal text-primary ">
              <h1 className="text-3xl font-semibold">Insert Quote Details</h1>
            </div>
            <form
              // onSubmit={(e) => {
              //   e.preventDefault();
              //   handleSubmit(onSubmit)();
              // }}
              aria-disabled={FileSent}
              onSubmit={handleSubmit(onSubmit)}
              className="flex flex-col w-full h-full pt-2 gap-y-4"
            >
              <div className="flex flex-row items-center w-full gap-x-2 justify-normal">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="QuoteNumber"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={quoteNumber}
                    // ... your validation rules for QuoteNumber ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        className="w-full h-full"
                        disabled={true}
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Quote Number:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller // Date Picker
                    name="QuoteDate"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={new Date()}
                    // ... your validation rules for QuoteDate ...
                    render={({ field }) => (
                      <DatePicker
                        {...field}
                        disabled={FileSent}
                        label="Quote Date"
                        className="w-full h-full"
                        onChange={(date: Date | null) => {
                          if (date) {
                            setValue("QuoteDate", date); // Set the selected date to the form input
                          }
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 justify-normal">
                  <Controller
                    name="Customer"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={""}
                    // ... your validation rules for Customer ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        error={Boolean(errors.Customer)}
                        onClick={openCustomerModal}
                        className="w-full h-full"
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Customer:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Address"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={""}
                    // ... your validation rules for Address ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        error={Boolean(errors.Address)}
                        onClick={openCustomerModal}
                        className="w-full h-full"
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Address:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="City"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={""}
                    // ... your validation rules for City ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        onClick={openCustomerModal}
                        error={Boolean(errors.City)}
                        className="w-full h-full"
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                City:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="State"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={""}
                    // ... your validation rules for State ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        onClick={openCustomerModal}
                        error={Boolean(errors.State)}
                        className="w-full h-full"
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                State:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full mt-2">
                <h3 className="text-3xl font-semibold text-primary">
                  Previous Insurance Details
                </h3>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Previous_Insurer"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={""}
                    // ... your validation rules for Previous_Insurer ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        className="w-full h-full disabled:text-black"
                        InputLabelProps={{ shrink: true }}
                        error={Boolean(errors.Previous_Insurer)}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Previous Insurer:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Previous_Insurance_Start_Date"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={new Date()}
                    // ... your validation rules for Previous_Insurance_Start_Date ...
                    render={({ field }) => (
                      <DatePicker
                        {...field}
                        disabled={FileSent}
                        label="Previous Insurance Start Date"
                        className="w-full h-full"
                        onChange={(date: Date | null) => {
                          if (date) {
                            setValue("Previous_Insurance_Start_Date", date); // Set the selected date to the form input
                          }
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Previous_Insurance_End_Date"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={new Date()}
                    // ... your validation rules for Previous_Insurance_End_Date ...
                    render={({ field }) => (
                      <DatePicker
                        {...field}
                        disabled={FileSent}
                        label="Previous Insurance End Date"
                        className="w-full h-full"
                        onChange={(date: Date | null) => {
                          if (date) {
                            setValue("Previous_Insurance_End_Date", date); // Set the selected date to the form input
                          }
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-row items-center w-1/3 h-full">
                  <InputLabel
                    htmlFor="family"
                    className="font-semibold text-black placeholder:text-black"
                  >
                    <span className="text-black">Family Type : </span>
                  </InputLabel>
                  <Select
                    error={Boolean(errors.Family)}
                    className="w-[70%] h-full"
                    label="Family"
                    disabled={FileSent}
                    sx={{ ":placeholder-shown": { color: "red" } }}
                    aria-label="Family"
                    placeholder="Select Family Type"
                    {...register("Family", {
                      required: "This Field Is Required",
                    })}
                  >
                    {FamilyOptions.map((option) => (
                      <MenuItem key={option.Id} value={option.Id}>
                        {option.Status_Name}
                      </MenuItem>
                    ))}
                  </Select>
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Premium_Inception"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Premium_Inception ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        className="w-full h-full"
                        type="number"
                        InputLabelProps={{ shrink: true }}
                        error={Boolean(errors.Premium_Inception)}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Premium at Inception: &#8377;
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Premium_till_date"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Premium_till_date ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        className="w-full h-full"
                        InputLabelProps={{ shrink: true }}
                        error={Boolean(errors.Premium_till_date)}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Premium Till Date: &#8377;
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full mt-2">
                <h3 className="text-3xl font-semibold text-primary">
                  Members at Inception
                </h3>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/4 h-full">
                  <Controller
                    name="Members_Inception_Self"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Members_Inception_Self ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        className="w-full h-full"
                        error={Boolean(errors.Members_Inception_Self)}
                        onChange={(e) =>
                          setInceptionSelf(parseInt(e.target.value, 10))
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Self:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/4 h-full">
                  <Controller
                    name="Members_Inception_Dependents"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Members_Inception_Dependents ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        error={Boolean(errors.Members_Inception_Dependents)}
                        className="w-full h-full"
                        onChange={(e) =>
                          setInceptionDependents(parseInt(e.target.value, 10))
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Dependents:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                {/* Add Both For Total Members */}
                <div className="flex flex-col items-center w-1/4 h-full">
                  {/* Add Self and Dependent for total members */}
                  <Controller
                    name="Members_Inception_Total"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Members_Inception_Total ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        className="w-full h-full "
                        error={Boolean(errors.Members_Inception_Total)}
                        value={calculateInceptionTotal(
                          inceptionSelf,
                          inceptionDependents
                        )}
                        disabled={true}
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Total:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full mt-2">
                <h3 className="text-3xl font-semibold text-primary">
                  Members Till Date
                </h3>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/4 h-full">
                  <Controller
                    name="Members_till_date_Self"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Members_till_date_Self ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        error={Boolean(errors.Members_till_date_Self)}
                        type="number"
                        className="w-full h-full"
                        onChange={(e) =>
                          setTillDateSelf(parseInt(e.target.value, 10))
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Self:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/4 h-full">
                  <Controller
                    name="Members_till_date_Dependents"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Members_till_date_Dependents ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        className="w-full h-full"
                        error={Boolean(errors.Members_till_date_Dependents)}
                        onChange={(e) =>
                          setTillDateDependents(parseInt(e.target.value, 10))
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Dependents:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                {/* Add Both For Total Members */}
                <div className="flex flex-col items-center w-1/4 h-full">
                  {/* Add Self and Dependent for total members */}
                  <Controller
                    name="Members_till_date_Total"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Members_till_date_Total ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        className="w-full h-full "
                        value={calculateTillDateTotal(
                          tillDateSelf,
                          tillDateDependents
                        )}
                        error={Boolean(errors.Members_till_date_Total)}
                        disabled={true}
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography
                                variant="subtitle1"
                                className="text-black"
                              >
                                Total:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full mt-2">
                <h3 className="text-3xl font-semibold text-primary">
                  Claim Particulars
                </h3>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col w-1/3 h-full">
                  <Controller
                    name="Claims_Quantity"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Claims_Quantity ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        className="w-full h-full"
                        error={Boolean(errors.Claims_Quantity)}
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography variant="subtitle1" color="black">
                                No. of Claims:
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                {/* data */}
                <div className="flex flex-col w-1/3 h-full">
                  <Controller
                    name="LastClaimDate"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    defaultValue={new Date()}
                    // ... your validation rules for LastClaimDate ...
                    render={({ field }) => (
                      <DatePicker
                        {...field}
                        disabled={FileSent}
                        label="Last Claim Date"
                        className="w-full h-full"
                        onChange={(date: Date | null) => {
                          if (date) {
                            setValue("LastClaimDate", date); // Set the selected date to the form input
                          }
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Amount"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Amount ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        error={Boolean(errors.Amount)}
                        className="w-full h-full"
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography variant="subtitle1" color="black">
                                Amount: &#8377;
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    name="Outstanding"
                    control={control}
                    rules={{ required: "Customer field is required" }}
                    // ... your validation rules for Outstanding ...
                    render={({ field }) => (
                      <TextField
                        {...field}
                        disabled={FileSent}
                        type="number"
                        className="w-full h-full"
                        error={Boolean(errors.Outstanding)}
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Typography variant="subtitle1" color="black">
                                Outstanding: &#8377;
                              </Typography>
                            </InputAdornment>
                          ),
                        }}
                      />
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-center w-full justify-normal">
                <h3 className="text-3xl font-semibold text-primary ">
                  Select Coverage
                </h3>
              </div>
              <div className="flex flex-col w-full pl-4">
                {renderCoverages(Coverages)}
              </div>

              <div className="flex flex-row items-center w-full gap-x-2">
                <div className="flex flex-col items-center w-1/3 h-full">
                  <Controller
                    control={control}
                    name="File"
                    rules={{ required: "File is required" }}
                    render={({ field }) => (
                      <Button
                        component="label"
                        variant="contained"
                        disabled={FileSent}
                        className="w-full h-12"
                        startIcon={<CloudUploadIcon className="text-white " />}
                      >
                        <span className="text-white">Upload file</span>
                        <VisuallyHiddenInput
                          required={true}
                          disabled={FileSent}
                          type="file"
                          accept=".xlsx, .xls ,.txt ,.csv"
                          onChange={(e) => {
                            const file = e.target?.files?.[0];
                            field.onChange(file);
                            setFileName(file?.name ?? "");
                          }}
                        />
                      </Button>
                    )}
                  />
                </div>
                <div className="flex flex-col items-center w-1/3 h-full">
                  {FileName === "" ? null : (
                    <button
                      type="submit"
                      className="flex flex-row items-center justify-center w-full h-12 transition-all duration-200 ease-in-out bg-white border rounded-md border-primary text-primary hover:bg-primary hover:text-white hover:border-transparent"
                    >
                      Submit
                    </button>
                  )}
                </div>
              </div>
            </form>
          </div>
          {FileSent && !DataArrival ? (
            <LoadingAnimation />
          ) : FileSent && DataArrival ? (
            <>
              <div className="flex flex-col items-center w-full mt-2 gap-y-8">
                {/* Data Grid */}
                <DataGrid
                  className="w-full"
                  rows={OutputTable?.QuoteData ?? []}
                  columns={OutputColumns}
                  getRowId={(row: QuoteDataModel) => row.Id}
                  autoHeight
                  slots={{
                    toolbar: GridToolbar,
                  }}
                  pagination
                  pageSizeOptions={[5, 10, 25]}
                  initialState={{
                    pagination: { paginationModel: { pageSize: 5 } },
                  }}
                  onCellClick={(params) => {
                    if (params.field === "action" && params.row) {
                      console.log("clicked", params.row.Id);
                    }
                  }}
                />
                <div className="w-full row-span-6">
                  <div className="flex flex-row items-center justify-center w-full h-16 border-b border-white bg-primary">
                    <h3 className="text-2xl text-white">Age Counts</h3>
                  </div>
                  <div className="grid w-full h-12 grid-cols-2">
                    <div className="flex flex-row items-center justify-center w-full text-white border-b bg-primary border-x border-slate-500">
                      <h1 className="">Age Groups</h1>
                    </div>
                    <div className="flex flex-row items-center justify-center w-full text-white border-b bg-primary border-x border-slate-500">
                      <h1 className="">Counts</h1>
                    </div>
                  </div>
                  <div className="grid w-full grid-cols-2">
                    {OutputTable?.AgeGroups.map((item, index) => {
                      return (
                        <>
                          <div
                            key={item.AgeGroup}
                            className="flex flex-row items-center justify-center w-full h-12 text-white border-b bg-primary/10 border-x border-slate-500"
                          >
                            <h1 className="text-black">
                              People Between the Ages : {item.AgeGroup}
                            </h1>
                          </div>
                          <div className="flex flex-row items-center justify-center w-full border-b bg-primary/10 border-x border-slate-500">
                            <h1 className="text-black ">
                              {item.AgeGroupCount}
                            </h1>
                          </div>
                        </>
                      );
                    })}
                  </div>
                </div>
              </div>
            </>
          ) : null}
        </div>
        <Modal
          key={"Customer Modal"}
          open={CustomerModel}
          onClose={closeCustomerModal}
        >
          <Box className="absolute top-1/2 left-1/2 w-11/12 h-[90%] transform -translate-x-1/2 -translate-y-1/2 bg-white shadow-md px-8 pb-8 min-w-[400px] flex flex-col items-center justify-center gap-y-4">
            <h2 className="text-3xl font-semibold text-primary">
              Select Customer
            </h2>
            <div className="w-full h-full">
              <DataGrid
                rows={rows}
                //adjustable column widths

                columns={columns}
                getRowId={(row: CustomerModelFields) => row.Id}
                autoHeight
                slots={{
                  toolbar: CustomToolbar,
                }}
                pagination
                onRowDoubleClick={(params) => {
                  // Handle double-click selection here
                  handleRowSelection(params.row as CustomerModelFields);
                  handleConfirmSelection();
                }}
                initialState={{
                  pagination: { paginationModel: { pageSize: 25 } },
                }}
                onCellClick={(params) => {
                  if (params.field === "action" && params.row) {
                    console.log("clicked", params.row.Id);
                  }
                }}
                className="cursor-pointer"
              />
            </div>
          </Box>
        </Modal>
      </LocalizationProvider>
    </Layout>
  );
}

export default Renewal_Quote;
