import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import type { Users as UsersType, WrapTextCellProps } from "types";
import { format, parseISO } from "date-fns";
import DeleteModal from "Modals/DeleteModal";
import { DataGrid, GridColDef, GridToolbar } from "@mui/x-data-grid";
import theme from "theme";
import Header from "Components/Header";
import { Button } from "@mui/material";
import { Box } from "@mui/system";
import toast from "react-hot-toast";
import { CircularProgress } from "@mui/material";
import PaginationButtons from "Components/PaginationButtons";
import { AddBox, Delete, EditNote, MenuBook } from "@mui/icons-material";

const Users: React.FC = () => {
  const [rows, setRows] = useState<UsersType[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [rowCount, setRowCount] = useState<number>(0);

  const navigate = useNavigate();

  function base64Encode(str: string) {
    return btoa(str);
  }

  // Base64 decoding function
  function base64Decode(encodedStr: string) {
    return atob(encodedStr);
  }

  const fetchData = async (page: number, pageSize: number) => {
    try {
      setLoading(true);
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/users/v1/users`,
        {
          params: {
            page,
            per_page: pageSize,
          },
        }
      );

      if (
        !response.data ||
        !response.data.users_data ||
        response.data.total_count == null
      ) {
        console.error("Invalid response format:", response.data);
        setLoading(false);
        return;
      }
      const formattedData = response.data.users_data.map(
        (row: UsersType, index: number) => ({
          ...row,
          actionsID: startIndex + index + 1,
          Id: row.Id,
        })
      );

      setRows(formattedData);
      setRowCount(response.data.total_count);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false); // Make sure to set loading to false in case of an error
    }
  };
  useEffect(() => {
    fetchData(currentPage, pageSize);
  }, [currentPage, pageSize]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  const handleAdd = () => {
    navigate("/user/manage/form/create");
  };

  const handleDeleteCancel = () => {
    setIsDeleteModalOpen(false);
  };

  const handleView = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/user/manage/form/view/${encodedId}`);
  };

  const handleEdit = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/user/manage/form/edit/${encodedId}`);
  };

  const coloumns: GridColDef[] = [
    {
      field: "actionsID",
      headerName: "ID",
      width: 70,
    },
    {
      field: "actions",
      headerName: "Actions",
      width: 220,
      renderCell: (params: any) => (
        <div className="cellAction">
          <div className="viewButton" onClick={() => handleView(params.row)}>
            <MenuBook sx={{ fontSize: "20px" }} />
          </div>
          <div className="editButton" onClick={() => handleEdit(params.row)}>
            <EditNote sx={{ fontSize: "20px" }} />
          </div>
          <div
            className="deleteButton"
            onClick={() => handleDelete(params.row.Id)}
          >
            <Delete sx={{ fontSize: "20px" }} />
          </div>
        </div>
      ),
    },

    {
      field: "User_Name",
      headerName: "Username",
      width: 160,
    },
    {
      field: "Email_Id",
      headerName: "Email ID",
      width: 250,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Mobile_No",
      headerName: "Mobile number",
      width: 250,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "Role_Names",
      headerName: "Role Names",
      width: 200,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "Customer_Name",
      headerName: "Customer Name",
      width: 200,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "IsStatus",
      headerName: "Status",
      width: 120,
      renderCell: (params) => (
        <div
          className={`cellWithStatus ${params.value ? "active" : "inactive"}`}
        >
          {params.value ? "Active" : "Inactive"}
        </div>
      ),
    },
    {
      field: "User_Type_Name",
      headerName: "User Type",
      width: 200,
      renderCell: (params) => (
        <div
          className={`cellWithStatus ${params.value ? "active" : "inactive"}`}
        >
          {params.value || "N/A"}
        </div>
      ),
    },
  ];

  const handleDelete = (id: string) => {
    const encodedId = base64Encode(id);
    setIsDeleteModalOpen(true);
    setSelectedRowId(encodedId);
  };

  const handleDeleteConfirm = async () => {
    try {
      const decodedId = selectedRowId ? base64Decode(selectedRowId) : null;

      const response = await AxiosInstance.delete(
        `${BASE_API_URL}/admin/users/v1/users/${decodedId}`
      );

      if (response.data) {
        // Remove the deleted row from the local state
        setIsDeleteModalOpen(false);
        setRows((prevRows) =>
          prevRows.filter((row: any) => row.Id.toString() !== decodedId)
        );
        toast.success("Data deleted successfully");
      } else {
        toast.error("Error deleting data");
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      setIsDeleteModalOpen(false);
    }
  };

  return (
    <Layout>
      <div className="datatable">
        <div className="datatableTitle">
          <Header title="Users Master" subtitle="" />
          <div className="flex space-x-2">
            <Button className="link" onClick={handleAdd}>
              <AddBox sx={{ fontSize: "40px" }} />
            </Button>
          </div>
        </div>

        <Box
          // height="75vh"
          width={"1100px"}
          margin={"auto"}
          sx={{
            "& .MuiDataGrid-root": {
              border: "none",
              borderBottom: `2px solid ${theme.palette.secondary.light}`,
            },

            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: theme.palette.primary.main,
              borderBottom: "none",
              fontWeight: "bold",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              color: "#fff !important",
            },

            "& .MuiDataGrid-colCell": {
              color: `#fff !important`,
            },

            "& .MuiDataGrid-footerContainer": {
              display: "none",
            },
          }}
        >
          <DataGrid
            rows={rows}
            columns={coloumns}
            getRowId={(row) => row.Id}
            autoHeight
            loading={loading}
          />
        </Box>
        <PaginationButtons
          currentPage={currentPage}
          totalPages={totalPages}
          handlePageChange={handlePageChange}
        />
      </div>
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        title="Confirm Deletion"
        message="Are you sure you want to delete this data?"
      />
    </Layout>
  );
};

export default Users;
