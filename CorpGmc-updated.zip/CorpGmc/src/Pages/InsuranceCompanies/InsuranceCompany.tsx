import { DataGrid, GridColDef, GridToolbar } from "@mui/x-data-grid";
import { Box, Button, ThemeProvider } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { format, parseISO } from "date-fns";
import theme from "../../theme";
import { BASE_API_URL } from "API/Base";
import { CustomerDetails, WrapTextCellProps } from "types";
import Header from "Components/Header";
import Layout from "Components/Layout";
import DeleteModal from "Modals/DeleteModal";
import toast, { Toaster } from "react-hot-toast";
import { usePermission } from "Components/ActionPermission";
import AxiosInstance from "API/axios";
import PaginationButtons from "Components/PaginationButtons";
import { usePagePermissions } from "Components/PagePermissions";
import { AddBox, Delete, EditNote, MenuBook } from "@mui/icons-material";

export const formatDate = (dateString: string) => {
  if (!dateString) {
    return "N/A";
  }
  const date = parseISO(dateString);
  return format(date, "M/dd/yyyy h:mm:ss a");
};

const InsuranceCompany = () => {
  const [rows, setRows] = useState<CustomerDetails[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [rowCount, setRowCount] = useState<number>(0);

  const navigate = useNavigate();

  // Fetch permissions for Address module
  const permissions = usePagePermissions("Customers");

  const base64Encode = (str: string) => {
    return btoa(str);
  };
  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };
  const fetchCustomerData = async (page: number, pageSize: number) => {
    try {
      setLoading(true);
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/insurance-companies/v1/insurance-companies`,
        {
          params: {
            page,
            per_page: pageSize,
          },
        }
      );

      if (
        !response.data ||
        !response.data.insurance_companies ||
        response.data.total_count == null
      ) {
        console.error("Invalid response format:", response.data);
        setLoading(false);
        return;
      }

      const formattedData = response.data.insurance_companies.map(
        (row: CustomerDetails, index: number) => ({
          ...row,
          actionsID: startIndex + index + 1,
          Id: row.Id,
        })
      );

      setRows(formattedData);
      setRowCount(response.data.total_count);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (permissions.List) {
      fetchCustomerData(currentPage, pageSize);
    }
  }, [currentPage, pageSize, permissions]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };
  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  const handleCreate = () => {
    navigate("/insurance-companies/manage/form/create");
  };

  const handleEdit = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/insurance-companies/manage/form/edit/${encodedId}`);
  };

  const handleView = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/insurance-companies/manage/form/view/${encodedId}`);
  };

  const handleDelete = (id: string) => {
    const encodedId = base64Encode(id);
    setIsDeleteModalOpen(true);
    setSelectedRowId(encodedId);
  };

  const handleDeleteCancel = () => {
    setIsDeleteModalOpen(false);
  };

  // Conditionally define the Action column based on permissions
  const actionColumn =
    permissions.Update || permissions.Delete || permissions.View
      ? {
          field: "action",
          headerName: "Action",
          width: 200,
          renderCell: (params: any) => (
            <div className="cellAction">
              {permissions.Update && (
                <div
                  className="editButton"
                  onClick={() => handleEdit(params.row)}
                >
                  <EditNote sx={{ fontSize: "20px" }} />
                </div>
              )}
              {permissions.Delete && (
                <div
                  className="deleteButton"
                  onClick={() => handleDelete(params.row.Id)}
                >
                  <Delete sx={{ fontSize: "20px" }} />
                </div>
              )}
              {permissions.View && (
                <div
                  className="viewButton"
                  onClick={() => handleView(params.row)}
                >
                  <MenuBook sx={{ fontSize: "20px" }} />
                </div>
              )}
            </div>
          ),
        }
      : undefined;

  const columns: GridColDef[] = [
    {
      field: "actionsID",
      headerName: "ID",
      width: 70,
    },
    ...(actionColumn ? [actionColumn] : []),
    {
      field: "Insurance_Company_Name",
      headerName: "Insurance Company",
      width: 250,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },

    {
      field: "Address_1",
      headerName: "Address",
      width: 300,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },

    {
      field: "CP_Name",
      headerName: "Contact Person",
      width: 180,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
  ];

  const handleDeleteConfirm = async () => {
    try {
      const decodedId = selectedRowId ? base64Decode(selectedRowId) : null;
      const response = await AxiosInstance.delete(
        `${BASE_API_URL}/admin/insurance-companies/v1/insurance-companies/${decodedId}`
      );

      if (response.data) {
        // Remove the deleted row from the local state
        setIsDeleteModalOpen(false);
        setRows((prevRows) =>
          prevRows.filter((row: any) => row.Id.toString() !== decodedId)
        );
        toast.success("Data deleted successfully");
      } else {
        toast.error("Error deleting data");
      }
    } catch (error) {
      console.error("Error deleting data:", error);
      setIsDeleteModalOpen(false);
    }
  };

  return (
    <Layout>
      <ThemeProvider theme={theme}>
        <div className="datatable">
          <div className="datatableTitle">
            <Header title="Insurance Companies" subtitle="" />
            <div className="flex space-x-2">
              {permissions.Add && (
                <Button className="link" onClick={handleCreate}>
                  <AddBox sx={{ fontSize: "40px" }} />
                </Button>
              )}
            </div>
          </div>

          <Box
            width="1100px"
            margin={"auto"}
            //
            // width="70%"
            // position="relative"
            // borderRadius="4px"
            // overflow="auto"
            // bgcolor={theme.palette.secondary.light}
            // color={theme.palette.primary.main}
            // boxShadow={theme.shadows[2]}
            // border={`1px solid ${theme.palette.secondary.light}`}

            sx={{
              "& .MuiDataGrid-root": {
                border: "none",
                borderBottom: `2px solid ${theme.palette.secondary.light}`,
              },

              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: theme.palette.primary.main,
                borderBottom: "none",
                fontWeight: "bold",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                color: "#fff !important",
              },

              "& .MuiDataGrid-colCell": {
                color: `#fff !important`,
              },

              "& .MuiDataGrid-footerContainer": {
                display: "none",
              },
            }}
          >
            <DataGrid
              rows={rows}
              columns={columns}
              getRowId={(row) => row.Id}
              autoHeight
              loading={loading}
            />
          </Box>
          <PaginationButtons
            currentPage={currentPage}
            totalPages={totalPages}
            handlePageChange={handlePageChange}
          />
        </div>

        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={handleDeleteCancel}
          onConfirm={handleDeleteConfirm}
          title="Confirm Deletion"
          message="Are you sure you want to delete this data?"
        />
      </ThemeProvider>
    </Layout>
  );
};

export default InsuranceCompany;
