import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  ThemeProvider,
} from "@mui/material";
import { BASE_API_URL } from "API/Base";
import Header from "Components/Header";
import Layout from "Components/Layout";
import AddressDataModal from "Modals/AddressDataModal";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import CDAccDataModal from "Modals/CDAccDataModal";
import CPDataModal from "Modals/CPDataModal";
import theme from "theme";
import { ProductDetails, CRUDFormPageProps } from "types";
import AxiosInstance from "API/axios";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState<boolean>(false);
  const [selectedAddress, setSelectedAddress] = useState<any>(null);
  const [isCPModalOpen, setIsCPModalOpen] = useState<boolean>(false);
  const [selectedCP, setSelectedCP] = useState<any>(null);
  const [editedValues, setEditedValues] = useState<any>({});
  const [formData, setFormData] = useState({
    Insurance_Company_Name: "",
    Company_Address: "",
    Contact_Person: "",
  });
  const [errors, setErrors] = useState({
    Insurance_Company_Name: "",
    Company_Address: "",
    Contact_Person: "",
  });

  const navigate = useNavigate();

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);

      setFormData({
        Insurance_Company_Name: data.Insurance_Company_Name || "",
        Company_Address: data.Company_Address || "",
        Contact_Person: data.Contact_Person || "",
      });

      setSelectedAddress(data.Address_1);
      setSelectedCP(data.CP_Name);
    }
  }, [mode, data]);

  const handleInputChange = (key: string, value: any) => {
    setFormData({
      ...formData,
      [key]: value,
    });
  };
  const handleBack = () => {
    navigate("/insurance-companies/manage");
  };
  const handleAddressModalClose = () => {
    setIsAddressModalOpen(false);
  };

  const handleSelectedAddress = (selectedAddress: any) => {
    setIsAddressModalOpen(false); // Close the modal
    setSelectedAddress(selectedAddress); // Set the selected address
    console.log(selectedAddress);
    handleInputChange("Company_Address", selectedAddress.Company_Address); // Update the form and edited values
  };

  const handleSubmit = async () => {
    try {
      if (mode === "create") {
        const newData = {
          Insurance_Company_Name: formData.Insurance_Company_Name,
          Company_Address: selectedAddress?.Id,
          Contact_Person: selectedCP?.Id,
        };
        console.log(newData);
        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/insurance-companies/v1/insurance-companies`,
          newData
        );
        if (response.data) {
          toast.success("Insurance company created successfully");
        }
      } else if (mode === "edit") {
        const newData = {
          Insurance_Company_Name: formData.Insurance_Company_Name,
          Company_Address: selectedAddress?.Id || formData.Company_Address,
          Contact_Person: selectedCP?.Id || formData.Contact_Person,
        };

        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/insurance-companies/v1/insurance-companies/${editedValues.Id}`,
          newData
        );

        if (response.data) {
          toast.success("Insurance company updated successfully");
        }
      }
    } catch (error: any) {
      if (error.response) {
        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        } else {
          // Handle other error status codes
          toast.error(`Server Error: ${error.response.status}`);
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <ThemeProvider theme={theme}>
        <AddressDataModal
          isOpen={isAddressModalOpen}
          onClose={handleAddressModalClose}
          onSelectedAddress={handleSelectedAddress}
        />
        <CPDataModal
          isOpen={isCPModalOpen}
          onClose={() => setIsCPModalOpen(false)}
          onSelectedCP={(selectedCP: any) => setSelectedCP(selectedCP)}
        />
        {loading && (
          <Box
            sx={{
              position: "fixed",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",

              zIndex: 1000,
            }}
          >
            <CircularProgress size={50} />
          </Box>
        )}

        <Box sx={{ width: "80%", margin: "50px auto" }}>
          <Header
            title={
              mode === "view"
                ? "View insurance company details"
                : mode === "edit"
                ? "Edit insurance company Details"
                : mode === "create"
                ? "Add new insurance company"
                : ""
            }
            subtitle={""}
          />

          <Grid container spacing={2}>
            {mode === "create" && (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="Company Name"
                    fullWidth
                    margin="normal"
                    variant="outlined"
                    value={formData.Insurance_Company_Name}
                    sx={{ marginBottom: "16px" }}
                    onChange={(e) =>
                      handleInputChange(
                        "Insurance_Company_Name",
                        e.target.value
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Address"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={selectedAddress?.Address_1 || ""}
                    onClick={() => setIsAddressModalOpen(true)}
                    onChange={(e) =>
                      handleInputChange("Company_Address", e.target.value)
                    }
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    label="Contact Person"
                    fullWidth
                    margin="normal"
                    variant="outlined"
                    onClick={() => setIsCPModalOpen(true)}
                    value={selectedCP?.CP_Name || ""}
                    sx={{ marginBottom: "16px" }}
                    onChange={(e) =>
                      handleInputChange("Contact_Person", e.target.value)
                    }
                  />
                </Grid>
              </>
            )}
            {mode === "edit" && (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="Company Name"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={formData.Insurance_Company_Name || ""}
                    sx={{ marginBottom: "16px" }}
                    onChange={(e) =>
                      handleInputChange(
                        "Insurance_Company_Name",
                        e.target.value
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Address"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={selectedAddress?.Address_1 || data.Address_1 || ""}
                    onClick={() => setIsAddressModalOpen(true)}
                    onChange={(e) =>
                      handleInputChange("Company_Address", e.target.value)
                    }
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    label="Contact Person"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={selectedCP?.CP_Name || data.CP_Name || ""}
                    onClick={() => setIsCPModalOpen(true)}
                    sx={{ marginBottom: "16px" }}
                    onChange={(e) =>
                      handleInputChange("Contact_Person", e.target.value)
                    }
                  />
                </Grid>
              </>
            )}
            {mode === "view" && (
              <>
                <Grid container spacing={2}>
                  {fields.map(({ label, key, type }) => (
                    <Grid item xs={6} key={key}>
                      <TextField
                        key={key}
                        label={label}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        value={data[key] || ""}
                      />
                    </Grid>
                  ))}
                </Grid>
              </>
            )}
          </Grid>

          <Box mt={2} display="flex" justifyContent="space-between">
            {mode === "edit" && (
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                sx={{
                  color: "#fff",
                }}
              >
                Save Changes
              </Button>
            )}

            {mode === "create" && (
              <Button
                variant="contained"
                color="primary"
                sx={{
                  color: "#fff",
                }}
                onClick={handleSubmit}
              >
                Create
              </Button>
            )}
            <Button
              variant="outlined"
              onClick={handleBack}
              sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            >
              Back
            </Button>
          </Box>
        </Box>
      </ThemeProvider>
      <Toaster />
    </Layout>
  );
};

export default CRUDForm;
