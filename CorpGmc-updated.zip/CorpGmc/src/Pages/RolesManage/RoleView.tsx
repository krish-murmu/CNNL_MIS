import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useParams } from "react-router";
import Chip from "@mui/material/Chip";
type Props = {};

interface Role {
  id: string;
  // Add more properties as needed
}

interface PageActionsAndRoleActions {
  Page_Id: number;
  Page_Name: string;
  Page_Actions: number[];
  Role_Actions: number[];
}

interface GetRoleWithPagesAndActionsModel {
  Role_Id: number;
  Role_Name: string;
  isStatus: number;
  PagesAndActions: PageActionsAndRoleActions[];
}

function RoleView({}: Props) {
  const { id } = useParams<{ id: string }>();
  const [role, setRole] = useState<GetRoleWithPagesAndActionsModel | null>(
    null
  );

  const get_role_details = async () => {
    try {
      const res = await AxiosInstance.get(
        `/admin/roles/v1/get-role-pages/${id}`
      );
      if (res.status === 200) {
        const data: GetRoleWithPagesAndActionsModel = res.data;
        setRole(data);
        console.log(data);
      }
    } catch (error) {
      toast.error("Error retrieving role details");
      console.error("Error retrieving roles:", error);
      return []; // Return an empty array in case of error
    }
  };

  useEffect(() => {
    get_role_details();
  }, [id]);

  const acitonwithnames = [
    { id: 1, name: "List" },
    { id: 2, name: "Add" },
    { id: 3, name: "Update" },
    { id: 4, name: "Delete" },
    { id: 5, name: "View" },
    { id: 6, name: "Print" },
    { id: 7, name: "Export" },
    { id: 8, name: "Approval" },
    { id: 9, name: "Transfer" },
    { id: 10, name: "Cancel" },
  ];

  return (
    <Layout>
      <div className="flex flex-col items-center w-full h-full p-8 mb-16">
        <div className="flex flex-row items-center w-full justify-normal">
          <Header
            title={`Edit Role : ${role?.Role_Name}`}
            subtitle={`Status : ${
              role?.isStatus === 1 ? "Active" : "Inactive"
            }`}
          />
        </div>
        <div className="w-full ">
          <div className="flex flex-col w-full pr-8">
            <div className="flex flex-row items-center justify-center w-full h-12 border-b bg-primary border-slate-500 ">
              <h3 className="text-xl font-bold text-white">Permissions</h3>
            </div>
            <div className="grid items-center w-full h-16 grid-cols-12 border-b divide-x border-x divide-primary border-slate-500 justify-normal">
              <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                <h3 className="text-lg font-semibold text-primary">ID</h3>
              </div>
              <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                <h3 className="text-lg font-semibold text-primary">Name</h3>
              </div>
              <div className="flex flex-col items-center justify-start h-full col-span-9 divide-y divide-primary">
                <h3 className="text-lg font-semibold text-primary">Actions</h3>
                <div className="flex flex-row items-center justify-center w-full divide-primary">
                  <div className="flex flex-row items-center justify-center w-1/4 ">
                    <h3>Action Name</h3>
                  </div>
                  <div className="flex flex-row items-center justify-center w-3/4">
                    <h3>Permission</h3>
                  </div>
                </div>
              </div>
            </div>
            {role?.PagesAndActions.map((page, pageIndex) => (
              <div
                key={pageIndex}
                className="grid items-center w-full grid-cols-12 border-b divide-x border-x divide-slate-500 border-slate-500 justify-normal"
              >
                <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                  <h3 className="text-lg font-semibold text-primary">
                    {pageIndex + 1}
                  </h3>
                </div>
                <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                  <h3 className="text-base font-normal text-black">
                    {page.Page_Name}
                  </h3>
                </div>
                <div className="flex flex-col items-start h-full col-span-9 divide-y divide gap-y divide-slate-500">
                  <div className="flex flex-row items-center justify-center w-full h-12 gap-x-2">
                    {page.Page_Actions.map((action, actionIndex) => (
                      <Chip
                        label={
                          acitonwithnames.find((x) => x.id === action)!.name
                        }
                        color={
                          page.Role_Actions.includes(action)
                            ? "success"
                            : "error"
                        }
                      />
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default RoleView;
