import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import AxiosInstance from "../../API/axios";
import toast from "react-hot-toast";
import Layout from "Components/Layout";
import Header from "Components/Header";
import {
  Button,
  Chip,
  FormControlLabel,
  List,
  ListItem,
  ListItemText,
  Modal,
  Switch,
  TextField,
  Typography,
} from "@mui/material";
import { Box, Theme } from "@mui/system";
import { Page } from "types";
import Loading from "Components/Loading";
import LoadingAnimation from "Components/LoadingAnimation";

interface Role {
  id: string;
  // Add more properties as needed
}

interface PageActionsAndRoleActions {
  Page_Id: number;
  Page_Name: string;
  Page_Actions: number[];
  Role_Actions: number[];
}

interface GetRoleWithPagesAndActionsModel {
  Role_Id: number;
  Role_Name: string;
  isStatus: number;
  PagesAndActions: PageActionsAndRoleActions[];
}

const RoleEdit: React.FC = () => {
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedRoleName, setEditedRoleName] = useState("");
  const [editedRole, setEditedRole] =
    useState<GetRoleWithPagesAndActionsModel | null>(null);

  const handleReviewModalOpen = () => {
    setIsReviewModalOpen(true);
  };

  const handleReviewModalClose = () => {
    setIsReviewModalOpen(false);
  };

  const handleReviewAndSubmit = async () => {
    const Data = {
      Role_Id: editedRole?.Role_Id,
      Role_Name: editedRoleName,
      isStatus: editedRole?.isStatus,
      PagesAndActions: editedRole?.PagesAndActions.filter(
        (page) => page.Role_Actions.length > 0
      ) // Filter pages that have actions
        .map((page) => {
          return {
            Page_Id: page.Page_Id,
            Actions: page.Role_Actions,
          };
        }),
    };
    console.log(Data);
    try {
      const res = await AxiosInstance.patch(
        "/admin/roles/v1/edit-role-with-actions",
        Data
      );
      if (res.status === 200) {
        toast.success("Role updated successfully");
      }
    } catch (error) {
      toast.error("Error updating role");
      console.error("Error updating role:", error);
    }
    // Add logic to handle review and submit here
    setIsReviewModalOpen(false);
  };

  const renderReviewModal = (modalRole: GetRoleWithPagesAndActionsModel) => {
    return (
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 400,
          bgcolor: "background.paper",
          maxHeight: "80vh", // Set a maximum height
          overflow: "auto", // Set overflow to scroll
          border: "2px solid #000",
          boxShadow: 24,
          p: 4,
        }}
      >
        <Typography variant="h6" id="review-modal-title" component="div">
          Review and Submit Changes
        </Typography>
        <Typography
          variant="body2"
          id="review-modal-description"
          sx={{ mt: 2 }}
        >
          <p>Role Name: {editedRoleName}</p>
          <p>Status: {modalRole?.isStatus === 1 ? "Active" : "Inactive"}</p>
          <p>Changes to Page Permissions:</p>
          <List>
            {modalRole?.PagesAndActions.map((page, pageIndex) => (
              <ListItem
                key={pageIndex}
                className="overflow-auto overflow-y-auto max-h-64"
              >
                <ListItemText
                  primary={
                    <span className="text-lg text-black">{page.Page_Name}</span>
                  }
                  secondary={
                    page.Role_Actions.length > 0 ? (
                      <>
                        <span className="mr-2 text-base text-black">
                          Permissions Changed:
                        </span>
                        {page.Role_Actions.map((actionId, actionIndex) => (
                          <Chip
                            key={actionIndex}
                            label={
                              acitonwithnames.find((x) => x.id === actionId)!
                                .name
                            }
                            size="small"
                            variant="filled"
                            color="primary"
                            style={{ marginRight: 4, marginBottom: 4 }}
                          />
                        ))}
                      </>
                    ) : (
                      "No Changes"
                    )
                  }
                />
              </ListItem>
            ))}
          </List>
        </Typography>
        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
          <Button onClick={handleReviewModalClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleReviewAndSubmit} color="primary">
            Submit
          </Button>
        </Box>
      </Box>
    );
  };

  const { id } = useParams<{ id: string }>();
  const [role, setRole] = useState<GetRoleWithPagesAndActionsModel | null>(
    null
  );

  const [Baserole, setBaseRole] =
    useState<GetRoleWithPagesAndActionsModel | null>(null);

  const get_role_details = async () => {
    try {
      const res = await AxiosInstance.get(
        `/admin/roles/v1/get-role-pages/${id}`
      );
      if (res.status === 200) {
        const data: GetRoleWithPagesAndActionsModel = res.data;
        setRole(data);
        setBaseRole(data);
        setEditedRole(data); // Initialize editedRole with the fetched data
        console.log(data);
      }
    } catch (error) {
      toast.error("Error retrieving role details");
      console.error("Error retrieving roles:", error);
      return []; // Return an empty array in case of error
    }
  };

  useEffect(() => {
    get_role_details();
  }, [id]);

  const handleEditClick = () => {
    setIsEditing(true);
    setEditedRoleName(role?.Role_Name || "");
  };

  const handleSaveClick = () => {
    setIsEditing(false);
    // Update the editedRole, not role
    setEditedRole((prevRole) => {
      if (!prevRole) return null;
      return {
        ...prevRole,
        Role_Name: editedRoleName,
      };
    });
  };

  //cancel edit
  const handleCancelClick = () => {
    if (Baserole) {
      // Create a new object based on originalRole to trigger a re-render
      setEditedRole({ ...Baserole });
    }
    setIsEditing(false);
    //set switche to default
  };

  const [allPages, setAllPages] = useState<Page[]>([]);

  // Function to get all pages with permissions
  const getPages = async () => {
    try {
      const res = await AxiosInstance.get(
        `/admin/roles/v1/get-pages-with-permissions`
      );
      const pages: Page[] = res.data;
      console.log(pages);
      setAllPages(pages); // Update state with fetched pages
    } catch (err) {
      console.log(err);
      toast.error("Error retrieving pages with permissions");
    }
  };

  const hasAction = (pageId: number, actionId: number): boolean => {
    return (
      editedRole?.PagesAndActions.some(
        (pa) => pa.Page_Id === pageId && pa.Role_Actions.includes(actionId)
      ) ?? false
    );
  };

  const toggleAction = (pageId: number, actionId: number) => {
    setEditedRole((prevRole) => {
      if (!prevRole) return null;

      const pageIndex = prevRole.PagesAndActions.findIndex(
        (x) => x.Page_Id === pageId
      );
      if (pageIndex === -1) {
        prevRole.PagesAndActions.push({
          Page_Id: pageId,
          Page_Name:
            allPages.find((p) => p.Page_Id === pageId)?.Page_Name || "",
          Page_Actions:
            allPages
              .find((p) => p.Page_Id === pageId)
              ?.Permissions.Actions.map((a) => a.ActionsId) || [],
          Role_Actions: [actionId],
        });
      } else {
        const actionIndex =
          prevRole.PagesAndActions[pageIndex].Role_Actions.indexOf(actionId);
        if (actionIndex === -1) {
          prevRole.PagesAndActions[pageIndex].Role_Actions.push(actionId);
        } else {
          prevRole.PagesAndActions[pageIndex].Role_Actions.splice(
            actionIndex,
            1
          );
        }
      }

      return { ...prevRole };
    });
  };

  // Call getPages on component mount
  useEffect(() => {
    getPages();
  }, []); // The empty dependency array ensures this effect runs only once after the initial render

  if (!editedRole || !role) {
    return (
      <Layout>
        <LoadingAnimation />
      </Layout>
    );
  }

  const acitonwithnames = [
    { id: 1, name: "List" },
    { id: 2, name: "Add" },
    { id: 3, name: "Update" },
    { id: 4, name: "Delete" },
    { id: 5, name: "View" },
    { id: 6, name: "Print" },
    { id: 7, name: "Export" },
    { id: 8, name: "Approval" },
    { id: 9, name: "Transfer" },
    { id: 10, name: "Cancel" },
  ];

  return (
    <Layout>
      <div className="flex flex-col w-full h-full pl-8 gap-y-8">
        <div className="pt-8 pl-4 ">
          <Header title={`Edit Role : ${role.Role_Name}`} subtitle="" />
        </div>
        <div className="flex flex-row items-center justify-start w-full gap-x-4">
          <TextField
            id="outlined-basic"
            label="Role Name"
            placeholder={role.Role_Name}
            variant="outlined"
            value={editedRoleName}
            onChange={(e: {
              target: { value: React.SetStateAction<string> };
            }) => setEditedRoleName(e.target.value)}
            disabled={!isEditing}
          />
          <div className="flex flex-row items-center">
            <h3 className="text-xl font-normal">Status</h3>
            <FormControlLabel
              control={
                <Switch
                  disabled={!isEditing}
                  checked={editedRole?.isStatus === 1 ? true : false}
                  onChange={() => {
                    setEditedRole((prevRole) => {
                      if (!prevRole) return null;
                      return {
                        ...prevRole,
                        isStatus: prevRole.isStatus === 1 ? 0 : 1,
                      };
                    });
                  }}
                />
              }
              label=""
            />
          </div>
          {isEditing ? (
            <Button
              variant="contained"
              color="primary"
              onClick={handleCancelClick}
            >
              Cancel
            </Button>
          ) : (
            <Button
              variant="contained"
              color="primary"
              onClick={handleEditClick}
            >
              Edit
            </Button>
          )}
          {isEditing ? (
            <Button
              variant="contained"
              color="primary"
              onClick={() => {
                handleReviewModalOpen();
              }}
            >
              Review Changes and Submit
            </Button>
          ) : null}
        </div>
        <div className="w-full ">
          <div className="flex flex-col w-full pr-8">
            <div className="flex flex-row items-center justify-center w-full h-12 border-b bg-primary border-slate-500 ">
              <h3 className="text-xl font-bold text-white">Permissions</h3>
            </div>
            <div className="grid items-center w-full h-16 grid-cols-12 border-b divide-x border-x divide-primary border-slate-500 justify-normal">
              <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                <h3 className="text-lg font-semibold text-primary">ID</h3>
              </div>
              <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                <h3 className="text-lg font-semibold text-primary">Name</h3>
              </div>
              <div className="flex flex-col items-center justify-start h-full col-span-9 divide-y divide-primary">
                <h3 className="text-lg font-semibold text-primary">Actions</h3>
                <div className="flex flex-row items-center justify-center w-full divide-primary">
                  <div className="flex flex-row items-center justify-center w-1/4 ">
                    <h3>Action Name</h3>
                  </div>
                  <div className="flex flex-row items-center justify-center w-3/4">
                    <h3>Permission</h3>
                  </div>
                </div>
              </div>
            </div>
            {editedRole /* Use editedRole here if it's not empty */
              ? allPages.map((page, pageIndex) => (
                  <div
                    key={pageIndex}
                    className="grid items-center w-full grid-cols-12 border-b divide-x border-x divide-slate-500 border-slate-500 justify-normal"
                  >
                    <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                      <h3 className="text-lg font-semibold text-primary">
                        {pageIndex + 1}
                      </h3>
                    </div>
                    <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                      <h3 className="text-lg font-normal text-black">
                        {page.Page_Name}
                      </h3>
                    </div>
                    <div className="flex flex-col items-start h-full col-span-9 divide-y divide gap-y divide-slate-500">
                      {page.Permissions.Actions.map((action, actionIndex) => (
                        <div
                          key={actionIndex}
                          className="flex flex-row items-center w-full h-12"
                        >
                          <div className="flex flex-row items-center justify-center w-1/4 border-r border-slate-500">
                            {action.ActionName}
                          </div>
                          <div className="flex flex-row items-center justify-center w-3/4">
                            <Switch
                              checked={hasAction(
                                page.Page_Id,
                                action.ActionsId
                              )}
                              onChange={() =>
                                toggleAction(page.Page_Id, action.ActionsId)
                              }
                              disabled={!isEditing}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              : /* Use role initially if editedRole is empty */
                role.PagesAndActions.map((page, pageIndex) => (
                  <div
                    key={pageIndex}
                    className="grid items-center w-full grid-cols-12 border-b divide-x border-x divide-slate-500 border-slate-500 justify-normal"
                  >
                    <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                      <h3 className="text-lg font-semibold text-primary">
                        {pageIndex + 1}
                      </h3>
                    </div>
                    <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                      <h3 className="text-lg font-normal text-black">
                        {page.Page_Name}
                      </h3>
                    </div>
                    <div className="flex flex-col items-start h-full col-span-9 divide-y divide gap-y divide-slate-500">
                      {page.Page_Actions.map((action, actionIndex) => (
                        <div
                          key={actionIndex}
                          className="flex flex-row items-center w-full h-12"
                        >
                          <div className="flex flex-row items-center justify-center w-1/4 border-r border-slate-500">
                            {acitonwithnames.find((x) => x.id === action)!.name}
                          </div>
                          <div className="flex flex-row items-center justify-center w-3/4">
                            <Switch
                              color="primary"
                              disabled={!isEditing}
                              defaultChecked={page.Role_Actions.includes(
                                action
                              )}
                              onChange={() => {
                                const newRole = { ...role };
                                const pageIndex =
                                  newRole.PagesAndActions.findIndex(
                                    (x) => x.Page_Id === page.Page_Id
                                  );
                                if (pageIndex === -1) return;
                                const actionIndex = newRole.PagesAndActions[
                                  pageIndex
                                ].Role_Actions.findIndex((x) => x === action);
                                if (actionIndex === -1) {
                                  newRole.PagesAndActions[
                                    pageIndex
                                  ].Role_Actions.push(action);
                                } else {
                                  newRole.PagesAndActions[
                                    pageIndex
                                  ].Role_Actions.splice(actionIndex, 1);
                                }
                                setRole(newRole);
                              }}
                              inputProps={{ "aria-label": "controlled" }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
          </div>
        </div>
        <Modal
          open={isReviewModalOpen}
          onClose={handleReviewModalClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          className="flex flex-row items-center justify-center"
        >
          {renderReviewModal(editedRole || role)}
          {/* Pass editedRole or role as the data source */}
        </Modal>
      </div>
    </Layout>
  );
};

export default RoleEdit;
