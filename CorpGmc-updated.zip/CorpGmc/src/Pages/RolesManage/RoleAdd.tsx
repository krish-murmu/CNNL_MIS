import React, { useEffect, useState } from "react";
import Layout from "Components/Layout";
import Header from "Components/Header";
import toast, { Toaster } from "react-hot-toast";
import {
  Button,
  List,
  ListItem,
  ListItemText,
  Modal,
  Switch,
  TextField,
  Typography,
} from "@mui/material";
import { SubmitHandler, useForm } from "react-hook-form";
import { useTokenStore } from "../../Zustand/TokenStore";
import { Page } from "../../types";
import { Box } from "@mui/system";
import AxiosInstance from "API/axios";
import { useNavigate } from "react-router";
import { BASE_API_URL } from "API/Base";

type Props = {};

interface Role {
  Role_Name: string;
  isStatus: boolean;
  PagesAndActions: PagesWithActions[];
}

interface PagesWithActions {
  Page_Id: number; // Change this to number
  Actions: number[];
}

function RoleAdd({}: Props) {
  const navigator = useNavigate();
  const [pages, setPages] = useState<Page[]>([]);
  const [selectedActions, setSelectedActions] = useState<
    Record<string, number[]>
  >({});
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleSwitchChange = (
    pageId: number,
    actionId: number,
    checked: boolean
  ) => {
    setSelectedActions((prevSelectedActions) => {
      const updatedPageActions = prevSelectedActions[pageId] || [];
      if (checked) {
        // Add the action if it's checked
        updatedPageActions.push(actionId);
      } else {
        // Remove the action if it's unchecked
        const index = updatedPageActions.indexOf(actionId);
        if (index !== -1) {
          updatedPageActions.splice(index, 1);
        }
      }
      return {
        ...prevSelectedActions,
        [pageId]: updatedPageActions,
      };
    });
  };

  const renderModalContent = () => {
    return (
      <Box className="absolute top-1/2 left-1/2 w-11/12 h-[90%] transform -translate-x-1/2 -translate-y-1/2 bg-white shadow-md px-8 pb-8 min-w-[400px] flex flex-col items-center gap-y-4">
        <Typography variant="h6" gutterBottom>
          Role Details
        </Typography>
        <Typography variant="subtitle1" gutterBottom>
          Role Name: {watch("Role_Name")}
        </Typography>
        <div className="flex flex-col items-center w-full">
          <div className="flex flex-row items-center justify-center w-full h-12 text-white bg-primary">
            <h1>Permissions</h1>
          </div>
          <div className="grid items-center w-full h-16 grid-cols-12 border-b divide-x bg-primary/15 border-x divide-primary border-slate-500 justify-normal">
            <div className="flex flex-row items-center justify-center h-full col-span-1 ">
              <h3 className="text-lg font-semibold text-primary">ID</h3>
            </div>
            <div className="flex flex-row items-center justify-center h-full col-span-2 ">
              <h3 className="text-lg font-semibold text-primary">Name</h3>
            </div>
            <div className="flex flex-col items-center justify-start h-full col-span-9 divide-y divide-primary">
              <h3 className="text-lg font-semibold text-primary">Actions</h3>
              <div className="flex flex-row items-center justify-center w-full divide-primary">
                <div className="flex flex-row items-center justify-center w-1/4 ">
                  <h3>Action Name</h3>
                </div>
                <div className="flex flex-row items-center justify-center w-3/4">
                  <h3>Permission</h3>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full overflow-hidden overflow-y-auto h-72">
            {pages.map((page, pageIndex) => (
              <div
                className="grid items-center w-full grid-cols-12 border-b divide-x bg-primary/15 border-x divide-slate-500 border-slate-500 justify-normal"
                key={pageIndex}
              >
                <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                  <h3 className="text-lg font-semibold text-primary">
                    {pageIndex + 1}
                  </h3>
                </div>
                <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                  <h3 className="text-lg font-normal text-black">
                    {page.Page_Name}
                  </h3>
                </div>
                <div className="flex flex-col items-start h-full col-span-9 divide-y divide gap-y divide-slate-500">
                  {page.Permissions.Actions.map((action, actionIndex) => (
                    <div
                      key={actionIndex}
                      className="flex flex-row items-center w-full h-12"
                    >
                      <div className="flex flex-row items-center justify-center w-1/4 border-r border-slate-500">
                        {action.ActionName}
                      </div>
                      <div className="flex flex-row items-center justify-center w-3/4">
                        {selectedActions[page.Page_Id]?.includes(
                          action.ActionsId
                        ) ? (
                          <h3>Yes</h3>
                        ) : (
                          <h3>No</h3>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-row items-center justify-center gap-x-4">
          <Button
            variant="contained"
            sx={{ color: "#fff" }}
            onClick={closeModal}
          >
            Close
          </Button>
          <Button
            variant="contained"
            color="primary"
            sx={{ color: "#fff" }}
            onClick={handleSubmit(onSubmit)}
          >
            Submit
          </Button>
        </div>
      </Box>
    );
  };

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<Role>();

  const onSubmit: SubmitHandler<Role> = async (data: Role) => {
    // Create the PagesAndActions array based on selectedActions
    const pagesAndActions: PagesWithActions[] = Object.keys(
      selectedActions
    ).map((pageId) => ({
      Page_Id: Number(pageId), // Convert Page_Id to a number here
      Actions: selectedActions[pageId],
    }));

    // Include the PagesAndActions in the Role data
    const roleData: Role = {
      ...data,
      PagesAndActions: pagesAndActions,
    };
    console.log(roleData);
    closeModal();
    try {
      const res = await AxiosInstance.post(
        "/admin/roles/v1/create-role",
        roleData
      );
      if (res.status === 200) {
        toast.success("Role Created Successfully");
        navigator("/roles/manage");
      } else {
        toast.error("Error Occured");
      }
    } catch (err) {
      if ((err as any).response.status === 406) {
        toast.error("Role Already Exists");
        return;
      }
      toast.error("Error Occured");
      console.log(err);
    }
  };

  //get pages list from modules
  const getPages = async () => {
    // const modules = useTokenStore.getState().AuthData?.Modules;
    // const allPages: Page[] = [];

    // modules.forEach((module) => {
    //   module.Pages.forEach((page) => {
    //     allPages.push(page);
    //   });
    // });
    // console.log(allPages);
    // allPages.forEach((page) => {
    //   page.Permissions.Actions.forEach((action) => {
    //     action.Status = false;
    //   });
    // });
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/roles/v1/get-pages-with-permissions`
      );
      const allPages: Page[] = res.data;
      console.log(allPages);
      setPages(allPages);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    console.log(useTokenStore.getState().AuthData);
    getPages();
  }, []);
  return (
    <Layout>
      <div className="flex flex-col w-full h-full pt-8 mb-8">
        <div className="w-full pl-12">
          <Header title="Create New Role" subtitle="" />
        </div>
        <div className="flex flex-col w-full pl-4 gap-y-8">
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="flex flex-row w-full pl-8 justify-normal gap-x-8">
              <TextField
                id="outlined-basic"
                label="Role Name"
                variant="outlined"
                required={true}
                {...register("Role_Name", {
                  required: "This Field Is Required",
                })}
              />
              <div className="flex flex-row items-center justify-center">
                <h3 className="text-xl font-normal">Status</h3>
                <Switch
                  {...register("isStatus")}
                  defaultChecked
                  inputProps={{ "aria-label": "controlled" }}
                />
              </div>
              <Button
                type="button"
                onClick={openModal}
                variant="contained"
                color="primary"
                sx={{ color: "white" }}
              >
                Review and Submit
              </Button>
            </div>
          </form>
          <div className="flex flex-col w-full px-8">
            <div className="flex flex-row items-center justify-center w-full h-12 border-b bg-primary border-slate-500 ">
              <h3 className="text-xl font-bold text-white">Permissions</h3>
            </div>
            <div className="grid items-center w-full h-16 grid-cols-12 border-b divide-x bg-primary/15 border-x divide-primary border-slate-500 justify-normal">
              <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                <h3 className="text-lg font-semibold text-primary">ID</h3>
              </div>
              <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                <h3 className="text-lg font-semibold text-primary">Name</h3>
              </div>
              <div className="flex flex-col items-center justify-start h-full col-span-9 divide-y divide-primary">
                <h3 className="text-lg font-semibold text-primary">Actions</h3>
                <div className="flex flex-row items-center justify-center w-full divide-primary">
                  <div className="flex flex-row items-center justify-center w-1/4 ">
                    <h3>Action Name</h3>
                  </div>
                  <div className="flex flex-row items-center justify-center w-3/4">
                    <h3>Permission</h3>
                  </div>
                </div>
              </div>
            </div>
            {pages.map((page, pageIndex) => (
              <div
                key={pageIndex}
                className="grid items-center w-full grid-cols-12 border-b divide-x bg-primary/15 border-x divide-slate-500 border-slate-500 justify-normal"
              >
                <div className="flex flex-row items-center justify-center h-full col-span-1 ">
                  <h3 className="text-lg font-semibold text-primary">
                    {pageIndex + 1}
                  </h3>
                </div>
                <div className="flex flex-row items-center justify-center h-full col-span-2 ">
                  <h3 className="text-lg font-normal text-black">
                    {page.Page_Name}
                  </h3>
                </div>
                <div className="flex flex-col items-start h-full col-span-9 divide-y divide gap-y divide-slate-500">
                  {page.Permissions.Actions.map((action, actionIndex) => (
                    <div
                      key={actionIndex}
                      className="flex flex-row items-center w-full h-12"
                    >
                      <div className="flex flex-row items-center justify-center w-1/4 border-r border-slate-500">
                        {action.ActionName}
                      </div>
                      <div className="flex flex-row items-center justify-center w-3/4">
                        <Switch
                          color="primary"
                          defaultChecked={action.Status}
                          onChange={(event) =>
                            handleSwitchChange(
                              page.Page_Id,
                              action.ActionsId,
                              event.target.checked
                            )
                          }
                          inputProps={{ "aria-label": "controlled" }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
        <Modal
          open={isModalOpen}
          onClose={closeModal}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          className="flex flex-row items-center justify-center"
        >
          {renderModalContent()}
        </Modal>
      </div>
    </Layout>
  );
}

export default RoleAdd;
